#!/usr/bin/env python3
"""Автоматический отбор кандидатов на неудачно выделенные токены из вывода токенизатора.

Вход: файл с токенами (по одному на строку). Выход: JSON {категория: [[токен, число], ...]}.
Это подсказка, где искать проблемы; вывод «удачно/неудачно» делает человек.
"""
import argparse
import collections
import json
import re
import sys

CYR = re.compile(r"[А-Яа-яЁё]")
LAT = re.compile(r"[A-Za-z]")
CONN = re.compile(r"[-\u2010\u2011'\u2019./,]")
CATEGORIES = {
    "longest": "самые длинные токены (часто мусор: склейки, закодированные данные)",
    "mixed_script": "кириллица и латиница в одном токене (опечатки, похожие буквы, склейки)",
    "letter_digit_mix": "буквы и цифры в одном токене (артикулы, идентификаторы, номера)",
    "many_connectors": "две и более связки внутри токена (даты, адреса, склеенные слова)",
    "long_numbers": "числа из 8 и более цифр (идентификаторы, телефоны)",
}


def compute(lines, top=15):
    counter = collections.Counter(t.rstrip("\n") for t in lines if t.strip())
    pick = {k: [] for k in CATEGORIES}
    for tok, c in counter.items():
        if CYR.search(tok) and LAT.search(tok):
            pick["mixed_script"].append((tok, c))
        if re.search(r"[^\W\d_]", tok) and re.search(r"\d", tok):
            pick["letter_digit_mix"].append((tok, c))
        if len(CONN.findall(tok)) >= 2:
            pick["many_connectors"].append((tok, c))
        if tok.isdigit() and len(tok) >= 8:
            pick["long_numbers"].append((tok, c))
    res = {k: sorted(v, key=lambda x: (-x[1], x[0]))[:top] for k, v in pick.items()}
    res["longest"] = sorted(counter.items(), key=lambda x: (-len(x[0]), -x[1], x[0]))[:top]
    return {k: [list(x) for x in res[k]] for k in CATEGORIES}


def markdown(res):
    parts = []
    for key, title in CATEGORIES.items():
        items = res.get(key, [])
        body = " ".join("`%s` (%d)" % (t, c) for t, c in items) if items else "нет"
        parts.append("- **%s.** %s: %s" % (key, title, body))
    return "\n".join(parts)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("tokens", help="файл с токенами или '-'")
    ap.add_argument("--top", type=int, default=15)
    ap.add_argument("-o", "--output", default="-")
    a = ap.parse_args()
    f = sys.stdin if a.tokens == "-" else open(a.tokens, encoding="utf-8")
    with f:
        out = json.dumps(compute(f, a.top), ensure_ascii=False, indent=1)
    if a.output == "-":
        print(out)
    else:
        with open(a.output, "w", encoding="utf-8") as g:
            g.write(out + "\n")


if __name__ == "__main__":
    main()
