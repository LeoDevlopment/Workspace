// Токенизатор текста в UTF-8. Без сторонних библиотек (STL допустим для токенизации).
//
// Токен - максимальная последовательность букв и цифр (любые алфавиты из таблицы ниже),
// внутри которой допускаются связки (см. правила в README.md):
//   дефис между буквенно-цифровыми символами (кроме цифра-дефис-цифра),
//   апостроф между буквами, '.' ',' '/' между цифрами,
//   '.' между одиночными буквами (U.S.S.R, т.е., e.g.).
// Иероглифы и кана - по одному символу на токен. Всё остальное разделяет токены.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

typedef uint32_t u32;
enum Cls : unsigned char { OTHER = 0, LETTER, DIGIT, MARK, CJK };

struct Range { u32 lo, hi; Cls cls; };
// Отсортировано по lo, диапазоны не пересекаются.
static const Range TABLE[] = {
    {0x0030, 0x0039, DIGIT}, {0x0041, 0x005A, LETTER}, {0x0061, 0x007A, LETTER},
    {0x00AA, 0x00AA, LETTER}, {0x00B5, 0x00B5, LETTER}, {0x00BA, 0x00BA, LETTER},
    {0x00C0, 0x00D6, LETTER}, {0x00D8, 0x00F6, LETTER}, {0x00F8, 0x02C1, LETTER},
    {0x0300, 0x036F, MARK},   {0x0370, 0x0373, LETTER}, {0x0376, 0x0377, LETTER},
    {0x037B, 0x037D, LETTER}, {0x0386, 0x0386, LETTER}, {0x0388, 0x03F5, LETTER},
    {0x03F7, 0x0481, LETTER}, {0x0483, 0x0487, MARK},   {0x048A, 0x052F, LETTER},
    {0x0531, 0x0556, LETTER}, {0x0561, 0x0587, LETTER}, {0x0591, 0x05BD, MARK},
    {0x05D0, 0x05EA, LETTER}, {0x0620, 0x063F, LETTER}, {0x0641, 0x064A, LETTER},
    {0x064B, 0x065F, MARK},   {0x0660, 0x0669, DIGIT},  {0x066E, 0x066F, LETTER},
    {0x0671, 0x06D3, LETTER}, {0x06F0, 0x06F9, DIGIT},  {0x1100, 0x11FF, LETTER},
    {0x1E00, 0x1FFF, LETTER}, {0x3040, 0x30FF, CJK},    {0x3400, 0x4DBF, CJK},
    {0x4E00, 0x9FFF, CJK},    {0xAC00, 0xD7A3, LETTER}, {0xF900, 0xFAFF, CJK},
    {0xFF10, 0xFF19, DIGIT},  {0x20000, 0x2FA1F, CJK},
};
static const size_t TABLE_N = sizeof(TABLE) / sizeof(TABLE[0]);
static unsigned char ASCII_CLS[128];
static unsigned char BMP_CLS[0x10000];          // класс любого символа базовой плоскости за одно обращение

static Cls cls_slow(u32 c);

static void init_tables() {
    for (u32 c = 0; c < 128; ++c) ASCII_CLS[c] = OTHER;
    for (u32 c = '0'; c <= '9'; ++c) ASCII_CLS[c] = DIGIT;
    for (u32 c = 'A'; c <= 'Z'; ++c) ASCII_CLS[c] = LETTER;
    for (u32 c = 'a'; c <= 'z'; ++c) ASCII_CLS[c] = LETTER;
    for (u32 c = 0; c < 0x10000; ++c) BMP_CLS[c] = cls_slow(c);
}

static Cls cls_slow(u32 c) {
    if (c < 128) return (Cls)ASCII_CLS[c];
    size_t lo = 0, hi = TABLE_N;                 // последний диапазон с lo <= c
    while (lo < hi) {
        size_t mid = (lo + hi) / 2;
        if (TABLE[mid].lo <= c) lo = mid + 1; else hi = mid;
    }
    if (lo == 0) return OTHER;
    const Range& r = TABLE[lo - 1];
    return c <= r.hi ? r.cls : OTHER;
}

static inline Cls cls(u32 c) { return c < 0x10000 ? (Cls)BMP_CLS[c] : cls_slow(c); }

// Приведение к нижнему регистру: латиница (в т.ч. расширенная и вьетнамская), греческий,
// кириллица, армянский. Остальные символы не меняются. İ (U+0130) -> i.
static inline u32 to_lower(u32 c) {
    if (c < 128) return (c >= 'A' && c <= 'Z') ? c + 32 : c;
    if (c >= 0x00C0 && c <= 0x00DE) return c == 0x00D7 ? c : c + 32;
    if (c < 0x0100) return c;
    if (c <= 0x0137) return c == 0x0130 ? 'i' : (c == 0x0131 ? c : ((c & 1) ? c : c + 1));
    if (c <= 0x0148) return (c >= 0x0139 && (c & 1)) ? c + 1 : c;
    if (c <= 0x0177) return (c >= 0x014A && !(c & 1)) ? c + 1 : c;
    if (c == 0x0178) return 0x00FF;
    if (c <= 0x017E) return (c & 1) ? c + 1 : c;
    if (c == 0x0386) return 0x03AC;
    if (c >= 0x0388 && c <= 0x038A) return c + 37;
    if (c == 0x038C) return 0x03CC;
    if (c == 0x038E || c == 0x038F) return c + 63;
    if ((c >= 0x0391 && c <= 0x03A1) || (c >= 0x03A3 && c <= 0x03AB)) return c + 32;
    if (c >= 0x0400 && c <= 0x040F) return c + 80;
    if (c >= 0x0410 && c <= 0x042F) return c + 32;
    if ((c >= 0x0460 && c <= 0x0481) || (c >= 0x048A && c <= 0x04BF) || (c >= 0x04D0 && c <= 0x052F))
        return (c & 1) ? c : c + 1;
    if (c == 0x04C0) return 0x04CF;
    if (c >= 0x04C1 && c <= 0x04CE) return (c & 1) ? c + 1 : c;
    if (c >= 0x0531 && c <= 0x0556) return c + 48;
    if (c == 0x1E9E) return 0x00DF;
    if ((c >= 0x1E00 && c <= 0x1E95) || (c >= 0x1EA0 && c <= 0x1EFF)) return (c & 1) ? c : c + 1;
    return c;
}

// ---------- UTF-8 ----------
static const u32 REPLACEMENT = 0xFFFD;

// Декодирует символ с позиции p. При ошибке возвращает U+FFFD и len = 1 (один плохой байт).
static inline u32 decode(const unsigned char* p, const unsigned char* end, int& len, bool& bad) {
    unsigned char b = *p;
    bad = false;
    if (b < 0x80) { len = 1; return b; }
    int need; u32 c, minv;
    if ((b & 0xE0) == 0xC0) { need = 1; c = b & 0x1F; minv = 0x80; }
    else if ((b & 0xF0) == 0xE0) { need = 2; c = b & 0x0F; minv = 0x800; }
    else if ((b & 0xF8) == 0xF0) { need = 3; c = b & 0x07; minv = 0x10000; }
    else { len = 1; bad = true; return REPLACEMENT; }
    if (end - p <= need) { len = 1; bad = true; return REPLACEMENT; }
    for (int i = 1; i <= need; ++i) {
        if ((p[i] & 0xC0) != 0x80) { len = 1; bad = true; return REPLACEMENT; }
        c = (c << 6) | (p[i] & 0x3F);
    }
    if (c < minv || c > 0x10FFFF || (c >= 0xD800 && c <= 0xDFFF)) { len = 1; bad = true; return REPLACEMENT; }
    len = need + 1;
    return c;
}

static inline void encode(u32 c, std::string& out) {
    if (c < 0x80) out.push_back((char)c);
    else if (c < 0x800) { out.push_back((char)(0xC0 | (c >> 6))); out.push_back((char)(0x80 | (c & 0x3F))); }
    else if (c < 0x10000) {
        out.push_back((char)(0xE0 | (c >> 12))); out.push_back((char)(0x80 | ((c >> 6) & 0x3F)));
        out.push_back((char)(0x80 | (c & 0x3F)));
    } else {
        out.push_back((char)(0xF0 | (c >> 18))); out.push_back((char)(0x80 | ((c >> 12) & 0x3F)));
        out.push_back((char)(0x80 | ((c >> 6) & 0x3F))); out.push_back((char)(0x80 | (c & 0x3F)));
    }
}

// ---------- параметры, статистика, вывод ----------
struct Opts {
    bool lower = false, split_hyphens = false, doc_output = false, jsonl = false, lines_as_docs = false, no_output = false;
    size_t max_len = 100;
};

struct Stats {
    unsigned long long docs = 0, bad_docs = 0, tokens = 0, too_long = 0, invalid_bytes = 0;
    unsigned long long input_bytes = 0, text_bytes = 0, token_bytes = 0, token_chars = 0, max_token_chars = 0;
};

struct Out {
    std::string buf;
    bool discard = false;                        // --no-output: токены строятся, но не записываются
    void flush() { if (!buf.empty()) { if (!discard) fwrite(buf.data(), 1, buf.size(), stdout); buf.clear(); } }
    void maybe_flush() { if (buf.size() > (1u << 20)) flush(); }
};

static inline bool wordish(Cls c) { return c == LETTER || c == DIGIT || c == MARK; }

// Токенизирует один фрагмент (документ или строку). first - нужно ли разделять токены пробелом.
static void tokenize(const char* data, size_t len, const Opts& o, Stats& st, Out& out,
                     std::vector<u32>& cps, std::vector<unsigned char>& cl, bool& first_in_doc) {
    cps.clear();
    const unsigned char* p = (const unsigned char*)data;
    const unsigned char* end = p + len;
    while (p < end) {
        int l; bool bad;
        u32 c = decode(p, end, l, bad);
        if (bad) st.invalid_bytes++;
        cps.push_back(c);
        p += l;
    }
    const size_t n = cps.size();
    cl.resize(n);
    for (size_t k = 0; k < n; ++k) cl[k] = cls(cps[k]);
    st.text_bytes += len;

    auto emit = [&](size_t s, size_t e) {
        size_t chars = e - s;
        if (chars > o.max_len) { st.too_long++; return; }
        if (o.doc_output && !first_in_doc) out.buf.push_back(' ');
        first_in_doc = false;
        size_t tstart = out.buf.size();
        for (size_t k = s; k < e; ++k) encode(o.lower ? to_lower(cps[k]) : cps[k], out.buf);
        if (!o.doc_output) out.buf.push_back('\n');
        st.tokens++;
        st.token_bytes += out.buf.size() - tstart - (o.doc_output ? 0 : 1);
        st.token_chars += chars;
        if (chars > st.max_token_chars) st.max_token_chars = chars;
    };

    size_t i = 0;
    while (i < n) {
        Cls c = (Cls)cl[i];
        if (c == CJK) { emit(i, i + 1); ++i; continue; }
        if (c != LETTER && c != DIGIT) { ++i; continue; }
        size_t start = i++;
        while (i < n) {
            Cls d = (Cls)cl[i];
            if (wordish(d)) { ++i; continue; }
            if (i + 1 >= n) break;
            u32 ch = cps[i];
            Cls nx = (Cls)cl[i + 1];
            size_t b = i - 1;                       // базовый символ перед связкой (минуя диакритику)
            while (b > start && cl[b] == MARK) --b;
            Cls pv = (Cls)cl[b];
            bool join = false;
            if (ch == '-' || ch == 0x2010 || ch == 0x2011) {
                join = !o.split_hyphens && (pv == LETTER || pv == DIGIT) && (nx == LETTER || nx == DIGIT)
                       && !(pv == DIGIT && nx == DIGIT);
            } else if (ch == '\'' || ch == 0x2019) {
                join = pv == LETTER && nx == LETTER;
            } else if (ch == '.' || ch == ',' || ch == '/') {
                if (pv == DIGIT && nx == DIGIT) join = true;
                else if (ch == '.' && pv == LETTER && nx == LETTER) {
                    bool single = (b == start) || !wordish((Cls)cl[b - 1]);
                    bool tail = (i + 2 >= n) || !wordish((Cls)cl[i + 2]);
                    join = single && tail;
                }
            }
            if (!join) break;
            ++i;
        }
        emit(start, i);
    }
}

// ---------- разбор JSON-строки с документом: поля id и text верхнего уровня ----------
struct Json {
    const std::string& s;
    size_t p = 0;
    explicit Json(const std::string& str) : s(str) {}
    void ws() { while (p < s.size() && (s[p] == ' ' || s[p] == '\t' || s[p] == '\r' || s[p] == '\n')) ++p; }
    static int hexv(char c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    }
    bool hex4(u32& v) {
        if (p + 4 > s.size()) return false;
        v = 0;
        for (int k = 0; k < 4; ++k) { int h = hexv(s[p + k]); if (h < 0) return false; v = v * 16 + h; }
        p += 4;
        return true;
    }
    // p указывает на открывающую кавычку; out == nullptr - только пропустить.
    bool str(std::string* out) {
        if (p >= s.size() || s[p] != '"') return false;
        ++p;
        while (p < s.size()) {
            char c = s[p++];
            if (c == '"') return true;
            if (c != '\\') { if (out) out->push_back(c); continue; }
            if (p >= s.size()) return false;
            char e = s[p++];
            u32 cp;
            switch (e) {
                case '"': cp = '"'; break;   case '\\': cp = '\\'; break; case '/': cp = '/'; break;
                case 'b': cp = 8; break;     case 'f': cp = 12; break;    case 'n': cp = 10; break;
                case 'r': cp = 13; break;    case 't': cp = 9; break;
                case 'u': {
                    if (!hex4(cp)) return false;
                    if (cp >= 0xD800 && cp <= 0xDBFF) {      // старшая часть суррогатной пары
                        u32 lo = 0; size_t save = p;
                        if (p + 1 < s.size() && s[p] == '\\' && s[p + 1] == 'u') {
                            p += 2;
                            if (hex4(lo) && lo >= 0xDC00 && lo <= 0xDFFF) cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                            else { p = save; cp = REPLACEMENT; }
                        } else cp = REPLACEMENT;
                    } else if (cp >= 0xDC00 && cp <= 0xDFFF) cp = REPLACEMENT;
                    break;
                }
                default: return false;
            }
            if (out) encode(cp, *out);
        }
        return false;
    }
    bool value(int depth) {                        // пропуск значения любого типа
        if (depth > 64 || p >= s.size()) return false;
        char c = s[p];
        if (c == '"') return str(nullptr);
        if (c == '{' || c == '[') {
            char close = c == '{' ? '}' : ']';
            ++p; ws();
            if (p < s.size() && s[p] == close) { ++p; return true; }
            while (true) {
                ws();
                if (close == '}') { if (!str(nullptr)) return false; ws(); if (p >= s.size() || s[p] != ':') return false; ++p; ws(); }
                if (!value(depth + 1)) return false;
                ws();
                if (p >= s.size()) return false;
                if (s[p] == ',') { ++p; continue; }
                if (s[p] == close) { ++p; return true; }
                return false;
            }
        }
        size_t b = p;
        while (p < s.size() && s[p] != ',' && s[p] != '}' && s[p] != ']' && s[p] != ' ' && s[p] != '\r' && s[p] != '\t') ++p;
        return p > b;
    }
    bool doc(std::string& id, std::string& text, bool& has_text) {
        has_text = false; id.clear(); text.clear();
        ws();
        if (p >= s.size() || s[p] != '{') return false;
        ++p; ws();
        if (p < s.size() && s[p] == '}') return true;
        while (true) {
            ws();
            std::string key;
            if (!str(&key)) return false;
            ws();
            if (p >= s.size() || s[p] != ':') return false;
            ++p; ws();
            if (key == "text" && p < s.size() && s[p] == '"') {
                if (!str(&text)) return false;
                has_text = true;
            } else if (key == "id") {
                size_t b = p;
                if (p < s.size() && s[p] == '"') { if (!str(&id)) return false; }
                else { if (!value(0)) return false; id.assign(s, b, p - b); }
            } else if (!value(0)) return false;
            ws();
            if (p >= s.size()) return false;
            if (s[p] == ',') { ++p; continue; }
            if (s[p] == '}') return true;
            return false;
        }
    }
};

static void usage(FILE* f) {
    fputs("Использование: tokenizer [параметры] [ФАЙЛ]      (без ФАЙЛа читается stdin, UTF-8)\n"
          "  --input-format text|jsonl   text: обычный текст (по умолчанию); jsonl: corpus.jsonl (поля id, text)\n"
          "  --lines-as-docs             (text) каждая строка - отдельный документ, номер = id\n"
          "  --output-format lines|doc   lines: токен на строку (по умолчанию); doc: 'id<TAB>токены через пробел'\n"
          "  --lower                     привести токены к нижнему регистру\n"
          "  --split-hyphens             дефис всегда разделяет токены\n"
          "  --no-output                 не печатать токены (для замера скорости без записи)\n"
          "  --max-token-len N           отбрасывать токены длиннее N символов (по умолчанию 100)\n"
          "  --stats-file ФАЙЛ           записать статистику (JSON) в файл; по умолчанию - в stderr\n"
          "  -h, --help                  эта справка\n", f);
}

int main(int argc, char** argv) {
    init_tables();
    Opts o;
    std::string path, stats_path;
    for (int k = 1; k < argc; ++k) {
        std::string a = argv[k];
        auto need = [&](const char* name) -> std::string {
            if (k + 1 >= argc) { fprintf(stderr, "tokenizer: %s требует значение\n", name); usage(stderr); exit(2); }
            return argv[++k];
        };
        if (a == "-h" || a == "--help") { usage(stdout); return 0; }
        else if (a == "--lower") o.lower = true;
        else if (a == "--split-hyphens") o.split_hyphens = true;
        else if (a == "--lines-as-docs") o.lines_as_docs = true;
        else if (a == "--no-output") o.no_output = true;
        else if (a == "--input-format") {
            std::string v = need("--input-format");
            if (v == "jsonl") o.jsonl = true; else if (v == "text") o.jsonl = false;
            else { fprintf(stderr, "tokenizer: неизвестный формат ввода: %s\n", v.c_str()); return 2; }
        } else if (a == "--output-format") {
            std::string v = need("--output-format");
            if (v == "doc") o.doc_output = true; else if (v == "lines") o.doc_output = false;
            else { fprintf(stderr, "tokenizer: неизвестный формат вывода: %s\n", v.c_str()); return 2; }
        } else if (a == "--max-token-len") {
            long v = atol(need("--max-token-len").c_str());
            if (v < 1) { fprintf(stderr, "tokenizer: --max-token-len должен быть >= 1\n"); return 2; }
            o.max_len = (size_t)v;
        } else if (a == "--stats-file") stats_path = need("--stats-file");
        else if (!a.empty() && a[0] == '-' && a != "-") { fprintf(stderr, "tokenizer: неизвестный параметр %s\n", a.c_str()); usage(stderr); return 2; }
        else path = a;
    }
    std::ifstream file;
    std::istream* in = &std::cin;
    if (!path.empty() && path != "-") {
        file.open(path, std::ios::binary);
        if (!file) { fprintf(stderr, "tokenizer: не удалось открыть %s\n", path.c_str()); return 1; }
        in = &file;
    }
    std::ios::sync_with_stdio(false);

    Stats st; Out out;
    out.discard = o.no_output;
    std::vector<u32> cps; std::vector<unsigned char> cl;
    auto t0 = std::chrono::steady_clock::now();
    std::string line, id, text;
    unsigned long long lineno = 0;
    bool whole_doc_open = false, first = true;
    while (std::getline(*in, line)) {
        ++lineno;
        st.input_bytes += line.size() + 1;
        if (o.jsonl) {
            bool has_text;
            Json j(line);
            j.ws();
            if (j.p >= line.size()) continue;                   // пустая строка
            if (!j.doc(id, text, has_text) || !has_text) { st.bad_docs++; continue; }
            st.docs++;
            if (o.doc_output) { out.buf += id; out.buf.push_back('\t'); }
            first = true;
            tokenize(text.data(), text.size(), o, st, out, cps, cl, first);
            if (o.doc_output) out.buf.push_back('\n');
        } else if (o.lines_as_docs) {
            st.docs++;
            if (o.doc_output) { out.buf += std::to_string(lineno); out.buf.push_back('\t'); }
            first = true;
            tokenize(line.data(), line.size(), o, st, out, cps, cl, first);
            if (o.doc_output) out.buf.push_back('\n');
        } else {                                                // весь ввод - один документ
            if (!whole_doc_open) {
                whole_doc_open = true; st.docs = 1; first = true;
                if (o.doc_output) out.buf += "0\t";
            }
            tokenize(line.data(), line.size(), o, st, out, cps, cl, first);
        }
        out.maybe_flush();
    }
    if (!o.jsonl && !o.lines_as_docs && whole_doc_open && o.doc_output) out.buf.push_back('\n');
    out.flush();
    double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();

    char js[1024];
    double avg_b = st.tokens ? (double)st.token_bytes / st.tokens : 0;
    double avg_c = st.tokens ? (double)st.token_chars / st.tokens : 0;
    double kbs = sec > 0 ? st.text_bytes / 1024.0 / sec : 0;
    snprintf(js, sizeof js,
             "{\"docs\": %llu, \"bad_docs\": %llu, \"tokens\": %llu, \"too_long\": %llu, \"invalid_utf8_bytes\": %llu, "
             "\"input_bytes\": %llu, \"text_bytes\": %llu, \"token_bytes\": %llu, \"avg_token_bytes\": %.3f, "
             "\"avg_token_chars\": %.3f, \"max_token_chars\": %llu, \"seconds\": %.4f, \"kb_per_sec\": %.1f}\n",
             st.docs, st.bad_docs, st.tokens, st.too_long, st.invalid_bytes, st.input_bytes, st.text_bytes,
             st.token_bytes, avg_b, avg_c, st.max_token_chars, sec, kbs);
    if (stats_path.empty()) fputs(js, stderr);
    else {
        FILE* f = fopen(stats_path.c_str(), "w");
        if (!f) { fprintf(stderr, "tokenizer: не удалось записать %s\n", stats_path.c_str()); return 1; }
        fputs(js, f); fclose(f);
    }
    return 0;
}
