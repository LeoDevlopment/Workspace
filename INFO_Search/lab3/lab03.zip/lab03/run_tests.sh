#!/usr/bin/env bash
# Сборка и прогон автотестов "с нуля". Результат: tests_result.txt (один тест-кейс на строку).
set -uo pipefail
cd "$(dirname "$0")"
make -s || exit 1
python3 -m unittest discover -s tests -v 2>&1 | tee tests_result.txt
exit "${PIPESTATUS[0]}"
