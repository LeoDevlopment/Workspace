import json
import os
import random
import subprocess
import sys
import tempfile
import unicodedata
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BIN = os.environ.get("TOKENIZER_BIN") or os.path.join(ROOT, "tokenizer")


def setUpModule():
    r = subprocess.run(["make", "-C", ROOT], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


def run(data, *args, raw=False):
    """Запускает токенизатор. data - str или bytes на stdin. Возвращает (stdout, stats, код)."""
    inp = data if isinstance(data, bytes) else data.encode("utf-8")
    p = subprocess.run([BIN, *args], input=inp, capture_output=True)
    out = p.stdout if raw else p.stdout.decode("utf-8")
    stats = None
    err = p.stderr.decode("utf-8", "replace").strip()
    if err.startswith("{"):
        stats = json.loads(err)
    return out, stats, p.returncode


def toks(text, *args):
    out, _, code = run(text, *args)
    assert code == 0
    return out.split("\n")[:-1] if out else []


class SpecTests(unittest.TestCase):
    """Примеры из лекции (слайды 53-61) и правила из README."""

    def test_basic_words_and_punctuation(self):
        self.assertEqual(toks("Hello, world! (test) «кавычки» — тире…"),
                         ["Hello", "world", "test", "кавычки", "тире"])

    def test_empty_and_whitespace_only(self):
        self.assertEqual(toks(""), [])
        self.assertEqual(toks("  \n\t \r\n"), [])

    def test_hyphens_slide_60(self):
        self.assertEqual(toks("Hewlett-Packard state-of-the-art co-education the hold-him-back-and-drag-him-away maneuver"),
                         ["Hewlett-Packard", "state-of-the-art", "co-education",
                          "the", "hold-him-back-and-drag-him-away", "maneuver"])

    def test_hyphen_between_digits_splits_but_letter_digit_joins(self):
        self.assertEqual(toks("B-52 1941-1945 2-го COVID-19 234-2333"),
                         ["B-52", "1941", "1945", "2-го", "COVID-19", "234", "2333"])

    def test_hyphen_variants_and_edges(self):
        self.assertEqual(toks("a\u2010b a\u2011b -start end- a - b a--b"),
                         ["a\u2010b", "a\u2011b", "start", "end", "a", "b", "a", "b"])

    def test_split_hyphens_option(self):
        self.assertEqual(toks("Hewlett-Packard B-52", "--split-hyphens"), ["Hewlett", "Packard", "B", "52"])

    def test_apostrophes(self):
        self.assertEqual(toks("don't O\u2019Brien rock'n'roll 'quoted' l'été"),
                         ["don't", "O\u2019Brien", "rock'n'roll", "quoted", "l'été"])

    def test_numbers_slide_61(self):
        self.assertEqual(toks("3/20/91 20/3/91 Mar 20, 1991 100.2.86.144 (800) 234-2333 800.234.2333"),
                         ["3/20/91", "20/3/91", "Mar", "20", "1991", "100.2.86.144", "800", "234", "2333", "800.234.2333"])

    def test_decimal_and_thousands_separators(self):
        self.assertEqual(toks("3.14 1,000 1,000,000.50 3,14"), ["3.14", "1,000", "1,000,000.50", "3,14"])

    def test_sentence_final_punctuation_is_not_part_of_number_or_word(self):
        self.assertEqual(toks("Version 3.14. Next, 5. End, 7,"), ["Version", "3.14", "Next", "5", "End", "7"])

    def test_abbreviations_with_dots(self):
        self.assertEqual(toks("U.S.S.R. т.е. e.g. А.С. Пушкин"), ["U.S.S.R", "т.е", "e.g", "А.С", "Пушкин"])

    def test_missing_space_after_dot_is_split(self):
        self.assertEqual(toks("end.Next я.Он site.com a.bc"), ["end", "Next", "я", "Он", "site", "com", "a", "bc"])

    def test_cyrillic_latin_greek_mixed(self):
        self.assertEqual(toks("Привет, Мир! Ёлка αβγ Σοφία Zürich naïve"),
                         ["Привет", "Мир", "Ёлка", "αβγ", "Σοφία", "Zürich", "naïve"])

    def test_cjk_each_ideograph_separate_and_adjacent_latin(self):
        self.assertEqual(toks("李克强说 abc李def あい"), ["李", "克", "强", "说", "abc", "李", "def", "あ", "い"])

    def test_combining_marks_stay_in_token(self):
        self.assertEqual(toks("e\u0301cole re\u0301sume\u0301 \u0301lone"), ["e\u0301cole", "re\u0301sume\u0301", "lone"])

    def test_underscore_symbols_and_emoji_are_separators(self):
        self.assertEqual(toks("snake_case a+b x×y 😀ok€5 $100 #tag @user"),
                         ["snake", "case", "a", "b", "x", "y", "ok", "5", "100", "tag", "user"])

    def test_mixed_scripts_in_one_word_stay_together(self):
        self.assertEqual(toks("MIT-центр iPhone15 тест1"), ["MIT-центр", "iPhone15", "тест1"])

    def test_max_token_len_drops_and_counts(self):
        out, st, _ = run("ok " + "a" * 7 + " fine " + "б" * 3, "--max-token-len", "5")
        self.assertEqual(out.split(), ["ok", "fine", "ббб"])
        self.assertEqual(st["too_long"], 1)

    def test_max_token_len_counts_characters_not_bytes(self):
        self.assertEqual(toks("ёёёёё", "--max-token-len", "5"), ["ёёёёё"])
        self.assertEqual(toks("ёёёёёё", "--max-token-len", "5"), [])

    def test_default_max_len_100(self):
        self.assertEqual(len(toks("x" * 100)), 1)
        self.assertEqual(toks("x" * 101), [])

    def test_lower(self):
        self.assertEqual(toks("Привет МИР Ёлка ÀÉÎ ΑΒΓ İstanbul", "--lower"),
                         ["привет", "мир", "ёлка", "àéî", "αβγ", "istanbul"])

    def test_lower_off_by_default(self):
        self.assertEqual(toks("MIT Fed"), ["MIT", "Fed"])


class InvalidInputTests(unittest.TestCase):
    def test_invalid_utf8_bytes_are_separators_and_counted(self):
        out, st, code = run(b"ab\xffcd \xc3 x\xe2\x82 y", "--output-format", "lines")
        self.assertEqual(code, 0)
        self.assertEqual(out.split(), ["ab", "cd", "x", "y"])
        self.assertEqual(st["invalid_utf8_bytes"], 4)    # \xff, \xc3, \xe2 и оставшийся \x82

    def test_overlong_surrogate_and_out_of_range_rejected(self):
        for bad in (b"\xc0\xaf", b"\xed\xa0\x80", b"\xf4\x90\x80\x80"):
            out, st, _ = run(b"a" + bad + b"b")
            self.assertEqual(out.split(), ["a", "b"], bad)
            self.assertGreater(st["invalid_utf8_bytes"], 0)

    def test_output_is_always_valid_utf8(self):
        rnd = random.Random(7)
        data = bytes(rnd.randrange(256) for _ in range(20000))
        out, _, code = run(data, raw=True)
        self.assertEqual(code, 0)
        out.decode("utf-8")

    def test_bom_and_crlf(self):
        self.assertEqual(toks("\ufeffHello\r\nworld\r\n"), ["Hello", "world"])

    def test_nul_byte_is_separator(self):
        self.assertEqual(toks("a\x00b"), ["a", "b"])


class OutputFormatTests(unittest.TestCase):
    def test_doc_format_whole_input_is_doc_zero(self):
        out, st, _ = run("one two\nthree\n", "--output-format", "doc")
        self.assertEqual(out, "0\tone two three\n")
        self.assertEqual(st["docs"], 1)

    def test_lines_as_docs_numbers_lines_from_one(self):
        out, st, _ = run("a b\n\nc\n", "--lines-as-docs", "--output-format", "doc")
        self.assertEqual(out, "1\ta b\n2\t\n3\tc\n")
        self.assertEqual(st["docs"], 3)

    def test_empty_input_doc_format(self):
        out, st, _ = run("", "--output-format", "doc")
        self.assertEqual((out, st["docs"], st["tokens"]), ("", 0, 0))

    def test_last_line_without_newline(self):
        self.assertEqual(toks("a b\nc"), ["a", "b", "c"])

    def test_no_output_prints_nothing_but_counts_the_same(self):
        text = "Привет, мир! Hewlett-Packard 3.14\n" * 50
        a_out, a_st, _ = run(text)
        b_out, b_st, _ = run(text, "--no-output")
        self.assertEqual(b_out, "")
        self.assertNotEqual(a_out, "")
        for k in ("tokens", "token_bytes", "avg_token_chars", "text_bytes", "docs"):
            self.assertEqual(a_st[k], b_st[k], k)

    def test_stats_fields(self):
        _, st, _ = run("Привет мир", "--lower")
        self.assertEqual(st["tokens"], 2)
        self.assertEqual(st["token_bytes"], 18)            # "привет" 12 байт + "мир" 6 байт
        self.assertEqual(st["avg_token_bytes"], 9.0)
        self.assertEqual(st["avg_token_chars"], 4.5)
        self.assertEqual(st["max_token_chars"], 6)
        self.assertEqual(st["text_bytes"], 19)


class JsonlTests(unittest.TestCase):
    def doc(self, *lines, args=()):
        return run("\n".join(lines) + "\n", "--input-format", "jsonl", "--output-format", "doc", *args)

    def test_corpus_line_with_escapes_and_unicode(self):
        line = json.dumps({"id": 5, "title": "Т", "url": "https://x/y", "text": 'Café "quoted"\nline2\tтаб'},
                          ensure_ascii=False)
        out, st, _ = self.doc(line)
        self.assertEqual(out, '5\tCafé quoted line2 таб\n')
        self.assertEqual(st["docs"], 1)

    def test_ascii_escaped_json_equals_raw(self):
        obj = {"id": 1, "text": "Привет, мир! 李克强 😀 end"}
        a, _, _ = self.doc(json.dumps(obj, ensure_ascii=True))
        b, _, _ = self.doc(json.dumps(obj, ensure_ascii=False))
        self.assertEqual(a, b)
        self.assertEqual(a, "1\tПривет мир 李 克 强 end\n")

    def test_surrogate_pair_decodes_to_one_char_separator(self):
        out, _, _ = self.doc('{"id":1,"text":"a\\ud83d\\ude00b"}')
        self.assertEqual(out, "1\ta b\n")

    def test_lone_surrogates_become_separators(self):
        out, _, _ = self.doc('{"id":1,"text":"a\\ud83dx b\\ude00c"}')
        self.assertEqual(out, "1\ta x b c\n")

    def test_only_top_level_text_is_used(self):
        out, st, _ = self.doc('{"meta":{"text":"no","a":[1,{"text":"no"}]},"id":7,"text":"yes","tail":[1,2]}')
        self.assertEqual(out, "7\tyes\n")
        self.assertEqual(st["bad_docs"], 0)

    def test_string_id_and_key_order(self):
        out, _, _ = self.doc('{"text":"x y","id":"abc-1"}')
        self.assertEqual(out, "abc-1\tx y\n")

    def test_missing_text_or_broken_json_counted_and_skipped(self):
        out, st, code = self.doc('{"id":1}', '{oops', '{"id":2,"text":"ok"}', '', '{"id":3,"text":"unterminated}', '[1,2]')
        self.assertEqual(code, 0)
        self.assertEqual(out, "2\tok\n")
        self.assertEqual((st["docs"], st["bad_docs"]), (1, 4))

    def test_text_not_a_string_is_bad_doc(self):
        out, st, _ = self.doc('{"id":1,"text":123}')
        self.assertEqual((out, st["bad_docs"]), ("", 1))

    def test_crlf_between_records_and_empty_text(self):
        out, st, _ = run('{"id":1,"text":""}\r\n{"id":2,"text":"a"}\r\n', "--input-format", "jsonl", "--output-format", "doc")
        self.assertEqual(out, "1\t\n2\ta\n")

    def test_deeply_nested_garbage_does_not_crash(self):
        deep = '{"id":1,"x":' + "[" * 5000 + "]" * 5000 + ',"text":"ok"}'
        out, st, code = self.doc(deep)
        self.assertEqual(code, 0)
        self.assertEqual(st["bad_docs"], 1)

    def test_lines_format_for_jsonl(self):
        out, _, _ = run('{"id":1,"text":"a b"}\n{"id":2,"text":"c"}\n', "--input-format", "jsonl")
        self.assertEqual(out, "a\nb\nc\n")


class CliTests(unittest.TestCase):
    def test_help(self):
        out, _, code = run("", "--help")
        self.assertEqual(code, 0)
        self.assertIn("--input-format", out)

    def test_bad_options_exit_2(self):
        for args in (["--bogus"], ["--input-format", "xml"], ["--output-format", "x"],
                     ["--max-token-len", "0"], ["--max-token-len"]):
            self.assertEqual(run("", *args)[2], 2, args)

    def test_missing_file_exit_1(self):
        self.assertEqual(run("", "/nonexistent/file.txt")[2], 1)

    def test_file_argument_and_stats_file(self):
        with tempfile.TemporaryDirectory() as d:
            p, sp = os.path.join(d, "in.txt"), os.path.join(d, "stats.json")
            with open(p, "w", encoding="utf-8") as f:
                f.write("раз два три\n")
            r = subprocess.run([BIN, p, "--stats-file", sp], capture_output=True)
            self.assertEqual(r.returncode, 0)
            self.assertEqual(r.stdout.decode().split(), ["раз", "два", "три"])
            self.assertEqual(r.stderr, b"")
            with open(sp) as f:
                self.assertEqual(json.load(f)["tokens"], 3)

    def test_large_single_line_and_many_lines(self):
        big = ("слово " * 200000)                       # ~1.4 МБ в одной строке
        _, st, _ = run(big)
        self.assertEqual(st["tokens"], 200000)
        many = "a b c\n" * 100000
        _, st, _ = run(many, "--lines-as-docs")
        self.assertEqual((st["docs"], st["tokens"]), (100000, 300000))


# ---------- сверка с независимой реализацией спецификации на Python ----------
def ref_cls(c):
    o = ord(c)
    if 0x3040 <= o <= 0x30FF or 0x4E00 <= o <= 0x9FFF or 0x3400 <= o <= 0x4DBF:
        return "C"
    if c.isascii() and c.isdigit():
        return "D"
    if unicodedata.category(c).startswith("M"):
        return "M"
    if c.isalpha():
        return "L"
    return "O"


def ref_tokenize(text, split_hyphens=False, max_len=100, lower=False):
    cps, n = list(text), len(text)
    cl = [ref_cls(c) for c in cps]
    wordish = lambda k: cl[k] in "LDM"
    res, i = [], 0

    def emit(s, e):
        if e - s <= max_len:
            t = "".join(cps[s:e])
            res.append("".join(ch.lower() for ch in t) if lower else t)   # посимвольно, без контекста

    while i < n:
        if cl[i] == "C":
            emit(i, i + 1); i += 1; continue
        if cl[i] not in "LD":
            i += 1; continue
        start = i; i += 1
        while i < n:
            if wordish(i):
                i += 1; continue
            if i + 1 >= n:
                break
            ch, nx = cps[i], cl[i + 1]
            b = i - 1
            while b > start and cl[b] == "M":
                b -= 1
            pv = cl[b]
            join = False
            if ch in "-\u2010\u2011":
                join = (not split_hyphens) and pv in "LD" and nx in "LD" and not (pv == "D" and nx == "D")
            elif ch in "'\u2019":
                join = pv == "L" and nx == "L"
            elif ch in ".,/":
                if pv == "D" and nx == "D":
                    join = True
                elif ch == "." and pv == "L" and nx == "L":
                    single = b == start or not wordish(b - 1)
                    tail = i + 2 >= n or not wordish(i + 2)
                    join = single and tail
            if not join:
                break
            i += 1
        emit(start, i)
    return res


ALPHABET = list("aZbxцЯжЁéÉßαΣ5097") + ["李", "あ", "\u0301"] + list("-\u2010\u2011'\u2019.,/") + \
           list(" \n!()_:\u00d7\"") + ["a", "b", "ж", "5", "-", ".", " "]


class ReferenceComparisonTests(unittest.TestCase):
    def compare(self, args, **kw):
        rnd = random.Random(12345)
        docs = ["".join(rnd.choice(ALPHABET) for _ in range(rnd.randrange(0, 40))).replace("\n", " ")
                for _ in range(4000)]
        out, _, code = run("\n".join(docs) + "\n", "--lines-as-docs", "--output-format", "doc", *args)
        self.assertEqual(code, 0)
        lines = out.split("\n")[:-1]
        self.assertEqual(len(lines), len(docs))
        for k, (doc, line) in enumerate(zip(docs, lines), 1):
            got = line.split("\t", 1)[1].split(" ") if line.split("\t", 1)[1] else []
            self.assertEqual(got, ref_tokenize(doc, **kw), "doc %d: %r" % (k, doc))

    def test_default(self):
        self.compare([])

    def test_split_hyphens(self):
        self.compare(["--split-hyphens"], split_hyphens=True)

    def test_lower(self):
        self.compare(["--lower"], lower=True)

    def test_small_max_len(self):
        self.compare(["--max-token-len", "4"], max_len=4)


class LowercaseTableTests(unittest.TestCase):
    RANGES = [(0x41, 0x24F - 0xCF), (0x100, 0x17F), (0x386, 0x3AB), (0x400, 0x52F), (0x531, 0x556), (0x1E00, 0x1EFF)]

    def test_matches_python_lower_on_covered_blocks(self):
        chars = []
        for lo, hi in self.RANGES:
            for o in range(lo, hi + 1):
                c = chr(o)
                if c.isalpha() and len(c.lower()) == 1 and ref_cls(c) == "L" and o not in (0x130, 0x1E9E):
                    chars.append(c)
        out, _, _ = run("\n".join(chars) + "\n", "--lower", "--lines-as-docs", "--output-format", "doc")
        bad = []
        for c, line in zip(chars, out.split("\n")):
            got = line.split("\t", 1)[1]
            if got != c.lower():
                bad.append((hex(ord(c)), got, c.lower()))
        self.assertEqual(bad, [])
        self.assertGreater(len(chars), 700)

    def test_special_cases(self):
        self.assertEqual(toks("İ ẞ Ÿ", "--lower"), ["i", "ß", "ÿ"])

    def test_final_sigma_is_not_context_sensitive(self):
        self.assertEqual(toks("ΟΔΥΣΣΕΥΣ", "--lower"), ["οδυσσευσ"])


if __name__ == "__main__":
    unittest.main()
