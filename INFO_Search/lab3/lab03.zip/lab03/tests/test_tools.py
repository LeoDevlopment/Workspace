import json
import os
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import bad_tokens
import bench
import failures
import token_stats


def setUpModule():
    assert subprocess.run(["make", "-C", ROOT], capture_output=True).returncode == 0


class FailuresTableTests(unittest.TestCase):
    """Фиксируют зафиксированное в отчёте поведение: если правила изменятся, отчёт надо обновить."""

    def got(self, text):
        return {t: g for t, g, _, _ in failures.rows()}[text]

    def test_documented_failures_still_happen(self):
        self.assertEqual(self.got("+7 (495) 123-45-67"), ["7", "495", "123", "45", "67"])
        self.assertEqual(self.got("user@example.com"), ["user", "example", "com"])
        self.assertEqual(self.got("C++ и C#"), ["C", "и", "C"])
        self.assertEqual(self.got("AT&T"), ["AT", "T"])
        self.assertEqual(self.got("т. е. и т. д."), ["т", "е", "и", "т", "д"])
        self.assertEqual(self.got("10 000 руб, 1 500 000"), ["10", "000", "руб", "1", "500", "000"])
        self.assertEqual(self.got("Ю.А.Гагарин"), ["Ю.А", "Гагарин"])
        self.assertEqual(self.got("e-mail и email"), ["e-mail", "и", "email"])
        self.assertEqual(self.got("李克强说"), ["李", "克", "强", "说"])

    def test_table_has_row_per_case_and_no_pipes_inside_cells(self):
        lines = failures.table().split("\n")
        self.assertEqual(len(lines), 2 + len(failures.CASES))
        for line in lines:
            self.assertEqual(line.count("|"), 5, line)


class BadTokensTests(unittest.TestCase):
    def test_categories(self):
        toks = ["привет"] * 3 + ["Москваmoscow", "Москваmoscow", "abc123", "x1", "x1", "x1", "1.2.3", "a-b-c",
                                 "12345678", "1234567", "a" * 40, "обычное"]
        res = bad_tokens.compute(iter(toks), top=5)
        self.assertEqual(res["mixed_script"], [["Москваmoscow", 2]])
        self.assertEqual(res["letter_digit_mix"][0], ["x1", 3])
        self.assertIn(["abc123", 1], res["letter_digit_mix"])
        self.assertEqual({t for t, _ in res["many_connectors"]}, {"1.2.3", "a-b-c"})
        self.assertEqual(res["long_numbers"], [["12345678", 1]])
        self.assertEqual(res["longest"][0], ["a" * 40, 1])
        self.assertEqual(set(res), set(bad_tokens.CATEGORIES))

    def test_markdown_and_empty(self):
        md = bad_tokens.markdown(bad_tokens.compute(iter([])))
        self.assertEqual(md.count("нет"), len(bad_tokens.CATEGORIES))
        self.assertIn("`x1` (3)", bad_tokens.markdown({"longest": [["x1", 3]]}))


class BenchMathTests(unittest.TestCase):
    def test_exact_line(self):
        a, b, r2 = bench.linear_fit([1, 2, 3, 4], [3, 5, 7, 9])
        self.assertAlmostEqual(a, 1.0); self.assertAlmostEqual(b, 2.0); self.assertAlmostEqual(r2, 1.0)

    def test_noisy_line_has_lower_r2_and_constant_y_is_handled(self):
        _, _, r2 = bench.linear_fit([1, 2, 3, 4], [1, 5, 2, 6])
        self.assertLess(r2, 0.6)
        a, b, r2 = bench.linear_fit([1, 2, 3], [4, 4, 4])
        self.assertEqual((a, b, r2), (4.0, 0.0, 1.0))

    def test_measure_end_to_end_on_tiny_corpus(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "c.jsonl")
            with open(p, "w", encoding="utf-8") as f:
                for i in range(64):
                    f.write(json.dumps({"id": i, "text": "слово раз два " * 50}, ensure_ascii=False) + "\n")
            res = bench.measure(p, parts=3, repeats=1)
            self.assertEqual([r["docs"] for r in res["rows"]], [16, 32, 64])
            self.assertEqual([r["tokens"] for r in res["rows"]], [16 * 150, 32 * 150, 64 * 150])
            self.assertTrue(all(r["kb_per_sec"] > 0 for r in res["rows"]))


class TokenStatsTests(unittest.TestCase):
    def test_compute(self):
        toks = ["a", "a", "b", "москва", "москва", "москва", "3.14", "B-52", "don't"]
        st = token_stats.compute(iter(toks), top=2)
        self.assertEqual((st["tokens"], st["unique_tokens"], st["hapax_tokens"]), (9, 6, 4))
        self.assertEqual(st["top_tokens"][0], ("москва", 3))
        self.assertEqual(st["share_with_digits"], round(2 / 9, 4))
        self.assertEqual(st["share_with_hyphen"], round(1 / 9, 4))
        self.assertEqual(st["share_with_apostrophe"], round(1 / 9, 4))
        self.assertEqual(st["share_cyrillic_only"], round(3 / 9, 4))
        self.assertEqual(st["share_latin_only"], round(3 / 9, 4))   # a, a, b; B-52 и don't не считаются
        self.assertEqual(st["length_histogram"]["1"], 3)


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


class ReportBuildTests(unittest.TestCase):
    def test_report_has_no_unsubstituted_fields_with_and_without_bench(self):
        with tempfile.TemporaryDirectory() as d:
            corpus = os.path.join(d, "c.jsonl")
            with open(corpus, "w", encoding="utf-8") as f:
                for i in range(40):
                    f.write(json.dumps({"id": i, "text": "Москва B-52 3.14 hello world " * 20}, ensure_ascii=False) + "\n")
            tok = os.path.join(ROOT, "tokenizer")
            tokens = os.path.join(d, "tokens.txt")
            with open(tokens, "wb") as out:
                subprocess.run([tok, corpus, "--input-format", "jsonl", "--lower",
                                "--stats-file", os.path.join(d, "t.json")], stdout=out, check=True)
            subprocess.run([sys.executable, os.path.join(ROOT, "token_stats.py"), tokens, "-o", os.path.join(d, "v.json")], check=True)
            base = [sys.executable, os.path.join(ROOT, "make_report.py"), "--student", "И", "--group", "Г",
                    "--tok-stats", os.path.join(d, "t.json"), "--vocab", os.path.join(d, "v.json"),
                    "--bench", os.path.join(d, "none.json"), "--bad", os.path.join(d, "none2.json")]
            r = subprocess.run(base + ["-o", os.path.join(d, "r1.md")], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            md = read(os.path.join(d, "r1.md"))
            self.assertNotIn("${", md)
            self.assertIn("ЗАПОЛНИТЬ: запустите `python3 bench.py", md)

            bj = os.path.join(d, "b.json")
            res = bench.measure(corpus, parts=3, repeats=1)
            with open(bj, "w") as f:
                json.dump(res, f)
            bad = os.path.join(d, "bad.json")
            subprocess.run([sys.executable, os.path.join(ROOT, "bad_tokens.py"), tokens, "-o", bad], check=True)
            base[-4:] = ["--bench", bj, "--bad", bad]
            r = subprocess.run(base + ["-o", os.path.join(d, "r2.md")], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            md = read(os.path.join(d, "r2.md"))
            self.assertNotIn("${", md)
            self.assertIn("R² =", md)
            self.assertIn("| Документов | Объём, МБ |", md)
            self.assertIn("**longest.**", md)


if __name__ == "__main__":
    unittest.main()
