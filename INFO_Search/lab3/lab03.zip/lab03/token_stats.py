#!/usr/bin/env python3
"""Статистика словаря по выводу токенизатора (формат lines: токен на строку) -> JSON.

В памяти держится счётчик различных токенов (для корпуса порядка миллиона документов
его нужно заменить внешней сортировкой: sort | uniq -c).
"""
import argparse
import collections
import json
import re
import sys

CYR = re.compile(r"^[А-Яа-яЁё]+$")
LAT = re.compile(r"^[A-Za-z]+$")


def compute(lines, top=20):
    counter = collections.Counter(t.rstrip("\n") for t in lines if t.strip())
    total = sum(counter.values())
    def share(pred):
        return round(sum(c for t, c in counter.items() if pred(t)) / total, 4) if total else 0
    lens = collections.Counter()
    for t, c in counter.items():
        lens[min(len(t), 16)] += c
    hapax = sum(1 for c in counter.values() if c == 1)
    return {
        "tokens": total,
        "unique_tokens": len(counter),
        "hapax_tokens": hapax,
        "hapax_share_of_vocab": round(hapax / len(counter), 4) if counter else 0,
        "top_tokens": counter.most_common(top),
        "length_histogram": {("16+" if k == 16 else str(k)): lens[k] for k in sorted(lens)},
        "share_with_digits": share(lambda t: any(ch.isdigit() for ch in t)),
        "share_with_hyphen": share(lambda t: "-" in t or "\u2010" in t or "\u2011" in t),
        "share_with_apostrophe": share(lambda t: "'" in t or "\u2019" in t),
        "share_with_dot_or_slash": share(lambda t: "." in t or "/" in t),
        "share_cyrillic_only": share(lambda t: bool(CYR.match(t))),
        "share_latin_only": share(lambda t: bool(LAT.match(t))),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("tokens", help="файл с токенами (по одному на строку) или '-'")
    ap.add_argument("--top", type=int, default=20)
    ap.add_argument("-o", "--output", default="-")
    a = ap.parse_args()
    f = sys.stdin if a.tokens == "-" else open(a.tokens, encoding="utf-8")
    with f:
        out = json.dumps(compute(f, a.top), ensure_ascii=False, indent=2)
    if a.output == "-":
        print(out)
    else:
        with open(a.output, "w", encoding="utf-8") as g:
            g.write(out + "\n")


if __name__ == "__main__":
    main()
