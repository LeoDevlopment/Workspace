#!/usr/bin/env bash
# Сборка -> токенизация корпуса ЛР1 -> статистика -> отчёт.
# Использование: ./run_all.sh /путь/к/corpus.jsonl "Иванов И. И." "М8О-101Б-23" "Тема корпуса"
set -euo pipefail
cd "$(dirname "$0")"
CORPUS=${1:?corpus.jsonl}; STUDENT=${2:?ФИО}; GROUP=${3:?группа}; CATEGORY=${4:?тема корпуса}
make -s
mkdir -p data
./tokenizer "$CORPUS" --input-format jsonl --output-format lines --lower \
    --stats-file data/tok_stats.json > data/tokens.txt
python3 token_stats.py data/tokens.txt -o data/vocab.json
python3 bad_tokens.py data/tokens.txt -o data/bad_tokens.json
python3 bench.py "$CORPUS" -o data/bench.json --plot data/bench.png
python3 make_report.py --student "$STUDENT" --group "$GROUP" --category "$CATEGORY"
./build_report.sh
