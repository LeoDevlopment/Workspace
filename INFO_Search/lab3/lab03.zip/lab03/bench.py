#!/usr/bin/env python3
"""Зависимость времени токенизации от объёма данных и сравнение с простым чтением файла.

Берёт первые k строк corpus.jsonl для k = N/32, N/16, ..., N, для каждого размера
запускает токенизатор (с записью токенов и с --no-output) и `cat` (чтение файла),
повторяет замеры и берёт медиану; затем строит линейную модель время = a + b * байты.
"""
import argparse
import json
import os
import statistics
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
BIN = os.environ.get("TOKENIZER_BIN") or os.path.join(HERE, "tokenizer")


def linear_fit(xs, ys):
    """МНК: y = a + b*x. Возвращает (a, b, R^2)."""
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    b = sxy / sxx if sxx else 0.0
    a = my - b * mx
    ss_tot = sum((y - my) ** 2 for y in ys)
    ss_res = sum((y - (a + b * x)) ** 2 for x, y in zip(xs, ys))
    return a, b, (1 - ss_res / ss_tot) if ss_tot else 1.0


def count_lines(path):
    with open(path, "rb") as f:
        return sum(1 for _ in f)


def write_prefix(src, dst, k):
    with open(src, "rb") as f, open(dst, "wb") as g:
        for i, line in enumerate(f):
            if i >= k:
                break
            g.write(line)


def timed_tokenizer(path, args, tmp):
    stats = os.path.join(tmp, "s.json")
    subprocess.run([BIN, path, "--input-format", "jsonl", "--stats-file", stats, *args],
                   stdout=subprocess.DEVNULL, check=True)
    with open(stats, encoding="utf-8") as f:
        return json.load(f)


def timed_cat(path):
    t = time.perf_counter()
    subprocess.run(["cat", path], stdout=subprocess.DEVNULL, check=True)
    return time.perf_counter() - t


def measure(corpus, parts=6, repeats=3):
    total = count_lines(corpus)
    if total == 0:
        raise SystemExit("пустой корпус")
    ks = sorted({max(1, total // 2 ** i) for i in range(parts - 1, -1, -1)})
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        for k in ks:
            p = os.path.join(tmp, "part.jsonl")
            write_prefix(corpus, p, k)
            runs = [timed_tokenizer(p, ["--lower"], tmp) for _ in range(repeats)]
            quiet = [timed_tokenizer(p, ["--lower", "--no-output"], tmp)["seconds"] for _ in range(repeats)]
            cats = [timed_cat(p) for _ in range(repeats)]
            rows.append({
                "docs": runs[0]["docs"], "tokens": runs[0]["tokens"], "input_bytes": runs[0]["input_bytes"],
                "text_bytes": runs[0]["text_bytes"],
                "seconds": statistics.median(r["seconds"] for r in runs),
                "seconds_no_output": statistics.median(quiet),
                "seconds_cat": statistics.median(cats),
            })
    a, b, r2 = linear_fit([r["text_bytes"] for r in rows], [r["seconds"] for r in rows])
    for r in rows:
        r["kb_per_sec"] = r["text_bytes"] / 1024 / r["seconds"] if r["seconds"] else 0
        r["kb_per_sec_no_output"] = r["text_bytes"] / 1024 / r["seconds_no_output"] if r["seconds_no_output"] else 0
        r["kb_per_sec_cat"] = r["input_bytes"] / 1024 / r["seconds_cat"] if r["seconds_cat"] else 0
    last = rows[-1]
    return {"rows": rows, "fit": {"intercept_s": a, "slope_s_per_byte": b, "r2": r2,
                                  "seconds_per_mb": b * 1024 * 1024},
            "full_run_vs_cat": last["kb_per_sec"] / last["kb_per_sec_cat"] if last["kb_per_sec_cat"] else None}


def plot(res, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    xs = [r["text_bytes"] / 1048576 for r in res["rows"]]
    fig, ax = plt.subplots(figsize=(6, 3.6))
    ax.plot(xs, [r["seconds"] for r in res["rows"]], "o-", label="токенизация (с выводом)")
    ax.plot(xs, [r["seconds_no_output"] for r in res["rows"]], "s--", label="токенизация (--no-output)")
    ax.plot(xs, [r["seconds_cat"] for r in res["rows"]], "^:", label="чтение файла (cat)")
    f = res["fit"]
    ax.plot(xs, [f["intercept_s"] + f["slope_s_per_byte"] * x * 1048576 for x in xs], "k-", lw=0.8,
            label="линейная модель")
    ax.set_xlabel("объём текста, МБ"); ax.set_ylabel("время, с"); ax.grid(alpha=.3); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("corpus", help="corpus.jsonl")
    ap.add_argument("--parts", type=int, default=6, help="число размеров (степени двойки)")
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("-o", "--output", default="data/bench.json")
    ap.add_argument("--plot", default="data/bench.png")
    a = ap.parse_args()
    res = measure(a.corpus, a.parts, a.repeats)
    os.makedirs(os.path.dirname(os.path.abspath(a.output)), exist_ok=True)
    with open(a.output, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    if a.plot:
        try:
            plot(res, a.plot)
        except ImportError:
            print("matplotlib не установлен: график пропущен", file=sys.stderr)
    print(json.dumps(res["fit"], indent=2))


if __name__ == "__main__":
    main()
