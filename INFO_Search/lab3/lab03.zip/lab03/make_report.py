#!/usr/bin/env python3
"""Собирает report.md из report_template.md, статистики токенизатора и словаря."""
import argparse
import json
import os
import string
import bad_tokens
import examples
import failures


def n(v):
    if isinstance(v, bool):
        return "да" if v else "нет"
    if isinstance(v, int):
        return "{:,}".format(v).replace(",", "\u00a0")
    if isinstance(v, float):
        return "{:,.2f}".format(v).replace(",", "\u00a0")
    return str(v)


def pct(x):
    return "%.1f%%" % (100 * x)


def bench_block(a):
    todo = "*ЗАПОЛНИТЬ: запустите `python3 bench.py corpus.jsonl` и пересоберите отчёт.*"
    if not os.path.exists(a.bench):
        return {"bench_table": todo, "bench_fit": "", "bench_plot": "", "speed_verdict": todo, "repeats": "3"}
    with open(a.bench, encoding="utf-8") as f:
        b = json.load(f)
    rows = ["| Документов | Объём, МБ | Токенов | С выводом, с | Без вывода, с | cat, с | Скорость, КБ/с |",
            "|---|---|---|---|---|---|---|"]
    for r in b["rows"]:
        rows.append("| %s | %.2f | %s | %.3f | %.3f | %.4f | %s |" % (
            n(r["docs"]), r["text_bytes"] / 1048576, n(r["tokens"]), r["seconds"],
            r["seconds_no_output"], r["seconds_cat"], n(round(r["kb_per_sec"]))))
    f_ = b["fit"]
    fit = ("Линейная модель «время = a + b · объём» по методу наименьших квадратов: b = %.4f с/МБ, a = %.4f с, "
           "коэффициент детерминации R² = %.4f. %s" % (
               f_["seconds_per_mb"], f_["intercept_s"], f_["r2"],
               "Время растёт линейно с объёмом входных данных." if f_["r2"] > 0.98 else
               "Зависимость заметно отличается от линейной: проверьте шум замеров и влияние кеша."))
    plot = "![Время токенизации в зависимости от объёма](%s)" % a.bench_plot if os.path.exists(a.bench_plot) else ""
    last = b["rows"][-1]
    ratio = b.get("full_run_vs_cat")
    if ratio is not None and ratio < 0.5:
        verdict = ("На полном корпусе скорость токенизации %s КБ/с, простое чтение того же файла %s КБ/с, то есть токенизатор "
                   "работает со скоростью %.1f%% от скорости чтения. Отключение вывода (`--no-output`) даёт %s КБ/с, то есть запись "
                   "результата почти не влияет. Время уходит на сам разбор: декодирование UTF-8, классификацию символов, сборку токенов. "
                   "**Скорость не оптимальна**: производительность ограничена процессором, а не вводом-выводом, поэтому "
                   "запас для ускорения есть." % (n(round(last["kb_per_sec"])), n(round(last["kb_per_sec_cat"])),
                                                   100 * ratio, n(round(last["kb_per_sec_no_output"]))))
    else:
        verdict = ("На полном корпусе скорость токенизации %s КБ/с, простое чтение файла %s КБ/с (отношение %s). Скорость близка "
                   "к пределу ввода-вывода; ускорение возможно только за счёт параллелизма." % (
                       n(round(last["kb_per_sec"])), n(round(last["kb_per_sec_cat"])),
                       "н/д" if ratio is None else "%.2f" % ratio))
    return {"bench_table": "\n".join(rows), "bench_fit": fit, "bench_plot": plot, "speed_verdict": verdict,
            "repeats": "3"}


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--tok-stats", default="data/tok_stats.json")
    ap.add_argument("--vocab", default="data/vocab.json")
    ap.add_argument("--template", default=os.path.join(here, "report_template.md"))
    ap.add_argument("--student", required=True)
    ap.add_argument("--group", required=True)
    ap.add_argument("--bench", default="data/bench.json")
    ap.add_argument("--bench-plot", default="data/bench.png")
    ap.add_argument("--bad", default="data/bad_tokens.json")
    ap.add_argument("--category", default="ЗАПОЛНИТЬ (тема корпуса ЛР1)")
    ap.add_argument("-o", "--output", default="report.md")
    a = ap.parse_args()

    with open(a.tok_stats, encoding="utf-8") as f:
        ts = json.load(f)
    with open(a.vocab, encoding="utf-8") as f:
        vc = json.load(f)
    v = {k: n(x) for k, x in ts.items()}
    v.update({k: n(x) for k, x in vc.items() if not isinstance(x, (list, dict))})
    for k in ("hapax_share_of_vocab", "share_cyrillic_only", "share_latin_only", "share_with_digits",
              "share_with_hyphen", "share_with_apostrophe", "share_with_dot_or_slash"):
        v[k] = pct(vc[k])
    total = vc["tokens"] or 1
    v["length_table"] = "| Длина | Токенов | Доля |\n|---|---|---|\n" + "\n".join(
        "| %s | %s | %s |" % (k, n(c), pct(c / total)) for k, c in vc["length_histogram"].items())
    v["top_table"] = "| № | Токен | Вхождений | Доля |\n|---|---|---|---|\n" + "\n".join(
        "| %d | %s | %s | %s |" % (i, t, n(c), pct(c / total)) for i, (t, c) in enumerate(vc["top_tokens"], 1))
    v["examples_table"] = examples.table()
    v["failures_table"] = failures.table()
    if os.path.exists(a.bad):
        with open(a.bad, encoding="utf-8") as f:
            v["bad_tokens_block"] = bad_tokens.markdown(json.load(f))
    else:
        v["bad_tokens_block"] = "*ЗАПОЛНИТЬ: запустите `python3 bad_tokens.py data/tokens.txt -o data/bad_tokens.json`.*"
    v.update(bench_block(a))
    v.update(student=a.student, group=a.group, category=a.category)
    with open(a.template, encoding="utf-8") as f:
        text = string.Template(f.read()).substitute(v)
    with open(a.output, "w", encoding="utf-8") as f:
        f.write(text)


if __name__ == "__main__":
    main()
