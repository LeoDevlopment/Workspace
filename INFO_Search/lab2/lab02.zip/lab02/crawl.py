#!/usr/bin/env python3
"""Робот: качает документы корпуса лабораторной №1 и сохраняет сырой HTML в MongoDB.

Вход: corpus.jsonl (поле url) либо файл со списком URL; '-' - stdin.
Можно прерывать (Ctrl-C) и запускать снова: уже скачанное пропускается.
"""
import argparse
import json
import sys

import bot
import store as store_mod


def make_store(a):
    if a.store == "memory":
        return store_mod.MemoryStore()
    return store_mod.MongoStore(a.mongo_uri, a.db, a.collection)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("seeds", help="corpus.jsonl или список URL; '-' = stdin")
    ap.add_argument("--contact", required=True, help="e-mail для User-Agent")
    ap.add_argument("--mongo-uri", default="mongodb://localhost:27017")
    ap.add_argument("--db", default="ir")
    ap.add_argument("--collection", default="pages")
    ap.add_argument("--store", choices=["mongo", "memory"], default="mongo",
                    help="memory - пробный прогон без записи в БД")
    ap.add_argument("--agent", default="MAI-IR-bot/1.0")
    ap.add_argument("--delay", type=float, default=0.5, help="пауза между запросами к хосту, с")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--timeout", type=float, default=30)
    ap.add_argument("--retries", type=int, default=3)
    ap.add_argument("--max-bytes", type=int, default=10_000_000)
    ap.add_argument("--max-redirects", type=int, default=5)
    ap.add_argument("--limit", type=int, default=0, help="обработать не более N URL")
    ap.add_argument("--refresh", action="store_true",
                    help="перекачать уже сохранённые страницы условным GET (If-Modified-Since/ETag)")
    ap.add_argument("--progress-every", type=int, default=100)
    a = ap.parse_args()

    agent = "%s (+student lab; %s)" % (a.agent, a.contact)
    st = make_store(a)
    c = bot.Crawler(st, agent, delay=a.delay, workers=a.workers, timeout=a.timeout,
                        retries=a.retries, max_bytes=a.max_bytes, max_redirects=a.max_redirects,
                        refresh=a.refresh, progress_every=a.progress_every)
    f = sys.stdin if a.seeds == "-" else open(a.seeds, encoding="utf-8")
    with f:
        counts = c.run(bot.read_seeds(f, c.log), limit=a.limit)
    print(json.dumps({"processed": sum(counts.values()), "by_state": dict(counts),
                      "in_store": st.count()}, ensure_ascii=False), file=sys.stderr)


if __name__ == "__main__":
    main()
