import datetime
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
import bot
import store as store_mod
import urlnorm
from testsite import Site

AG = "MAI-IR-bot/1.0 (test)"


def items(base, *paths):
    return [{"url": urlnorm.normalize(base + p), "source_id": i, "title": "T%d" % i}
            for i, p in enumerate(paths, 1)]


class CrawlerTests(unittest.TestCase):
    def setUp(self):
        self.site = Site()
        self.store = store_mod.MemoryStore()

    def tearDown(self):
        self.site.stop()

    def crawler(self, **kw):
        kw.setdefault("delay", 0)
        kw.setdefault("workers", 3)
        kw.setdefault("timeout", 5)
        kw.setdefault("backoff", 0.01)
        kw.setdefault("progress_every", 0)
        return bot.Crawler(self.store, AG, log=lambda m: None, **kw)

    def doc(self, path):
        return self.store.docs[urlnorm.url_id(urlnorm.normalize(self.site.base + path))]

    def run_paths(self, *paths, **kw):
        return self.crawler(**kw).run(items(self.site.base, *paths))

    # ---- сохранение ----
    def test_ok_page_saved_as_raw_bytes_with_metadata(self):
        self.run_paths("/ok1")
        d = self.doc("/ok1")
        self.assertEqual(d["state"], "ok")
        self.assertEqual(d["status"], 200)
        self.assertIsInstance(d["html"], bytes)
        self.assertEqual(d["html"], ("<html><head><title>T</title></head><body>страница /ok1</body></html>").encode())
        self.assertEqual((d["charset"], d["size"], d["source_id"], d["title"]), ("utf-8", len(d["html"]), 1, "T1"))
        self.assertIsInstance(d["fetched_at"], datetime.datetime)

    def test_gzip_saved_decompressed(self):
        self.run_paths("/gz")
        self.assertIn(b"gzip", self.doc("/gz")["html"])

    def test_cp1251_bytes_kept_raw_and_charset_detected(self):
        self.run_paths("/cp1251")
        d = self.doc("/cp1251")
        self.assertEqual(d["charset"], "cp1251")
        self.assertIn("привет", d["html"].decode(d["charset"]))

    def test_id_is_hash_of_normalized_url(self):
        self.run_paths("/ok1")
        self.assertEqual(list(self.store.docs), [urlnorm.url_id(urlnorm.normalize(self.site.base + "/ok1"))])

    # ---- редиректы ----
    def test_redirect_followed_and_chain_recorded(self):
        self.run_paths("/r1", "/r-abs")
        d = self.doc("/r1")
        self.assertEqual((d["state"], d["final_url"]), ("ok", self.site.base + "/ok-target"))
        self.assertEqual(d["redirects"], [self.site.base + "/ok-target"])
        self.assertEqual(self.doc("/r-abs")["final_url"], self.site.base + "/ok-abs")   # без якоря

    def test_redirect_loop_and_too_many_redirects(self):
        self.run_paths("/loop1", "/chain/0", max_redirects=3)
        self.assertEqual(self.doc("/loop1")["state"], "redirect_error")
        self.assertIn("loop", self.doc("/loop1")["error"])
        self.assertIn("too many", self.doc("/chain/0")["error"])

    # ---- ошибки ----
    def test_404_is_recorded_not_retried(self):
        self.run_paths("/missing")
        d = self.doc("/missing")
        self.assertEqual((d["state"], d["status"], "html" in d), ("http_error", 404, False))
        self.assertEqual(len(self.site.hits("/missing")), 1)

    def test_503_is_retried_until_success(self):
        self.run_paths("/flaky", retries=3)
        d = self.doc("/flaky")
        self.assertEqual((d["state"], d["attempts"]), ("ok", 3))

    def test_persistent_503_gives_up_after_retries(self):
        self.run_paths("/always503", retries=2)
        self.assertEqual(self.doc("/always503")["state"], "http_error")
        self.assertEqual(len(self.site.hits("/always503")), 3)

    def test_429_retry_after_slows_host_and_retries(self):
        t0 = time.monotonic()
        self.run_paths("/throttle")
        self.assertEqual(self.doc("/throttle")["state"], "ok")
        self.assertGreaterEqual(time.monotonic() - t0, 0.9)

    def test_connection_failure_state_network(self):
        import fetcher

        def fake(url, agent, timeout, max_bytes, extra):      # robots.txt нет, страница недоступна
            if url.endswith("/robots.txt"):
                return fetcher.FetchResult(url=url, status=404)
            return fetcher.FetchResult(url=url, status=0, error="URLError: refused")
        c = self.crawler(retries=1, fetch=fake)
        c.run([{"url": "http://h.example/x", "source_id": 1, "title": "t"}])
        d = next(iter(self.store.docs.values()))
        self.assertEqual((d["state"], d["status"], d["attempts"]), ("network", 0, 2))
        self.assertIn("refused", d["error"])

    def test_non_html_and_too_large_have_no_html(self):
        self.run_paths("/image", "/big", max_bytes=1000)
        self.assertEqual(self.doc("/image")["state"], "non_html")
        self.assertEqual(self.doc("/big")["state"], "too_large")
        self.assertNotIn("html", self.doc("/image"))
        self.assertNotIn("html", self.doc("/big"))

    # ---- robots.txt ----
    def test_robots_disallow_respected_and_not_requested(self):
        self.run_paths("/ok1", "/private/a")
        self.assertEqual(self.doc("/private/a")["state"], "robots")
        self.assertEqual(self.site.hits("/private/a"), [])
        self.assertEqual(self.doc("/ok1")["state"], "ok")

    def test_robots_fetched_once_per_host(self):
        self.run_paths("/ok1", "/ok2", "/ok3", "/ok4", "/ok5")
        self.assertEqual(len(self.site.hits("/robots.txt")), 1)

    def test_robots_404_allows_everything(self):
        self.site.robots_status = 404
        self.run_paths("/private/a")
        self.assertEqual(self.doc("/private/a")["state"], "ok")

    def test_robots_5xx_disallows_everything(self):
        self.site.robots_status = 503
        self.run_paths("/ok1")
        self.assertEqual(self.doc("/ok1")["state"], "robots_unavailable")
        self.assertEqual(self.site.hits("/ok1"), [])

    def test_robots_unavailable_is_retried_on_next_run_unlike_explicit_disallow(self):
        self.site.robots_status = 503
        self.run_paths("/ok1", "/private/a")
        self.site.robots_status = 200
        self.run_paths("/ok1", "/private/a")
        self.assertEqual(self.doc("/ok1")["state"], "ok")             # robots.txt появился - скачали
        self.assertEqual(self.doc("/private/a")["state"], "robots")   # явный запрет остаётся

    def test_robots_rules_for_our_agent_token(self):
        self.site.robots = "User-agent: *\nDisallow: /\n\nUser-agent: MAI-IR-bot\nAllow: /\n"
        self.run_paths("/ok1")
        self.assertEqual(self.doc("/ok1")["state"], "ok")

    def test_crawl_delay_from_robots_is_honored(self):
        self.site.robots = "User-agent: *\nCrawl-delay: 1\n"
        self.run_paths("/ok1", "/ok2")
        a, b = sorted(self.site.hits("/ok1") + self.site.hits("/ok2"))
        self.assertGreaterEqual(b - a, 0.95)

    # ---- вежливость ----
    def test_per_host_delay_enforced_across_threads(self):
        self.run_paths("/ok1", "/ok2", "/ok3", "/ok4", workers=4, delay=0.2)
        ts = sorted(t for t, p, _ in self.site.log if p.startswith("/ok"))
        gaps = [b - a for a, b in zip(ts, ts[1:])]
        self.assertTrue(all(g >= 0.17 for g in gaps), gaps)

    def test_host_limiter_unit(self):
        sleeps, now = [], [0.0]
        lim = bot.HostLimiter(1.0, clock=lambda: now[0], sleep=sleeps.append)
        lim.wait("a"); lim.wait("a"); lim.wait("b")
        self.assertEqual(sleeps, [1.0])          # второй запрос к 'a' ждёт, 'b' не ждёт
        lim.penalize("a", 5)
        lim.wait("a")
        self.assertEqual(sleeps[-1], 5.0)

    # ---- возобновление и обновление ----
    def test_resume_skips_terminal_and_retries_failures(self):
        self.run_paths("/ok1", "/missing", "/always503", retries=0)
        n_ok, n_missing = len(self.site.hits("/ok1")), len(self.site.hits("/missing"))
        self.run_paths("/ok1", "/missing", "/always503", retries=0)
        self.assertEqual(len(self.site.hits("/ok1")), n_ok)           # ok - пропущен
        self.assertEqual(len(self.site.hits("/missing")), n_missing)  # 404 - окончательный
        self.assertEqual(len(self.site.hits("/always503")), 2)        # 5xx - пробуем снова

    def test_limit(self):
        c = self.crawler()
        c.run(items(self.site.base, "/ok1", "/ok2", "/ok3"), limit=2)
        self.assertEqual(len(self.store.docs), 2)

    def test_refresh_uses_conditional_get_and_keeps_html(self):
        self.run_paths("/etag")
        before = self.doc("/etag")["fetched_at"]
        time.sleep(0.01)
        counts = self.run_paths("/etag", refresh=True)
        self.assertEqual(counts["not_modified"], 1)
        last = self.site.log[-1][2]
        self.assertEqual(last["If-None-Match"], '"v1"')
        self.assertIn("If-Modified-Since", last)
        d = self.doc("/etag")
        self.assertIn(b"etag", d["html"])
        self.assertGreater(d["fetched_at"], before)

    def test_refresh_ignores_urls_not_yet_stored(self):
        self.run_paths("/ok1", refresh=True)
        self.assertEqual(len(self.store.docs), 0)

    def test_worker_survives_store_failure(self):
        class Boom(store_mod.MemoryStore):
            def put(self, doc):
                if doc["url"].endswith("/ok1"):
                    raise RuntimeError("db down")
                super().put(doc)
        self.store = Boom()
        counts = self.run_paths("/ok1", "/ok2")
        self.assertEqual(counts["internal_error"], 1)
        self.assertEqual(self.doc("/ok2")["state"], "ok")


class SeedsTests(unittest.TestCase):
    def test_corpus_jsonl_and_plain_urls(self):
        lines = ['{"id": 7, "title": "Москва", "url": "https://ru.wikipedia.org/wiki/Москва", "text": "x"}',
                 "https://example.org/a#frag", "", "mailto:x@y.ru", "{oops"]
        logs = []
        got = list(bot.read_seeds(lines, logs.append))
        self.assertEqual([g["url"] for g in got],
                         ["https://ru.wikipedia.org/wiki/%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0",
                          "https://example.org/a"])
        self.assertEqual((got[0]["source_id"], got[0]["title"]), (7, "Москва"))
        self.assertEqual(len(logs), 2)


class CliTests(unittest.TestCase):
    def test_cli_memory_store_dry_run_from_corpus_file(self):
        site = Site()
        try:
            with tempfile.TemporaryDirectory() as d:
                p = os.path.join(d, "corpus.jsonl")
                with open(p, "w", encoding="utf-8") as f:
                    for i in range(1, 4):
                        f.write(json.dumps({"id": i, "title": "T", "url": site.base + "/ok%d" % i,
                                            "text": "x"}) + "\n")
                root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
                r = subprocess.run([sys.executable, os.path.join(root, "crawl.py"), p,
                                    "--store", "memory", "--contact", "t@e.org", "--delay", "0",
                                    "--progress-every", "0"], capture_output=True, text=True,
                                   encoding="utf-8")
                self.assertEqual(r.returncode, 0, r.stderr)
                summary = json.loads(r.stderr.strip().splitlines()[-1])
                self.assertEqual(summary["by_state"], {"ok": 3})
                ua = site.log[-1][2]["User-Agent"]
                self.assertTrue(ua.startswith("MAI-IR-bot/1.0") and "t@e.org" in ua)
        finally:
            site.stop()


if __name__ == "__main__":
    unittest.main()
