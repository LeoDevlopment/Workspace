import os
import socket
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
import fetcher
import urlnorm
from testsite import Site

AG = "MAI-IR-bot/1.0 (test)"


class UrlNormTests(unittest.TestCase):
    BASE = "https://site.com/path/page.html"

    def test_slide_11_resolution_rules(self):
        n = urlnorm.normalize
        self.assertEqual(n("http://wikipedia.org", self.BASE), "http://wikipedia.org/")
        self.assertEqual(n("//cdn.org/jquery.js", self.BASE), "https://cdn.org/jquery.js")
        self.assertEqual(n("/admin/index.html", self.BASE), "https://site.com/admin/index.html")
        self.assertEqual(n("another.html", self.BASE), "https://site.com/path/another.html")
        self.assertEqual(n("?full=1", self.BASE), "https://site.com/path/page.html?full=1")
        self.assertEqual(n("#chapter2", self.BASE), "https://site.com/path/page.html")

    def test_case_default_port_fragment(self):
        self.assertEqual(urlnorm.normalize("HTTPS://Site.COM:443/a#x"), "https://site.com/a")
        self.assertEqual(urlnorm.normalize("http://site.com:8080/a"), "http://site.com:8080/a")
        self.assertEqual(urlnorm.normalize("http://site.com"), "http://site.com/")

    def test_cyrillic_path_and_idna_host(self):
        self.assertEqual(urlnorm.normalize("https://ru.wikipedia.org/wiki/Москва"),
                         "https://ru.wikipedia.org/wiki/%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0")
        self.assertEqual(urlnorm.normalize("http://пример.рф/"), "http://xn--e1afmkfd.xn--p1ai/")

    def test_equivalent_urls_get_same_id(self):
        a = urlnorm.normalize("https://ru.wikipedia.org/wiki/Москва")
        b = urlnorm.normalize("https://RU.wikipedia.org:443/wiki/%d0%9c%D0%BE%D1%81%D0%BA%D0%B2%D0%B0#top")
        self.assertEqual(urlnorm.url_id(a), urlnorm.url_id(b))

    def test_query_kept_and_reserved_chars_stay_encoded(self):
        self.assertEqual(urlnorm.normalize("http://a.ru/x?q=1&r=2"), "http://a.ru/x?q=1&r=2")
        self.assertEqual(urlnorm.normalize("http://a.ru/a%3Fb%23c"), "http://a.ru/a%3Fb%23c")

    def test_rejects_non_http_and_garbage(self):
        for bad in ("mailto:a@b.ru", "javascript:void(0)", "ftp://a.ru/x", "", "http://", "http://a.ru:99999999/"):
            self.assertIsNone(urlnorm.normalize(bad), bad)

    def test_path_query(self):
        self.assertEqual(urlnorm.path_query("http://a.ru/x?y=1"), "/x?y=1")
        self.assertEqual(urlnorm.path_query("http://a.ru"), "/")


class CharsetTests(unittest.TestCase):
    def test_header_wins(self):
        self.assertEqual(fetcher.detect_charset("text/html; charset=KOI8-R", b"<meta charset=utf-8>"), "koi8-r")

    def test_meta_variants(self):
        self.assertEqual(fetcher.detect_charset("text/html", b'<meta charset="windows-1251">'), "cp1251")
        body = b'<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">'
        self.assertEqual(fetcher.detect_charset("text/html", body), "cp1251")

    def test_default_utf8_and_unknown_codec(self):
        self.assertEqual(fetcher.detect_charset(None, b"<html>"), "utf-8")
        self.assertEqual(fetcher.detect_charset("text/html; charset=nonsense", b"x"), "utf-8")

    def test_bad_header_falls_through_to_meta(self):
        self.assertEqual(fetcher.detect_charset("text/html; charset=nonsense", b"<meta charset=cp1251>"), "cp1251")

    def test_is_html(self):
        self.assertTrue(fetcher.is_html("text/html; charset=utf-8"))
        self.assertTrue(fetcher.is_html("Application/XHTML+xml"))
        self.assertFalse(fetcher.is_html("image/png"))
        self.assertFalse(fetcher.is_html(None))


class DecodeBodyTests(unittest.TestCase):
    def test_gzip_zlib_raw_deflate_identity(self):
        import gzip, zlib
        data = b"hello " * 10
        self.assertEqual(fetcher.decode_body(gzip.compress(data), "gzip", 1000), (data, False))
        self.assertEqual(fetcher.decode_body(zlib.compress(data), "deflate", 1000), (data, False))
        raw = zlib.compressobj(wbits=-15)
        rawdata = raw.compress(data) + raw.flush()
        self.assertEqual(fetcher.decode_body(rawdata, "deflate", 1000), (data, False))
        self.assertEqual(fetcher.decode_body(data, None, 1000), (data, False))

    def test_decompression_bomb_is_capped(self):
        import gzip
        bomb = gzip.compress(b"\0" * 5_000_000)
        out, too_big = fetcher.decode_body(bomb, "gzip", 1000)
        self.assertTrue(too_big)
        self.assertEqual(len(out), 1000)

    def test_unknown_encoding_raises(self):
        with self.assertRaises(ValueError):
            fetcher.decode_body(b"x", "br", 10)


class FetchOnceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.site = Site()

    @classmethod
    def tearDownClass(cls):
        cls.site.stop()

    def get(self, path, **kw):
        return fetcher.fetch_once(self.site.base + path, AG, timeout=5, **kw)

    def test_plain_ok_and_user_agent_sent(self):
        r = self.get("/ok")
        self.assertEqual(r.status, 200)
        self.assertIn("страница".encode(), r.body)
        self.assertEqual(self.site.log[-1][2]["User-Agent"], AG)

    def test_gzip_and_deflate_are_decoded(self):
        self.assertIn(b"gzip", self.get("/gz").body)
        self.assertIn(b"deflate", self.get("/deflate").body)

    def test_redirect_is_not_followed(self):
        r = self.get("/r1")
        self.assertEqual(r.status, 302)
        self.assertEqual(r.headers["location"], "/ok-target")

    def test_404_returns_status_and_body(self):
        r = self.get("/missing")
        self.assertEqual((r.status, r.body), (404, b"no"))

    def test_conditional_headers_passed(self):
        r = self.get("/etag", extra={"If-None-Match": '"v1"'})
        self.assertEqual((r.status, r.body), (304, b""))

    def test_size_limit(self):
        r = self.get("/big", max_bytes=1000)
        self.assertTrue(r.too_large)
        self.assertEqual(r.body, b"")

    def test_connection_refused_gives_status_zero(self):
        s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
        r = fetcher.fetch_once("http://127.0.0.1:%d/" % port, AG, timeout=2)
        self.assertEqual(r.status, 0)
        self.assertTrue(r.error)

    def test_invalid_url_does_not_raise(self):
        self.assertEqual(fetcher.fetch_once("http://127.0.0.1:99999999/", AG, timeout=1).status, 0)


if __name__ == "__main__":
    unittest.main()
