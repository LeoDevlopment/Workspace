"""Локальный тестовый сайт: имитирует поведение реальных серверов (редиректы, gzip, 503 и т.д.)."""
import gzip
import http.server
import threading
import time
import zlib

HTML = "<html><head><title>T</title></head><body>%s</body></html>"


class Site:
    def __init__(self):
        self.log = []                       # (время, путь, заголовки)
        self.robots = "User-agent: *\nDisallow: /private/\n"
        self.robots_status = 200
        self.counters = {}
        site = self

        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def reply(self, status, body=b"", headers=None):
                self.send_response(status)
                for k, v in (headers or {}).items():
                    self.send_header(k, v)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):
                path = self.path
                site.log.append((time.monotonic(), path, dict(self.headers)))
                n = site.counters[path] = site.counters.get(path, 0) + 1
                html = {"Content-Type": "text/html; charset=utf-8"}
                if path == "/robots.txt":
                    return self.reply(site.robots_status, site.robots.encode(),
                                      {"Content-Type": "text/plain"})
                if path.startswith("/ok"):
                    return self.reply(200, (HTML % ("страница " + path)).encode(), html)
                if path.startswith("/private/"):
                    return self.reply(200, (HTML % "секрет").encode(), html)
                if path == "/gz":
                    return self.reply(200, gzip.compress((HTML % "gzip").encode()),
                                      dict(html, **{"Content-Encoding": "gzip"}))
                if path == "/deflate":
                    return self.reply(200, zlib.compress((HTML % "deflate").encode()),
                                      dict(html, **{"Content-Encoding": "deflate"}))
                if path == "/cp1251":
                    body = ('<html><head><meta http-equiv="Content-Type" content="text/html; '
                            'charset=windows-1251"></head><body>привет</body></html>').encode("cp1251")
                    return self.reply(200, body, {"Content-Type": "text/html"})
                if path == "/r1":
                    return self.reply(302, headers={"Location": "/ok-target"})
                if path == "/r-abs":
                    return self.reply(301, headers={"Location": "/ok-abs#frag"})
                if path == "/loop1":
                    return self.reply(302, headers={"Location": "/loop2"})
                if path == "/loop2":
                    return self.reply(302, headers={"Location": "/loop1"})
                if path.startswith("/chain/"):
                    k = int(path.split("/")[2])
                    return self.reply(302, headers={"Location": "/chain/%d" % (k + 1)})
                if path == "/missing":
                    return self.reply(404, b"no", html)
                if path == "/flaky":
                    if n <= 2:
                        return self.reply(503, b"busy", html)
                    return self.reply(200, (HTML % "flaky ok").encode(), html)
                if path == "/always503":
                    return self.reply(503, b"busy", html)
                if path == "/throttle":
                    if n == 1:
                        return self.reply(429, b"slow", dict(html, **{"Retry-After": "1"}))
                    return self.reply(200, (HTML % "after 429").encode(), html)
                if path == "/image":
                    return self.reply(200, b"\x89PNG....", {"Content-Type": "image/png"})
                if path == "/big":
                    return self.reply(200, b"x" * 5000, html)
                if path == "/etag":
                    if self.headers.get("If-None-Match") == '"v1"':
                        return self.reply(304, headers={"ETag": '"v1"'})
                    return self.reply(200, (HTML % "etag").encode(),
                                      dict(html, ETag='"v1"',
                                           **{"Last-Modified": "Fri, 24 Jul 2015 22:53:05 GMT"}))
                return self.reply(404, b"unknown", html)

        self.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.srv.daemon_threads = True
        self.base = "http://127.0.0.1:%d" % self.srv.server_port
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def hits(self, path):
        return [t for t, p, _ in self.log if p == path]

    def stop(self):
        self.srv.shutdown()
        self.srv.server_close()
