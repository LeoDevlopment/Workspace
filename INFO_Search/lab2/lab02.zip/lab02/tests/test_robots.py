import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from robots import Robots

SLIDE = "User-agent: *\nAllow: /article*\nDisallow: /auth*\nClean-param: s /forum/showthread.php\nCrawl-delay: 30\nSitemap: https://solo.nabiraem.ru/sitemap.xml\n"
AG = "MAI-IR-bot"


class RobotsTests(unittest.TestCase):
    def test_slide_41_example(self):
        r = Robots(SLIDE, AG)
        got = {p: r.allowed(p) for p in ["/", "/auth/", "/auth/article/", "/article/", "/post/"]}
        self.assertEqual(got, {"/": True, "/auth/": False, "/auth/article/": False,
                               "/article/": True, "/post/": True})

    def test_crawl_delay_and_sitemap(self):
        r = Robots(SLIDE, AG)
        self.assertEqual(r.crawl_delay, 30.0)
        self.assertEqual(r.sitemaps, ["https://solo.nabiraem.ru/sitemap.xml"])

    def test_empty_means_allow_all(self):
        self.assertTrue(Robots("", AG).allowed("/anything"))
        self.assertTrue(Robots.allow_all().allowed("/x"))

    def test_disallow_all(self):
        r = Robots.disallow_all()
        self.assertFalse(r.allowed("/x"))
        self.assertTrue(r.allowed("/robots.txt"))

    def test_empty_disallow_allows_everything(self):
        self.assertTrue(Robots("User-agent: *\nDisallow:", AG).allowed("/x"))

    def test_longest_match_wins(self):
        r = Robots("User-agent: *\nDisallow: /a/\nAllow: /a/public/", AG)
        self.assertFalse(r.allowed("/a/secret"))
        self.assertTrue(r.allowed("/a/public/x"))

    def test_tie_goes_to_allow(self):
        r = Robots("User-agent: *\nDisallow: /x\nAllow: /x", AG)
        self.assertTrue(r.allowed("/x"))

    def test_wildcard_in_middle_and_dollar(self):
        r = Robots("User-agent: *\nDisallow: /*.pdf$\nDisallow: /tmp*/draft", AG)
        self.assertFalse(r.allowed("/doc/file.pdf"))
        self.assertTrue(r.allowed("/doc/file.pdf?x=1"))
        self.assertTrue(r.allowed("/doc/file.pdfx"))
        self.assertFalse(r.allowed("/tmp123/draft/a"))

    def test_query_part_is_matched(self):
        r = Robots("User-agent: *\nDisallow: /*?sort=", AG)
        self.assertFalse(r.allowed("/list?sort=asc"))
        self.assertTrue(r.allowed("/list"))

    def test_specific_agent_group_beats_star(self):
        txt = "User-agent: *\nDisallow: /\n\nUser-agent: mai-ir-bot\nDisallow: /private/\n"
        r = Robots(txt, "MAI-IR-bot")
        self.assertTrue(r.allowed("/public"))
        self.assertFalse(r.allowed("/private/x"))
        self.assertFalse(Robots(txt, "OtherBot").allowed("/public"))

    def test_several_agents_share_one_group(self):
        txt = "User-agent: foo\nUser-agent: mai-ir-bot\nDisallow: /x\n"
        self.assertFalse(Robots(txt, AG).allowed("/x"))

    def test_no_matching_group_allows_all(self):
        self.assertTrue(Robots("User-agent: foo\nDisallow: /", AG).allowed("/x"))

    def test_comments_crlf_bom_case_insensitive_keys(self):
        txt = "\ufeffUSER-AGENT: *  # все\r\nDISALLOW: /a # комментарий\r\n"
        r = Robots(txt, AG)
        self.assertFalse(r.allowed("/a/b"))
        self.assertTrue(r.allowed("/b"))

    def test_rules_before_any_user_agent_ignored(self):
        self.assertTrue(Robots("Disallow: /\nUser-agent: *\nAllow: /", AG).allowed("/x"))

    def test_garbage_lines_are_ignored(self):
        r = Robots("<html>404</html>\nnonsense\nUser-agent: *\nDisallow: /a", AG)
        self.assertFalse(r.allowed("/a"))
        self.assertTrue(r.allowed("/b"))

    def test_bad_crawl_delay_ignored(self):
        self.assertIsNone(Robots("User-agent: *\nCrawl-delay: abc", AG).crawl_delay)

    def test_percent_encoding_equivalence(self):
        r = Robots("User-agent: *\nDisallow: /wiki/Служебная:", AG)
        self.assertFalse(r.allowed("/wiki/%D0%A1%D0%BB%D1%83%D0%B6%D0%B5%D0%B1%D0%BD%D0%B0%D1%8F:Search"))
        r = Robots("User-agent: *\nDisallow: /wiki/%D0%A1", AG)
        self.assertFalse(r.allowed("/wiki/Сталин"))

    def test_robots_txt_itself_always_allowed(self):
        self.assertTrue(Robots("User-agent: *\nDisallow: /", AG).allowed("/robots.txt"))


if __name__ == "__main__":
    unittest.main()
