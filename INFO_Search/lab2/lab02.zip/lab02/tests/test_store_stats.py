import datetime
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import crawl_stats
import store as store_mod


class FakeCollection:
    """Минимальная имитация pymongo.Collection: ровно те методы, что вызывает MongoStore."""

    def __init__(self):
        self.docs, self.indexes = {}, []

    def create_index(self, field):
        self.indexes.append(field)

    @staticmethod
    def _project(doc, proj):
        if not proj:
            return dict(doc)
        if all(v == 0 for v in proj.values()):
            return {k: v for k, v in doc.items() if k not in proj}
        return {k: v for k, v in doc.items() if k == "_id" or proj.get(k)}

    def _match(self, flt):
        for d in self.docs.values():
            ok = True
            for k, cond in flt.items():
                if isinstance(cond, dict) and "$in" in cond:
                    ok &= d.get(k) in cond["$in"]
                else:
                    ok &= d.get(k) == cond
            if ok:
                yield d

    def find(self, flt, proj=None):
        return (self._project(d, proj) for d in list(self._match(flt)))

    def find_one(self, flt, proj=None):
        return next(self.find(flt, proj), None)

    def replace_one(self, flt, doc, upsert=False):
        assert upsert and flt == {"_id": doc["_id"]}
        self.docs[doc["_id"]] = dict(doc)

    def update_one(self, flt, upd):
        for d in self._match(flt):
            d.update(upd["$set"])

    def count_documents(self, flt):
        return len(list(self._match(flt)))


def mk(i, state="ok", status=200, size=100, **kw):
    d = {"_id": "id%d" % i, "url": "http://x/%d" % i, "state": state, "status": status,
         "html": b"<html>", "size": size, "charset": "utf-8", "content_type": "text/html; charset=utf-8",
         "fetch_ms": 10, "attempts": 1, "redirects": [], "error": None,
         "fetched_at": datetime.datetime(2026, 1, 1, 0, 0, i, tzinfo=datetime.timezone.utc)}
    d.update(kw)
    return d


class MongoStoreTests(unittest.TestCase):
    def setUp(self):
        self.col = FakeCollection()
        self.s = store_mod.MongoStore(collection_obj=self.col)

    def test_indexes_created(self):
        self.assertEqual(set(self.col.indexes), {"state", "fetched_at", "source_id"})

    def test_put_upsert_replaces_and_keeps_bytes(self):
        self.s.put(mk(1))
        self.s.put(mk(1, state="http_error", status=404))
        self.assertEqual(self.s.count(), 1)
        self.assertEqual(self.col.docs["id1"]["state"], "http_error")
        self.s.put(mk(2))
        self.assertIsInstance(self.col.docs["id2"]["html"], bytes)

    def test_existing_returns_state_and_status_only_for_known_ids(self):
        self.s.put(mk(1)); self.s.put(mk(2, state="http_error", status=503))
        self.assertEqual(self.s.existing(["id1", "id2", "id3"]),
                         {"id1": ("ok", 200), "id2": ("http_error", 503)})

    def test_get_and_iter_meta_exclude_html(self):
        self.s.put(mk(1))
        self.assertNotIn("html", self.s.get("id1"))
        self.assertIsNone(self.s.get("nope"))
        self.assertTrue(all("html" not in d for d in self.s.iter_meta()))

    def test_touch_updates_fetched_at_only(self):
        self.s.put(mk(1))
        when = datetime.datetime(2030, 1, 1, tzinfo=datetime.timezone.utc)
        self.s.touch("id1", when)
        self.assertEqual(self.col.docs["id1"]["fetched_at"], when)
        self.assertEqual(self.col.docs["id1"]["state"], "ok")


class TerminalTests(unittest.TestCase):
    def test_terminal_rules(self):
        t = store_mod.is_terminal
        for st, code in [("ok", 200), ("robots", 0), ("non_html", 200), ("too_large", 200),
                         ("empty", 200), ("http_error", 404), ("http_error", 410)]:
            self.assertTrue(t(st, code), (st, code))
        for st, code in [("network", 0), ("robots_unavailable", 0), ("redirect_error", 302),
                         ("http_error", 503), ("http_error", 429), ("http_error", 408)]:
            self.assertFalse(t(st, code), (st, code))


class StatsTests(unittest.TestCase):
    def test_compute(self):
        docs = [mk(1, size=100), mk(2, size=300, charset="cp1251", redirects=["x"]),
                mk(3, state="http_error", status=404, error="HTTP 404", fetch_ms=30, attempts=2),
                mk(4, state="robots", status=0, error="disallowed")]
        for d in docs:
            d.pop("html")
        st = crawl_stats.compute(iter(docs))
        self.assertEqual(st["docs"], 4)
        self.assertEqual(st["by_state"], {"ok": 2, "http_error": 1, "robots": 1})
        self.assertEqual(st["by_status"], {"0": 1, "200": 2, "404": 1})
        self.assertEqual((st["ok_docs"], st["html_bytes_total"], st["html_bytes_avg"]), (2, 400, 200.0))
        self.assertEqual(st["html_bytes_max"], 300)
        self.assertEqual(st["charsets"], {"utf-8": 1, "cp1251": 1})
        self.assertEqual(st["redirected_docs"], 1)
        self.assertEqual(st["attempts_avg"], 1.25)
        self.assertIn("HTTP 404", st["top_errors"])
        self.assertTrue(st["first_fetched_at"] < st["last_fetched_at"])

    def test_empty_collection(self):
        st = crawl_stats.compute(iter([]))
        self.assertEqual((st["docs"], st["ok_docs"], st["html_bytes_avg"]), (0, 0, 0))


@unittest.skipUnless(os.environ.get("MONGO_URI"), "задайте MONGO_URI для интеграционного теста")
class RealMongoTests(unittest.TestCase):
    def test_roundtrip_against_real_mongodb(self):
        s = store_mod.MongoStore(os.environ["MONGO_URI"], "ir_test", "pages_test")
        s.col.drop()
        s = store_mod.MongoStore(os.environ["MONGO_URI"], "ir_test", "pages_test")
        s.put(mk(1))
        self.assertEqual(s.existing(["id1"]), {"id1": ("ok", 200)})
        self.assertEqual(s.col.find_one({"_id": "id1"})["html"], b"<html>")
        self.assertNotIn("html", s.get("id1"))
        s.col.drop()


if __name__ == "__main__":
    unittest.main()
