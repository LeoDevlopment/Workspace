#!/usr/bin/env bash
# Полный конвейер: обкачка -> статистика -> отчёт.
# Использование: ./run_all.sh /путь/к/corpus.jsonl you@example.org "Иванов И. И." "М8О-101Б-23" "Тема корпуса" [лимит]
set -euo pipefail
cd "$(dirname "$0")"
CORPUS=${1:?corpus.jsonl}; CONTACT=${2:?e-mail}; STUDENT=${3:?ФИО}; GROUP=${4:?группа}
CATEGORY=${5:?тема корпуса}; LIMIT=${6:-0}
MONGO_URI=${MONGO_URI:-mongodb://localhost:27017}
mkdir -p data
python3 crawl.py "$CORPUS" --contact "$CONTACT" --mongo-uri "$MONGO_URI" --limit "$LIMIT"
python3 crawl_stats.py --mongo-uri "$MONGO_URI" -o data/stats.json
python3 make_report.py --stats data/stats.json --student "$STUDENT" --group "$GROUP" --category "$CATEGORY"
./build_report.sh
