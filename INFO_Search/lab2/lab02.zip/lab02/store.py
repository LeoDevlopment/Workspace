"""Хранилище страниц: MongoDB (основное) и память (для тестов и пробного прогона).

Документ страницы:
  _id            sha1 от нормализованного URL (произвольный доступ по хешу, слайд 56)
  url            запрошенный нормализованный URL;  final_url - после редиректов
  source_id, title  идентификатор и заголовок из корпуса лабораторной №1
  state          ok | http_error | robots | robots_unavailable | network | non_html | too_large |
                 empty | redirect_error   (окончательные: см. TERMINAL; остальные повторяются)
  status         последний HTTP-статус (0 - ответа не было)
  html           сырые байты ответа после снятия gzip/deflate (BSON Binary); только при state=ok
  charset        кодировка, определённая по заголовку/<meta>/умолчанию
  size, content_type, content_encoding, last_modified, etag, redirects, error,
  attempts, fetch_ms, fetched_at (UTC)
"""
import threading

TERMINAL = {"ok", "robots", "non_html", "too_large", "empty"}


def is_terminal(state, status):
    """Нужно ли пропускать URL при повторном запуске."""
    return state in TERMINAL or (state == "http_error" and 400 <= status < 500
                                 and status not in (408, 429))


class MemoryStore:
    def __init__(self):
        self.docs, self._lock = {}, threading.Lock()

    def existing(self, ids):
        with self._lock:
            return {i: (self.docs[i].get("state"), self.docs[i].get("status", 0))
                    for i in ids if i in self.docs}

    def get(self, id_):
        with self._lock:
            d = self.docs.get(id_)
            return dict(d) if d else None

    def put(self, doc):
        with self._lock:
            self.docs[doc["_id"]] = dict(doc)

    def touch(self, id_, when):
        with self._lock:
            self.docs[id_]["fetched_at"] = when

    def count(self):
        return len(self.docs)

    def iter_meta(self):
        for d in list(self.docs.values()):
            yield {k: v for k, v in d.items() if k != "html"}


class MongoStore:
    def __init__(self, uri="mongodb://localhost:27017", db="ir", collection="pages",
                 collection_obj=None):
        if collection_obj is None:
            from pymongo import MongoClient      # импорт ленивый: тестам pymongo не нужен
            client = MongoClient(uri, serverSelectionTimeoutMS=10000)
            client.admin.command("ping")         # быстро упасть, если MongoDB недоступна
            collection_obj = client[db][collection]
        self.col = collection_obj
        for field in ("state", "fetched_at", "source_id"):
            self.col.create_index(field)

    def existing(self, ids):
        cur = self.col.find({"_id": {"$in": list(ids)}}, {"state": 1, "status": 1})
        return {d["_id"]: (d.get("state"), d.get("status", 0)) for d in cur}

    def get(self, id_):
        return self.col.find_one({"_id": id_}, {"html": 0})

    def put(self, doc):
        self.col.replace_one({"_id": doc["_id"]}, doc, upsert=True)

    def touch(self, id_, when):
        self.col.update_one({"_id": id_}, {"$set": {"fetched_at": when}})

    def count(self):
        return self.col.count_documents({})

    def iter_meta(self):
        return self.col.find({}, {"html": 0})
