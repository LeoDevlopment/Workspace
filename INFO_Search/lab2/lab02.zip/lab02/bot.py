"""Поисковый робот (модуль bot): очередь URL, вежливость по хостам, robots.txt, повторы, сохранение в БД."""
import collections
import datetime
import json
import queue
import sys
import threading
import time
import urllib.parse

import fetcher
import robots as robots_mod
import store as store_mod
import urlnorm


class HostLimiter:
    """Не чаще одного запроса к хосту за delay секунд при любом числе потоков."""

    def __init__(self, delay, clock=time.monotonic, sleep=time.sleep):
        self.delay, self.clock, self.sleep = delay, clock, sleep
        self._next, self._lock = {}, threading.Lock()

    def wait(self, host, delay=0.0):
        with self._lock:
            now = self.clock()
            start = max(now, self._next.get(host, 0.0))
            self._next[host] = start + max(self.delay, delay)
        if start > now:
            self.sleep(start - now)

    def penalize(self, host, seconds):
        with self._lock:
            self._next[host] = max(self._next.get(host, 0.0), self.clock() + seconds)


class RobotsCache:
    def __init__(self, crawler, ttl=3600, fail_ttl=300):
        self.c, self.ttl, self.fail_ttl = crawler, ttl, fail_ttl
        self._cache, self._locks, self._lock = {}, {}, threading.Lock()

    def get(self, url):
        p = urllib.parse.urlsplit(url)
        key = (p.scheme, p.netloc)
        with self._lock:
            lock = self._locks.setdefault(key, threading.Lock())
        with lock:                                   # один поток качает robots.txt хоста
            hit = self._cache.get(key)
            if hit and hit[1] > time.monotonic():
                return hit[0]
            rb, ttl = self._load(*key)
            self._cache[key] = (rb, time.monotonic() + ttl)
            return rb

    def _load(self, scheme, netloc):
        url = "%s://%s/robots.txt" % (scheme, netloc)
        res = None
        for _ in range(4):
            self.c.limiter.wait(urllib.parse.urlsplit(url).netloc)
            res = self.c.fetch(url, self.c.agent, self.c.timeout, 512 * 1024, None)
            loc = res.headers.get("location")
            if res.status in fetcher.REDIRECTS and loc:
                url = urlnorm.normalize(loc, base=url)
                if url:
                    continue
            break
        token = self.c.agent_token
        if res.status == 200:
            text = res.body.decode(fetcher.detect_charset(res.headers.get("content-type"), res.body),
                                   errors="replace")
            return robots_mod.Robots(text, token), self.ttl
        if 400 <= res.status < 500:                  # robots.txt нет: можно всё
            return robots_mod.Robots.allow_all(token), self.ttl
        rb = robots_mod.Robots.disallow_all(token)    # 5xx/сеть: пока не качаем, но и не помечаем навсегда
        rb.unavailable = True
        return rb, self.fail_ttl


class Crawler:
    def __init__(self, store, agent, delay=0.5, workers=4, timeout=30, retries=3, backoff=1.0,
                 max_bytes=10_000_000, max_redirects=5, refresh=False, respect_robots=True,
                 fetch=fetcher.fetch_once, log=None, progress_every=100):
        self.store, self.agent, self.workers = store, agent, workers
        self.agent_token = agent.split("/", 1)[0].split()[0]
        self.timeout, self.retries, self.backoff = timeout, retries, backoff
        self.max_bytes, self.max_redirects = max_bytes, max_redirects
        self.refresh, self.respect_robots, self.fetch = refresh, respect_robots, fetch
        self.limiter = HostLimiter(delay)
        self.robots = RobotsCache(self)
        self.log = log or (lambda m: print(m, file=sys.stderr, flush=True))
        self.progress_every = progress_every
        self.counts, self._clock_lock = collections.Counter(), threading.Lock()

    # ---------- один запрос с повторами ----------
    def _request(self, url, extra):
        netloc = urllib.parse.urlsplit(url).netloc
        for attempt in range(self.retries + 1):
            delay = self.robots.get(url).crawl_delay or 0.0 if self.respect_robots else 0.0
            self.limiter.wait(netloc, delay)
            res = self.fetch(url, self.agent, self.timeout, self.max_bytes, extra)
            res.attempts = attempt + 1
            if (res.status == 0 or res.status == 429 or res.status >= 500) and attempt < self.retries:
                ra = res.headers.get("retry-after", "")
                wait = min(int(ra), 60) if ra.isdigit() else min(self.backoff * 2 ** attempt, 60)
                if res.status in (429, 503):
                    self.limiter.penalize(netloc, wait)   # притормозить весь хост
                else:
                    time.sleep(wait)
                continue
            break
        return res

    # ---------- обработка одного URL ----------
    def process(self, item):
        url, uid = item["url"], urlnorm.url_id(item["url"])
        extra = {}
        if self.refresh:
            prev = self.store.get(uid)
            if prev and prev.get("state") == "ok":
                if prev.get("etag"):
                    extra["If-None-Match"] = prev["etag"]
                if prev.get("last_modified"):
                    extra["If-Modified-Since"] = prev["last_modified"]
        doc = {"_id": uid, "url": url, "source_id": item.get("source_id"),
               "title": item.get("title"), "redirects": [], "error": None, "attempts": 0}
        t0 = time.monotonic()
        cur, seen, res = url, {url}, None
        for hop in range(self.max_redirects + 1):
            rb = self.robots.get(cur) if self.respect_robots else None
            if rb is not None and not rb.allowed(urlnorm.path_query(cur)):
                if rb.unavailable:
                    return self._save(doc, "robots_unavailable", 0, t0,
                                      error="robots.txt недоступен: " + cur)
                return self._save(doc, "robots", 0, t0, error="disallowed by robots.txt: " + cur)
            res = self._request(cur, extra if hop == 0 else None)
            doc["attempts"] += res.attempts
            loc = res.headers.get("location")
            if res.status in fetcher.REDIRECTS and loc:
                nxt = urlnorm.normalize(loc, base=cur)
                if not nxt:
                    return self._save(doc, "redirect_error", res.status, t0, error="bad Location: " + loc)
                if nxt in seen:
                    return self._save(doc, "redirect_error", res.status, t0, error="redirect loop")
                seen.add(nxt)
                doc["redirects"].append(nxt)
                cur = nxt
                continue
            break
        else:
            return self._save(doc, "redirect_error", res.status, t0, error="too many redirects")

        doc["final_url"] = cur
        h = res.headers
        doc.update(content_type=h.get("content-type"), content_encoding=h.get("content-encoding"),
                   last_modified=h.get("last-modified"), etag=h.get("etag"))
        if res.status == 0:
            return self._save(doc, "network", 0, t0, error=res.error)
        if res.status == 304:
            self.store.touch(uid, datetime.datetime.now(datetime.timezone.utc))
            return "not_modified"
        if res.status >= 400:
            return self._save(doc, "http_error", res.status, t0, error="HTTP %d" % res.status)
        if res.too_large:
            return self._save(doc, "too_large", res.status, t0, error="body exceeds %d bytes" % self.max_bytes)
        if not res.body:
            return self._save(doc, "empty", res.status, t0)
        if not fetcher.is_html(h.get("content-type")):
            return self._save(doc, "non_html", res.status, t0)
        doc.update(html=res.body, size=len(res.body),
                   charset=fetcher.detect_charset(h.get("content-type"), res.body))
        return self._save(doc, "ok", res.status, t0)

    def _save(self, doc, state, status, t0, error=None):
        doc.update(state=state, status=status, fetch_ms=int((time.monotonic() - t0) * 1000),
                   fetched_at=datetime.datetime.now(datetime.timezone.utc))
        if error:
            doc["error"] = error
        self.store.put(doc)
        return state

    # ---------- очередь и потоки ----------
    def _worker(self, q):
        while True:
            item = q.get()
            if item is None:
                return
            try:
                state = self.process(item)
            except Exception as e:                    # баг или сбой БД: не роняем обход
                state = "internal_error"
                self.log("ошибка при обработке %s: %r" % (item["url"], e))
            with self._clock_lock:
                self.counts[state] += 1
                done = sum(self.counts.values())
                if self.progress_every and done % self.progress_every == 0:
                    rate = done / max(time.monotonic() - self._t0, 1e-9)
                    self.log("обработано %d (%.1f/с) %s" % (done, rate, dict(self.counts)))

    def _pending(self, items, limit):
        """Отбирает URL, которые надо обработать; опрашивает БД пачками."""
        chunk, taken = [], 0
        def flush():
            nonlocal taken
            known = self.store.existing([urlnorm.url_id(i["url"]) for i in chunk])
            for i in chunk:
                st = known.get(urlnorm.url_id(i["url"]))
                if st is None:
                    ok = not self.refresh                 # при обновлении новые URL не трогаем
                elif self.refresh:
                    ok = st[0] == "ok" or not store_mod.is_terminal(*st)
                else:
                    ok = not store_mod.is_terminal(*st)
                if ok and not (limit and taken >= limit):
                    taken += 1
                    yield i
            chunk.clear()
        for it in items:
            chunk.append(it)
            if len(chunk) >= 500:
                yield from flush()
            if limit and taken >= limit:
                return
        yield from flush()

    def run(self, items, limit=0):
        q = queue.Queue(maxsize=self.workers * 4)
        threads = [threading.Thread(target=self._worker, args=(q,), daemon=True)
                   for _ in range(self.workers)]
        self._t0 = time.monotonic()
        for t in threads:
            t.start()
        try:
            for item in self._pending(items, limit):
                q.put(item)
        except KeyboardInterrupt:
            self.log("прервано: дожидаюсь текущих запросов")
            try:
                while True:
                    q.get_nowait()
            except queue.Empty:
                pass
        for _ in threads:
            q.put(None)
        for t in threads:
            t.join()
        return self.counts


def read_seeds(lines, log=None):
    """Строки: JSON-объект с полем url (corpus.jsonl) или просто URL."""
    for line in lines:
        line = line.strip()
        if not line:
            continue
        item = {}
        if line.startswith("{"):
            try:
                rec = json.loads(line)
            except ValueError:
                if log:
                    log("пропущена битая строка: " + line[:80])
                continue
            item = {"source_id": rec.get("id"), "title": rec.get("title")}
            line = rec.get("url") or ""
        url = urlnorm.normalize(line)
        if not url:
            if log:
                log("пропущен некорректный URL: " + line[:80])
            continue
        item["url"] = url
        yield item
