# Лабораторная работа №2. Поисковый робот

Робот качает страницы по адресам из корпуса лабораторной №1 (`corpus.jsonl`, поле `url`) и сохраняет **сырой HTML** вместе с метаданными в MongoDB.

## Требования
- Python 3.9+; для обкачки и статистики: `pip install -r requirements.txt` (pymongo);
- MongoDB 5+ (локально: `docker compose up -d`, порт 27017 на localhost);
- для отчёта: `pandoc` и LibreOffice (`soffice`).
- Тесты (`./run_tests.sh`) не требуют ни интернета, ни MongoDB, ни pymongo.

## Быстрый старт
```
./run_tests.sh                       # автотесты, результат в tests_result.txt
docker compose up -d                 # MongoDB
./run_all.sh ../lab01/data/corpus.jsonl you@example.org "Иванов И. И." "М8О-101Б-23" "Тема корпуса" 200
```
Последний аргумент - лимит URL для пробного прогона; уберите его для полной обкачки.
Сначала сделайте пробный прогон без БД: `python3 crawl.py corpus.jsonl --contact you@example.org --store memory --limit 20`.

## Шаги по отдельности
```
python3 crawl.py corpus.jsonl --contact you@example.org [--delay 0.5] [--workers 4] [--limit N] [--refresh]
python3 crawl_stats.py -o data/stats.json
python3 make_report.py --stats data/stats.json --student "ФИО" --group "ГРУППА" --category "Тема"
./build_report.sh
```
Обкачку можно прерывать (Ctrl-C) и запускать снова: окончательно обработанные URL пропускаются, временные ошибки (сеть, 5xx, 429, недоступный `robots.txt`) повторяются. `--refresh` перепроверяет сохранённые страницы условным GET.

## Что лежит в MongoDB (база `ir`, коллекция `pages`)
Один документ на URL: `_id` (sha1 от нормализованного URL), `url`, `final_url`, `redirects`, `source_id`, `title`, `state`, `status`, `html` (байты), `charset`, `size`, `content_type`, `etag`, `last_modified`, `error`, `attempts`, `fetch_ms`, `fetched_at`. Подробности: docstring в `store.py`.

Примеры в `mongosh`:
```
use ir
db.pages.countDocuments({state: "ok"})
db.pages.aggregate([{$group: {_id: "$state", n: {$sum: 1}}}])
db.pages.findOne({state: "ok"}, {html: 0})
```
Прочитать HTML в Python: `doc["html"].decode(doc["charset"], errors="replace")`.

## Интеграционный тест с настоящей MongoDB
```
MONGO_URI=mongodb://localhost:27017 ./run_tests.sh
```
Тест пишет в отдельную базу `ir_test` и удаляет её коллекцию.

## Важно
- Робот соблюдает `robots.txt` и паузу между запросами к хосту; отключить это нельзя намеренно. По умолчанию 0,5 с на хост (около 2 запросов/с), для 30 тысяч страниц порядка 4–5 часов.
- В `User-Agent` попадает e-mail из `--contact`.
- Разделы «Журнал выполнения» и пометки ЗАПОЛНИТЬ в отчёте заполняются вручную по итогам реального прогона.
