"""Одиночный HTTP-запрос: без автоматических редиректов, с gzip/deflate и лимитом размера."""
import codecs
import http.client
import re
import time
import urllib.error
import urllib.request
import zlib
from dataclasses import dataclass, field

REDIRECTS = (301, 302, 303, 307, 308)
HTML_TYPES = ("text/html", "application/xhtml+xml")


@dataclass
class FetchResult:
    url: str
    status: int = 0                 # 0 - ответа нет (сеть, таймаут, ошибка декодирования)
    headers: dict = field(default_factory=dict)
    body: bytes = b""
    error: str = None
    too_large: bool = False
    elapsed_ms: int = 0
    attempts: int = 1


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None                  # 3xx приходят как HTTPError: ходим по ним сами


_OPENER = urllib.request.build_opener(_NoRedirect)


def decode_body(raw, encoding, limit):
    """Снимает Content-Encoding. Возвращает (данные, превышен_ли_лимит)."""
    enc = (encoding or "").lower().strip()
    if enc in ("", "identity"):
        data = raw
    elif enc in ("gzip", "x-gzip"):
        data = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(raw, limit + 1)
    elif enc == "deflate":
        try:
            data = zlib.decompressobj().decompress(raw, limit + 1)
        except zlib.error:
            data = zlib.decompressobj(-zlib.MAX_WBITS).decompress(raw, limit + 1)
    else:
        raise ValueError("unsupported content-encoding: " + enc)
    return data[:limit], len(data) > limit


def fetch_once(url, agent, timeout=30, max_bytes=10_000_000, extra=None):
    t0 = time.monotonic()
    headers = {"User-Agent": agent,
               "Accept": "text/html,application/xhtml+xml;q=0.9,*/*;q=0.1",
               "Accept-Encoding": "gzip, deflate"}
    headers.update(extra or {})
    res = FetchResult(url=url)
    resp = None
    try:
        try:
            resp = _OPENER.open(urllib.request.Request(url, headers=headers), timeout=timeout)
        except urllib.error.HTTPError as e:
            resp = e
        res.status = resp.getcode()
        res.headers = {k.lower(): v for k, v in resp.headers.items()}
        raw = resp.read(max_bytes + 1)
        if len(raw) > max_bytes:
            res.too_large = True
        else:
            res.body, res.too_large = decode_body(raw, res.headers.get("content-encoding"), max_bytes)
    except (zlib.error, ValueError) as e:
        res.status, res.body, res.error = 0, b"", "decode_error: %s" % e
    except (urllib.error.URLError, OSError, http.client.HTTPException) as e:
        res.status, res.body, res.error = 0, b"", "%s: %s" % (type(e).__name__, e)
    finally:
        if resp is not None:
            resp.close()
    res.elapsed_ms = int((time.monotonic() - t0) * 1000)
    return res


_HDR_CHARSET = re.compile(r"charset\s*=\s*[\"']?\s*([\w\-:.]+)", re.I)
_META_CHARSET = re.compile(rb"<meta[^>]+charset\s*=\s*[\"']?\s*([\w\-:.]+)", re.I)


def detect_charset(content_type, body):
    """Порядок как в браузерах (слайд 51): заголовок, затем <meta>, затем UTF-8."""
    cands = []
    m = _HDR_CHARSET.search(content_type or "")
    if m:
        cands.append(m.group(1))
    m = _META_CHARSET.search(body[:4096])
    if m:
        cands.append(m.group(1).decode("ascii", "ignore"))
    for c in cands:
        try:
            return codecs.lookup(c).name
        except LookupError:
            continue
    return "utf-8"


def is_html(content_type):
    return (content_type or "").split(";", 1)[0].strip().lower() in HTML_TYPES
