"""Разбор robots.txt: группы User-agent, Allow/Disallow с '*' и '$', Crawl-delay, Sitemap.

Приоритет правил: побеждает самое длинное подходящее правило, при равенстве - Allow
(так делают Google и Яндекс). Пустой Disallow ничего не запрещает.
"""
import re
import urllib.parse

_SAFE = "/*$?&=:;,@+!~'()-._%"


def canon(s):
    """Приводит путь/шаблон к единому виду: '%D0%90' и 'А' считаются одним и тем же."""
    return urllib.parse.quote(urllib.parse.unquote(s), safe=_SAFE.replace("%", ""))


def _compile(pattern):
    anchored = pattern.endswith("$")
    if anchored:
        pattern = pattern[:-1]
    rx = ".*".join(re.escape(part) for part in pattern.split("*"))
    return re.compile(rx + ("$" if anchored else ""))


class _Group:
    def __init__(self):
        self.agents = []
        self.rules = []          # (allow, длина шаблона, regex)
        self.crawl_delay = None


class Robots:
    def __init__(self, text, agent):
        """agent - имя нашего робота (без версии), например 'MAI-IR-bot'."""
        self.agent = agent.lower()
        self.unavailable = False        # True: robots.txt не удалось получить (временный запрет)
        self.sitemaps = []
        groups, cur, prev_was_agent = [], None, False
        for line in text.lstrip("\ufeff").splitlines():
            line = line.split("#", 1)[0].strip()
            if ":" not in line:
                continue
            key, value = (x.strip() for x in line.split(":", 1))
            key = key.lower()
            if key == "user-agent":
                if cur is None or not prev_was_agent:
                    cur = _Group()
                    groups.append(cur)
                cur.agents.append(value.lower())
                prev_was_agent = True
                continue
            prev_was_agent = False
            if key == "sitemap":
                self.sitemaps.append(value)
            elif cur is None:
                continue                      # правило до первого User-agent
            elif key in ("allow", "disallow"):
                if value:
                    pattern = canon(value)
                    cur.rules.append((key == "allow", len(pattern), _compile(pattern)))
            elif key == "crawl-delay":
                try:
                    d = float(value)
                    if d >= 0 and cur.crawl_delay is None:
                        cur.crawl_delay = d
                except ValueError:
                    pass
        self._rules, self.crawl_delay = self._select(groups)

    def _select(self, groups):
        best, best_len = [], -1
        for g in groups:                       # самая конкретная подходящая группа
            for token in g.agents:
                if token != "*" and token and token in self.agent:
                    if len(token) > best_len:
                        best, best_len = [g], len(token)
                    elif len(token) == best_len and g not in best:
                        best.append(g)
        if not best:
            best = [g for g in groups if "*" in g.agents]
        rules = [r for g in best for r in g.rules]
        delay = next((g.crawl_delay for g in best if g.crawl_delay is not None), None)
        return rules, delay

    def allowed(self, path):
        """path - путь с query, например '/auth/page?x=1'."""
        if path.split("?", 1)[0] == "/robots.txt":
            return True
        path = canon(path)
        best_len, verdict = -1, True
        for allow, length, rx in self._rules:
            if rx.match(path) and (length > best_len or (length == best_len and allow)):
                best_len, verdict = length, allow
        return verdict

    @classmethod
    def allow_all(cls, agent="*"):
        return cls("", agent)

    @classmethod
    def disallow_all(cls, agent="*"):
        return cls("User-agent: *\nDisallow: /", agent)
