#!/usr/bin/env python3
"""Подставляет статистику обкачки в report_template.md -> report.md."""
import argparse
import datetime
import json
import os
import string


def n(v):
    if isinstance(v, bool):
        return "да" if v else "нет"
    if isinstance(v, int):
        return "{:,}".format(v).replace(",", "\u00a0")
    if isinstance(v, float):
        return "{:,.1f}".format(v).replace(",", "\u00a0")
    return "н/д" if v is None else str(v)


def rows(d, empty="| (нет) | 0 |"):
    return "\n".join("| %s | %s |" % (k, n(v)) for k, v in d.items()) or empty


def human(seconds):
    s = int(seconds)
    return "%d ч %d мин %d с" % (s // 3600, s % 3600 // 60, s % 60)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--stats", default="data/stats.json")
    ap.add_argument("--template", default=os.path.join(here, "report_template.md"))
    ap.add_argument("--student", required=True)
    ap.add_argument("--group", required=True)
    ap.add_argument("--category", default="ЗАПОЛНИТЬ (тема корпуса ЛР1)")
    ap.add_argument("--max-redirects", type=int, default=5)
    ap.add_argument("-o", "--output", default="report.md")
    a = ap.parse_args()

    st = json.load(open(a.stats, encoding="utf-8"))
    v = {k: n(x) for k, x in st.items() if not isinstance(x, (dict, list))}
    v.update(student=a.student, group=a.group, category=a.category,
             max_redirects=str(a.max_redirects))
    v["ok_share"] = "%.1f%%" % (100.0 * st["ok_docs"] / st["docs"]) if st["docs"] else "н/д"
    v["states_rows"] = rows(st["by_state"])
    v["status_rows"] = rows(st["by_status"])
    v["charset_rows"] = rows(st["charsets"])
    if st["top_errors"]:
        v["errors_block"] = "| Причина | Документов |\n|---|---|\n" + rows(st["top_errors"])
    else:
        v["errors_block"] = "Ошибок нет."
    v["duration"] = v["rate"] = "н/д"
    if st["first_fetched_at"] and st["last_fetched_at"]:
        sec = (datetime.datetime.fromisoformat(st["last_fetched_at"])
               - datetime.datetime.fromisoformat(st["first_fetched_at"])).total_seconds()
        v["duration"] = human(sec)
        if sec > 0:
            v["rate"] = "%.2f документов/с (%s в час)" % (st["docs"] / sec, n(st["docs"] / sec * 3600))
    with open(a.output, "w", encoding="utf-8") as f:
        f.write(string.Template(open(a.template, encoding="utf-8").read()).substitute(v))


if __name__ == "__main__":
    main()
