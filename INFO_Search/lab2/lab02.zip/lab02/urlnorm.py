"""Нормализация и разрешение URL (слайды 9-11 лекции)."""
import hashlib
import re
import urllib.parse

_DEFAULT_PORTS = {"http": 80, "https": 443}
_PATH_SAFE = "/:@!$&'()*+,;=-._~"


def normalize(url, base=None):
    """Абсолютный нормализованный URL или None (не http/https, битый адрес)."""
    try:
        if base:
            url = urllib.parse.urljoin(base, url.strip())
        p = urllib.parse.urlsplit(url.strip())
        scheme = p.scheme.lower()
        if scheme not in _DEFAULT_PORTS or not p.hostname:
            return None
        host = p.hostname.lower().encode("idna").decode("ascii")
        port = p.port
    except (ValueError, UnicodeError):
        return None
    netloc = host if port in (None, _DEFAULT_PORTS[scheme]) else "%s:%d" % (host, port)
    if ":" in host:                                   # IPv6
        netloc = "[%s]" % host if port in (None, _DEFAULT_PORTS[scheme]) else "[%s]:%d" % (host, port)
    path = urllib.parse.quote(urllib.parse.unquote(p.path or "/"), safe=_PATH_SAFE)
    query = re.sub(r"[^\x00-\x7f]", lambda m: urllib.parse.quote(m.group()), p.query)
    query = query.replace(" ", "%20")
    return urllib.parse.urlunsplit((scheme, netloc, path, query, ""))   # без якоря


def url_id(url):
    """Идентификатор документа в базе: хеш от нормализованного URL."""
    return hashlib.sha1(url.encode("utf-8")).hexdigest()


def path_query(url):
    p = urllib.parse.urlsplit(url)
    return (p.path or "/") + ("?" + p.query if p.query else "")
