#!/usr/bin/env python3
"""Статистика обкачки по содержимому MongoDB -> JSON."""
import argparse
import collections
import json
import statistics

import store as store_mod


def compute(meta_iter):
    states, statuses = collections.Counter(), collections.Counter()
    charsets, ctypes, errors = collections.Counter(), collections.Counter(), collections.Counter()
    sizes, fetch_ms, attempts = [], [], []
    redirected = n = 0
    first = last = None
    for d in meta_iter:
        n += 1
        states[d.get("state")] += 1
        statuses[d.get("status", 0)] += 1
        if d.get("redirects"):
            redirected += 1
        if d.get("error") and d.get("state") != "ok":
            errors[str(d["error"])[:60]] += 1
        if d.get("state") == "ok":
            sizes.append(d.get("size", 0))
            charsets[d.get("charset")] += 1
            ctypes[(d.get("content_type") or "").split(";")[0].strip()] += 1
        fetch_ms.append(d.get("fetch_ms", 0))
        attempts.append(d.get("attempts", 1))
        t = d.get("fetched_at")
        if t is not None:
            first = t if first is None or t < first else first
            last = t if last is None or t > last else last
    s = sorted(sizes)
    return {
        "docs": n,
        "by_state": dict(states),
        "by_status": {str(k): v for k, v in sorted(statuses.items())},
        "ok_docs": len(sizes),
        "html_bytes_total": sum(sizes),
        "html_bytes_avg": round(sum(sizes) / len(sizes), 1) if sizes else 0,
        "html_bytes_median": statistics.median(sizes) if sizes else 0,
        "html_bytes_p90": s[int(0.9 * (len(s) - 1))] if s else 0,
        "html_bytes_max": s[-1] if s else 0,
        "charsets": dict(charsets.most_common()),
        "content_types": dict(ctypes.most_common()),
        "redirected_docs": redirected,
        "fetch_ms_avg": round(sum(fetch_ms) / n, 1) if n else 0,
        "attempts_avg": round(sum(attempts) / n, 3) if n else 0,
        "first_fetched_at": first.isoformat() if first else None,
        "last_fetched_at": last.isoformat() if last else None,
        "top_errors": dict(errors.most_common(10)),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--mongo-uri", default="mongodb://localhost:27017")
    ap.add_argument("--db", default="ir")
    ap.add_argument("--collection", default="pages")
    ap.add_argument("-o", "--output", default="-")
    a = ap.parse_args()
    out = json.dumps(compute(store_mod.MongoStore(a.mongo_uri, a.db, a.collection).iter_meta()),
                     ensure_ascii=False, indent=2)
    if a.output == "-":
        print(out)
    else:
        open(a.output, "w", encoding="utf-8").write(out + "\n")


if __name__ == "__main__":
    main()
