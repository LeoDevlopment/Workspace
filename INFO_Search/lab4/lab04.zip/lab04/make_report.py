#!/usr/bin/env python3
import argparse, json
from pathlib import Path

def esc(s):
    return str(s).replace("|", r"\|").replace("\n"," ")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stats",default="data/stats.json")
    ap.add_argument("--student",required=True)
    ap.add_argument("--group",required=True)
    ap.add_argument("--category",required=True)
    ap.add_argument("--input",default="")
    ap.add_argument("--template",default="report_template.md")
    args=ap.parse_args()
    root=Path(__file__).resolve().parent
    stats=json.loads((root/args.stats).read_text(encoding="utf-8"))
    for key in ("original","lemma","stem"):
        timing_path=root/"data"/f"{key}_timing.json"
        if timing_path.exists():
            stats[key]["seconds"]=json.loads(timing_path.read_text(encoding="utf-8")).get("seconds",0)
        else:
            stats[key]["seconds"]=stats[key].get("seconds",0)
    (root/"data"/"stats.json").write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding="utf-8")
    rows=["| Метод | Токенов | Уникальных терминов | Снижение словаря | Hapax | Время, с |",
          "|---|---:|---:|---:|---:|---:|"]
    for key,label in (("original","Исходный корпус"),("lemma","Лемматизация"),("stem","Стемминг")):
        d=stats[key]
        rows.append(f"| {label} | {d['tokens']} | {d['vocabulary']} | {d.get('vocabulary_reduction_pct',0):.2f}% | {d['hapax']} | {d['seconds']:.3f} |")
    ex_path=root/"data"/"examples.tsv"
    examples=["| Исходный токен | Лемма | Стем | Частота |","|---|---|---|---:|"]
    if ex_path.exists():
        for line in ex_path.read_text(encoding="utf-8").splitlines()[1:16]:
            parts=line.split("\t")
            if len(parts)==4: examples.append("| "+" | ".join(esc(x) for x in parts)+" |")
    if len(examples)==2: examples.append("| Нет данных | — | — | — |")
    template=(root/args.template).read_text(encoding="utf-8")
    replacements={
        "${student}":args.student,"${group}":args.group,"${category}":args.category,
        "${results_table}":"\n".join(rows),
        "${vocab_plot}":"vocab_reduction.png",
        "${examples_table}":"\n".join(examples),
    }
    for key,value in replacements.items(): template=template.replace(key,value)
    (root/"data"/"report.md").write_text(template,encoding="utf-8")
    print("Отчёт Markdown создан: data/report.md")
if __name__=="__main__": main()
