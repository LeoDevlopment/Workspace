#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 4 ]]; then
  echo "Использование: $0 TOKENS.txt \"ФИО\" \"ГРУППА\" \"ТЕМА КОРПУСА\"" >&2
  exit 2
fi
INPUT="$1"; STUDENT="$2"; GROUP="$3"; CATEGORY="$4"
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
python3 -c 'import pymorphy3, nltk, matplotlib' 2>/dev/null || {
  echo "Установите зависимости: python3 -m pip install -r requirements.txt" >&2; exit 2;
}
mkdir -p data
python3 normalize.py "$INPUT" --mode lemma --output data/lemmas.txt --stats-json data/lemma_timing.json
python3 normalize.py "$INPUT" --mode stem --output data/stems.txt --stats-json data/stem_timing.json
python3 analyze.py "$INPUT" data/lemmas.txt data/stems.txt --outdir data > data/analysis_stdout.json
python3 make_report.py --stats data/stats.json --student "$STUDENT" --group "$GROUP" --category "$CATEGORY" --input "$INPUT"
if command -v pandoc >/dev/null 2>&1 && command -v soffice >/dev/null 2>&1; then
  ./build_report.sh
else
  echo "pandoc/soffice не найдены: report.md создан; для DOCX/PDF установите их." >&2
fi
