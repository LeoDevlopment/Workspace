#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
python3 -m unittest discover -s tests -v 2>&1 | tee tests_result.txt
status=${PIPESTATUS[0]}
exit "$status"
