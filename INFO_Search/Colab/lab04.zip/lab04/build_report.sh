#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
pandoc data/report.md -o data/report.docx
soffice --headless --convert-to pdf --outdir data data/report.docx >/dev/null
