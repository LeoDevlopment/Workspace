#!/usr/bin/env python3
"""Compare original tokens, lemmas and stems; create stats and charts."""
import argparse, collections, json, math, time
from pathlib import Path

def read_tokens(path):
    with open(path, encoding="utf-8") as f:
        for line in f:
            token = line.strip()
            if token:
                yield token

def write_vocab(counter, path):
    with open(path, "w", encoding="utf-8") as f:
        for word, freq in sorted(counter.items(), key=lambda x: (-x[1], x[0])):
            f.write(f"{word}\t{freq}\n")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("original"); ap.add_argument("lemmas"); ap.add_argument("stems")
    ap.add_argument("--outdir", default="data")
    args=ap.parse_args()
    out=Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    counters={}
    elapsed={}
    for name,path in (("original",args.original),("lemma",args.lemmas),("stem",args.stems)):
        started=time.perf_counter()
        c=collections.Counter(read_tokens(path))
        elapsed[name]=time.perf_counter()-started
        counters[name]=c
        write_vocab(c, out/f"vocab_{name if name != 'original' else 'original'}.tsv")
    total=sum(counters["original"].values())
    if total != sum(counters["lemma"].values()) or total != sum(counters["stem"].values()):
        raise SystemExit("Ошибка: число токенов изменилось после нормализации")
    def summary(c):
        return {"tokens":sum(c.values()),"vocabulary":len(c),
                "hapax":sum(1 for n in c.values() if n==1),
                "top_terms":[{"term":w,"frequency":n} for w,n in c.most_common(20)]}
    stats={"original":summary(counters["original"]),
           "lemma":summary(counters["lemma"]),
           "stem":summary(counters["stem"])}
    for name in stats:
        stats[name]["analysis_seconds"]=elapsed[name]
        timing_file=out/f"{name}_timing.json"
        stats[name]["seconds"]=json.loads(timing_file.read_text(encoding="utf-8")).get("seconds",0) if timing_file.exists() else elapsed[name]
    base=max(1,stats["original"]["vocabulary"])
    for name in ("lemma","stem"):
        stats[name]["vocabulary_reduction_pct"]=100*(1-stats[name]["vocabulary"]/base)
    # Deterministic examples: most frequent original forms, then alphabetical tie-break.
    examples=[]
    for word,_ in sorted(counters["original"].items(), key=lambda x:(-x[1],x[0]))[:200]:
        examples.append(word)
    with open(out/"examples.tsv","w",encoding="utf-8") as f:
        f.write("token\tlemma\tstem\tfrequency\n")
        # Outputs are aligned line-by-line; map observed normalized outputs by original stream.
        lemma_iter=iter(read_tokens(args.lemmas)); stem_iter=iter(read_tokens(args.stems))
        exset=set(examples)
        seen={}
        for token in read_tokens(args.original):
            lemma=next(lemma_iter); stem=next(stem_iter)
            if token in exset and token not in seen:
                seen[token]=(lemma,stem,counters["original"][token])
        for token in examples:
            if token in seen:
                lemma,stem,freq=seen[token]
                f.write(f"{token}\t{lemma}\t{stem}\t{freq}\n")
    with open(out/"stats.json","w",encoding="utf-8") as f:
        json.dump(stats,f,ensure_ascii=False,indent=2)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        labels=["Исходные токены","Лемматизация","Стемминг"]
        vals=[stats["original"]["vocabulary"],stats["lemma"]["vocabulary"],stats["stem"]["vocabulary"]]
        plt.figure(figsize=(8,4.5)); plt.bar(labels,vals); plt.ylabel("Число уникальных терминов")
        plt.title("Размер словаря до и после нормализации"); plt.tight_layout()
        plt.savefig(out/"vocab_reduction.png",dpi=150); plt.close()
        times=[stats["original"]["seconds"],stats["lemma"]["seconds"],stats["stem"]["seconds"]]
        plt.figure(figsize=(8,4.5)); plt.bar(labels,times); plt.ylabel("Время, секунды")
        plt.title("Время подсчёта/нормализации токенов"); plt.tight_layout()
        plt.savefig(out/"time_comparison.png",dpi=150); plt.close()
    except ImportError:
        pass
    print(json.dumps(stats,ensure_ascii=False,indent=2))
if __name__=="__main__": main()
