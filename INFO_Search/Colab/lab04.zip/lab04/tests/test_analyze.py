import json, tempfile, unittest, subprocess, sys
from pathlib import Path

class AnalyzeTests(unittest.TestCase):
    def test_vocab_and_reduction(self):
        script=Path(__file__).resolve().parents[1]/"analyze.py"
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)
            (p/"orig").write_text("кот\nкоты\nкот\n",encoding="utf-8")
            (p/"lem").write_text("кот\nкот\nкот\n",encoding="utf-8")
            (p/"stem").write_text("кот\nкот\nкот\n",encoding="utf-8")
            subprocess.run([sys.executable,str(script),"orig","lem","stem","--outdir","out"],cwd=p,check=True,stdout=subprocess.PIPE)
            stats=json.loads((p/"out"/"stats.json").read_text(encoding="utf-8"))
            self.assertEqual(stats["original"]["tokens"],3)
            self.assertEqual(stats["original"]["vocabulary"],2)
            self.assertEqual(stats["lemma"]["vocabulary_reduction_pct"],50.0)
            self.assertTrue((p/"out"/"vocab_lemma.tsv").exists())
if __name__=="__main__": unittest.main()
