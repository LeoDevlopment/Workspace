import io, unittest
from unittest.mock import patch
import normalize

class FakeParse:
    def __init__(self, normal_form): self.normal_form=normal_form
class FakeMorph:
    def parse(self, token):
        mapping={"машины":"машина","кошками":"кошка","бежали":"бежать"}
        return [FakeParse(mapping.get(token,token))]

class NormalizeTests(unittest.TestCase):
    def test_stream_skips_empty_lines_and_preserves_count(self):
        source=io.StringIO("машины\n\nкошками\n")
        target=io.StringIO()
        result=normalize.normalize_stream(source,target,str.upper)
        self.assertEqual(target.getvalue(),"МАШИНЫ\nКОШКАМИ\n")
        self.assertEqual(result["tokens"],2)
    def test_lemma_processor_with_fake_analyzer(self):
        with patch.dict("sys.modules", {"pymorphy3": type("M",(),{"MorphAnalyzer":lambda self: FakeMorph()})()}):
            processor=normalize.make_processor("lemma")
        self.assertEqual(processor("машины"),"машина")
        self.assertEqual(processor("NASA"),"nasa")
    def test_russian_stemmer(self):
        processor=normalize.make_processor("stem")
        self.assertEqual(processor("МАШИНА"),processor("машина"))
        self.assertTrue(processor("машинами").startswith("машин"))
    def test_unknown_mode(self):
        with self.assertRaises(ValueError): normalize.make_processor("bad")
if __name__=="__main__": unittest.main()
