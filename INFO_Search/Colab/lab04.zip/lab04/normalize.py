#!/usr/bin/env python3
"""Stream tokens through Russian lemmatization or stemming."""
import argparse
import sys
import time
from pathlib import Path

def make_processor(mode):
    if mode == "lemma":
        try:
            import pymorphy3
        except ImportError as exc:
            raise RuntimeError("Для лемматизации установите зависимости: pip install -r requirements.txt") from exc
        morph = pymorphy3.MorphAnalyzer()
        def process(token):
            # Токены ЛР3 уже нормализованы по регистру. Не-кириллические токены
            # сохраняем в нижнем регистре, не пытаясь морфологически разбирать.
            if not any('\u0400' <= ch <= '\u052f' for ch in token):
                return token.lower()
            return morph.parse(token.lower())[0].normal_form
        return process
    if mode == "stem":
        try:
            from nltk.stem.snowball import SnowballStemmer
        except ImportError as exc:
            raise RuntimeError("Для стемминга установите зависимости: pip install -r requirements.txt") from exc
        stemmer = SnowballStemmer("russian")
        def process(token):
            if not any('\u0400' <= ch <= '\u052f' for ch in token):
                return token.lower()
            return stemmer.stem(token.lower())
        return process
    raise ValueError(f"Неизвестный режим: {mode}")

def normalize_stream(source, target, processor):
    count = 0
    started = time.perf_counter()
    for line in source:
        token = line.strip()
        if not token:
            continue
        target.write(processor(token) + "\n")
        count += 1
    target.flush()
    return {"tokens": count, "seconds": time.perf_counter() - started}

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", default="-", help="файл с токенами по одному на строку; '-' — stdin")
    parser.add_argument("--mode", choices=("lemma", "stem"), required=True)
    parser.add_argument("--output", default="-", help="выходной файл; '-' — stdout")
    parser.add_argument("--stats-json", help="необязательный JSON-файл со временем и числом токенов")
    args = parser.parse_args(argv)
    try:
        processor = make_processor(args.mode)
        with (open(args.input, encoding="utf-8") if args.input != "-" else sys.stdin) as source:
            if args.output == "-":
                result = normalize_stream(source, sys.stdout, processor)
            else:
                Path(args.output).parent.mkdir(parents=True, exist_ok=True)
                with open(args.output, "w", encoding="utf-8") as target:
                    result = normalize_stream(source, target, processor)
        if args.stats_json:
            import json
            Path(args.stats_json).parent.mkdir(parents=True, exist_ok=True)
            with open(args.stats_json, "w", encoding="utf-8") as f:
                json.dump({"mode": args.mode, **result}, f, ensure_ascii=False, indent=2)
        print(f"mode={args.mode} tokens={result['tokens']} seconds={result['seconds']:.6f}", file=sys.stderr)
        return 0
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        return 2

if __name__ == "__main__":
    raise SystemExit(main())
