#!/usr/bin/env python3
"""Статистика корпуса (corpus.jsonl, опционально raw.jsonl) -> JSON.

Токен здесь - максимальная последовательность букв/цифр (\\w+), в нижнем регистре.
Это грубая оценка для описания корпуса, а не токенизатор следующих работ.
Потоковая обработка; в памяти держатся только счётчики и длины документов.
"""
import argparse
import collections
import json
import re
import statistics
import sys

TOKEN = re.compile(r"\w+")
BUCKETS = [(0, 100), (100, 500), (500, 1000), (1000, 3000), (3000, 10000), (10000, None)]


def share(text, pattern):
    return len(re.sub(pattern, "", text))


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("corpus")
    ap.add_argument("--raw", help="raw.jsonl: для оценки доли разметки")
    ap.add_argument("--top", type=int, default=30)
    ap.add_argument("--min-docs", type=int, default=30000)
    ap.add_argument("-o", "--output", default="-")
    a = ap.parse_args()

    lens, counter = [], collections.Counter()
    text_bytes = chars = cyr = lat = dig = 0
    tok_chars = 0
    with open(a.corpus, encoding="utf-8") as f:
        for line in f:
            text = json.loads(line)["text"]
            toks = TOKEN.findall(text.lower())
            lens.append(len(toks))
            counter.update(toks)
            tok_chars += sum(map(len, toks))
            text_bytes += len(text.encode("utf-8"))
            chars += len(text)
            cyr += share(text, r"[^А-Яа-яЁё]")
            lat += share(text, r"[^A-Za-z]")
            dig += share(text, r"[^0-9]")
    n, total = len(lens), sum(lens)

    raw_bytes = raw_docs = None
    if a.raw:
        raw_bytes = raw_docs = 0
        with open(a.raw, encoding="utf-8") as f:
            for line in f:
                try:
                    raw_bytes += len(json.loads(line)["wikitext"].encode("utf-8"))
                    raw_docs += 1
                except (ValueError, KeyError):
                    pass

    hist = []
    for lo, hi in BUCKETS:
        c = sum(1 for x in lens if x >= lo and (hi is None or x < hi))
        hist.append({"from": lo, "to": hi, "docs": c})
    lens_sorted = sorted(lens)
    stats = {
        "docs": n,
        "tokens": total,
        "unique_tokens": len(counter),
        "text_bytes": text_bytes,
        "chars": chars,
        "avg_tokens_per_doc": round(total / n, 1) if n else 0,
        "median_tokens_per_doc": statistics.median(lens) if n else 0,
        "p90_tokens_per_doc": lens_sorted[int(0.9 * (n - 1))] if n else 0,
        "min_tokens": lens_sorted[0] if n else 0,
        "max_tokens": lens_sorted[-1] if n else 0,
        "avg_token_chars": round(tok_chars / total, 2) if total else 0,
        "avg_bytes_per_token": round(text_bytes / total, 2) if total else 0,
        "share_cyrillic_letters": round(cyr / chars, 4) if chars else 0,
        "share_latin_letters": round(lat / chars, 4) if chars else 0,
        "share_digits": round(dig / chars, 4) if chars else 0,
        "length_histogram": hist,
        "top_tokens": counter.most_common(a.top),
        "raw_docs": raw_docs,
        "raw_bytes": raw_bytes,
        "markup_removed_ratio": (round(1 - text_bytes / raw_bytes, 4)
                                 if raw_bytes else None),
        "requirements": {"min_docs": a.min_docs, "docs_ok": n >= a.min_docs},
    }
    out = json.dumps(stats, ensure_ascii=False, indent=2)
    if a.output == "-":
        print(out)
    else:
        with open(a.output, "w", encoding="utf-8") as f:
            f.write(out + "\n")


if __name__ == "__main__":
    main()
