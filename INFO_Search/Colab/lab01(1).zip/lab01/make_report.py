#!/usr/bin/env python3
"""Подставляет статистику в report_template.md -> report.md."""
import argparse
import json
import os
import string


def fmt(v):
    if isinstance(v, bool):
        return "выполнено" if v else "НЕ выполнено"
    if isinstance(v, int):
        return "{:,}".format(v).replace(",", "\u00a0")
    if isinstance(v, float):
        return ("%.4g" % v) if v < 1 else "{:,.1f}".format(v).replace(",", "\u00a0")
    return "н/д" if v is None else str(v)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--stats", default="data/stats.json")
    ap.add_argument("--meta", default="data/fetch_meta.json")
    ap.add_argument("--template", default=os.path.join(here, "report_template.md"))
    ap.add_argument("--student", required=True)
    ap.add_argument("--group", required=True)
    ap.add_argument("--min-chars", type=int, default=200)
    ap.add_argument("-o", "--output", default="report.md")
    a = ap.parse_args()

    st = json.load(open(a.stats, encoding="utf-8"))
    meta = json.load(open(a.meta, encoding="utf-8")) if os.path.exists(a.meta) else {}
    vals = {k: fmt(v) for k, v in st.items() if not isinstance(v, (list, dict))}
    vals["docs_ok"] = fmt(st["requirements"]["docs_ok"])
    vals["min_docs"] = fmt(st["requirements"]["min_docs"])
    ratio = st.get("markup_removed_ratio")
    vals["markup_removed_ratio"] = "н/д" if ratio is None else "%.1f%%" % (ratio * 100)
    for k in ("share_cyrillic_letters", "share_latin_letters", "share_digits"):
        vals[k] = "%.1f%%" % (st[k] * 100)
    rows = ["| Токенов в документе | Документов | Доля |", "|---|---|---|"]
    for b in st["length_histogram"]:
        rng = ("%d и более" % b["from"]) if b["to"] is None else "%d–%d" % (b["from"], b["to"] - 1)
        share = 100.0 * b["docs"] / st["docs"] if st["docs"] else 0
        rows.append("| %s | %s | %.1f%% |" % (rng, fmt(b["docs"]), share))
    vals["hist_table"] = "\n".join(rows)
    rows = ["| № | Токен | Вхождений |", "|---|---|---|"]
    for i, (tok, c) in enumerate(st["top_tokens"], 1):
        rows.append("| %d | %s | %s |" % (i, tok, fmt(c)) )
    vals["top_table"] = "\n".join(rows)
    category = meta.get("category", "ЗАПОЛНИТЬ")
    vals["category"] = category.split(":", 1)[-1]
    vals["depth"] = str(meta.get("depth", "ЗАПОЛНИТЬ"))
    vals["student"], vals["group"] = a.student, a.group
    vals["min_chars"] = str(a.min_chars)

    tpl = string.Template(open(a.template, encoding="utf-8").read())
    with open(a.output, "w", encoding="utf-8") as f:
        f.write(tpl.substitute(vals))


if __name__ == "__main__":
    main()
