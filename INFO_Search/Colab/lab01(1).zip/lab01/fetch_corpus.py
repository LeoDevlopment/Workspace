#!/usr/bin/env python3
"""Добыча корпуса: категория Википедии -> titles.tsv + raw.jsonl (исходный викитекст).

Этапы: (1) обход категории в ширину, (2) пакетная загрузка викитекста.
Оба этапа возобновляемы: повторный запуск докачивает недостающее.
"""
import argparse
import datetime
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

CAT_PREFIXES = ("category:", "категория:")


class Api:
    def __init__(self, base, contact, delay):
        self.base, self.delay = base, delay
        self.ua = "MAI-IR-lab01/1.0 (student corpus crawler; %s)" % contact

    def call(self, params, retries=6):
        q = dict(params, format="json", formatversion="2", maxlag="5")
        url = self.base + "?" + urllib.parse.urlencode(q)
        for attempt in range(retries):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": self.ua})
                with urllib.request.urlopen(req, timeout=60) as r:
                    data = json.load(r)
            except (urllib.error.URLError, TimeoutError, ValueError):
                time.sleep(min(2 ** attempt, 30))
                continue
            err = data.get("error")
            if err:
                if err.get("code") == "maxlag":
                    time.sleep(5)
                    continue
                raise RuntimeError("API error: %r" % (err,))
            time.sleep(self.delay)
            return data
        raise RuntimeError("API недоступен: " + url)


def list_category(api, category, depth, limit):
    """Обход категории в ширину. Возвращает [(pageid, title)] без дубликатов."""
    seen_cats, pages = {category}, {}
    queue = [(category, 0)]
    while queue:
        cat, d = queue.pop(0)
        cont = {}
        while True:
            data = api.call(dict({
                "action": "query", "list": "categorymembers", "cmtitle": cat,
                "cmtype": "page|subcat", "cmlimit": "500"}, **cont))
            for m in data["query"]["categorymembers"]:
                if m["ns"] == 14:
                    if d < depth and m["title"] not in seen_cats:
                        seen_cats.add(m["title"])
                        queue.append((m["title"], d + 1))
                elif m["ns"] == 0 and m["pageid"] not in pages:
                    pages[m["pageid"]] = m["title"]
                    if limit and len(pages) >= limit:
                        return list(pages.items())
            if "continue" not in data:
                break
            cont = data["continue"]
        print("категорий в очереди: %d, статей найдено: %d" % (len(queue), len(pages)),
              file=sys.stderr)
    return list(pages.items())


def fetch_batch(api, ids):
    data = api.call({
        "action": "query", "pageids": "|".join(map(str, ids)),
        "prop": "revisions", "rvprop": "ids|timestamp|content", "rvslots": "main"})
    for p in data["query"]["pages"]:
        if p.get("missing") or not p.get("revisions"):
            continue
        rev = p["revisions"][0]
        yield {"id": p["pageid"], "title": p["title"], "revid": rev["revid"],
               "timestamp": rev["timestamp"], "wikitext": rev["slots"]["main"]["content"]}


def load_done(path):
    done = set()
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for line in f:
                try:
                    done.add(json.loads(line)["id"])
                except (ValueError, KeyError):
                    pass  # оборванная последняя строка
    return done


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("category", help="например: Категория:Авиация")
    ap.add_argument("--out", default="data", help="каталог результатов")
    ap.add_argument("--api", default="https://ru.wikipedia.org/w/api.php")
    ap.add_argument("--contact", required=True,
                    help="e-mail для User-Agent (требование политики Википедии)")
    ap.add_argument("--depth", type=int, default=3, help="глубина подкатегорий")
    ap.add_argument("--limit", type=int, default=0, help="макс. число статей (0 - без лимита)")
    ap.add_argument("--batch", type=int, default=50, help="статей в одном запросе (<=50)")
    ap.add_argument("--delay", type=float, default=0.3, help="пауза между запросами, с")
    ap.add_argument("--refresh-titles", action="store_true", help="заново обойти категорию")
    a = ap.parse_args()

    cat = a.category.strip()
    if not cat.lower().startswith(CAT_PREFIXES):
        cat = "Категория:" + cat
    os.makedirs(a.out, exist_ok=True)
    titles_path = os.path.join(a.out, "titles.tsv")
    raw_path = os.path.join(a.out, "raw.jsonl")
    api = Api(a.api, a.contact, a.delay)

    if os.path.exists(titles_path) and not a.refresh_titles:
        with open(titles_path, encoding="utf-8") as f:
            pages = [(int(i), t) for i, t in (l.rstrip("\n").split("\t", 1) for l in f if l.strip())]
    else:
        pages = list_category(api, cat, a.depth, a.limit)
        tmp = titles_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            for pid, title in pages:
                f.write("%d\t%s\n" % (pid, title))
        os.replace(tmp, titles_path)

    done = load_done(raw_path)
    todo = [pid for pid, _ in pages if pid not in done]
    print("всего: %d, уже скачано: %d, осталось: %d" % (len(pages), len(done), len(todo)),
          file=sys.stderr)
    step = max(1, min(a.batch, 50))
    with open(raw_path, "a", encoding="utf-8") as out:
        for i in range(0, len(todo), step):
            for rec in fetch_batch(api, todo[i:i + step]):
                out.write(json.dumps(rec, ensure_ascii=False) + "\n")
            out.flush()
            print("скачано %d/%d" % (min(i + step, len(todo)), len(todo)), file=sys.stderr)

    with open(os.path.join(a.out, "fetch_meta.json"), "w", encoding="utf-8") as f:
        json.dump({"category": cat, "api": a.api, "depth": a.depth,
                   "pages_listed": len(pages), "finished_utc":
                   datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")},
                  f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
