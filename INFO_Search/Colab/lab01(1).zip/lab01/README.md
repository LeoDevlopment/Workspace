# Лабораторная работа №1. Добыча корпуса документов

Конвейер: категория Википедии -> викитекст (`raw.jsonl`) -> чистый текст (`corpus.jsonl`) -> статистика (`stats.json`) -> отчёт (`report.docx`, `report.pdf`).

## Требования
- Python 3.9+ (только стандартная библиотека), доступ в интернет для этапа скачивания;
- для сборки отчёта: `pandoc` и LibreOffice (`soffice`).
- Кодировка всех входных и выходных файлов: UTF-8.

## Быстрый старт
```
./run_tests.sh                       # автотесты (интернет не нужен), результат в tests_result.txt
./run_all.sh "Категория:ВАША_ТЕМА" you@example.org "Иванов И. И." "М8О-101Б-23"
```
Для пробы на небольшом объёме добавьте пятым аргументом лимит статей, например `200`.

## Шаги по отдельности
```
python3 fetch_corpus.py "Категория:ТЕМА" --out data --contact you@example.org [--depth 3] [--limit N]
python3 extract_text.py data/raw.jsonl -o data/corpus.jsonl [--split-dir data/docs] [--min-chars 200]
python3 corpus_stats.py data/corpus.jsonl --raw data/raw.jsonl -o data/stats.json
python3 make_report.py --stats data/stats.json --meta data/fetch_meta.json --student "ФИО" --group "ГРУППА"
./build_report.sh
```
Скачивание можно прерывать и запускать повторно: недостающее докачивается.

## Формат корпуса
`corpus.jsonl`: одна строка - один документ `{"id", "title", "url", "text"}`. С флагом `--split-dir` дополнительно создаётся `<id>.txt` на документ.

## Важно
- Тема корпуса должна быть уникальной в рамках групп: согласуйте её с преподавателем до скачивания.
- Раздел «Журнал выполнения» и пункт 5.5 отчёта заполняются вручную по итогам реального прогона (пометки ЗАПОЛНИТЬ).
