#!/usr/bin/env python3
"""raw.jsonl (викитекст) -> corpus.jsonl (чистый текст), по одному документу на строку.

Ввод/вывод: файл или '-' (stdin/stdout). Кодировка UTF-8. Потоковая обработка.
Сводка пропусков печатается в stderr в виде JSON.
"""
import argparse
import json
import os
import sys
import urllib.parse

import wikitext


def open_in(p):
    return sys.stdin if p == "-" else open(p, encoding="utf-8")


def open_out(p):
    return sys.stdout if p == "-" else open(p, "w", encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("raw", help="raw.jsonl или '-'")
    ap.add_argument("-o", "--output", default="-", help="corpus.jsonl или '-'")
    ap.add_argument("--wiki-url", default="https://ru.wikipedia.org/wiki/")
    ap.add_argument("--min-chars", type=int, default=200,
                    help="отбрасывать документы короче (в символах)")
    ap.add_argument("--keep-service-sections", action="store_true",
                    help="не вырезать 'Примечания', 'Литература', 'Ссылки' и т.п.")
    ap.add_argument("--split-dir", help="дополнительно писать каждый документ в <id>.txt")
    a = ap.parse_args()

    if a.split_dir:
        os.makedirs(a.split_dir, exist_ok=True)
    skipped = {"bad_json": 0, "redirect": 0, "too_short": 0}
    kept = 0
    with open_in(a.raw) as fin, open_out(a.output) as fout:
        for line in fin:
            try:
                rec = json.loads(line)
                src = rec["wikitext"]
            except (ValueError, KeyError):
                skipped["bad_json"] += 1
                continue
            text = wikitext.clean(src, a.keep_service_sections)
            if text is None:
                skipped["redirect"] += 1
                continue
            if len(text) < a.min_chars:
                skipped["too_short"] += 1
                continue
            doc = {"id": rec["id"], "title": rec["title"],
                   "url": a.wiki_url + urllib.parse.quote(rec["title"].replace(" ", "_")),
                   "text": text}
            fout.write(json.dumps(doc, ensure_ascii=False) + "\n")
            if a.split_dir:
                with open(os.path.join(a.split_dir, "%d.txt" % rec["id"]), "w",
                          encoding="utf-8") as f:
                    f.write(text + "\n")
            kept += 1
    print(json.dumps({"kept": kept, "skipped": skipped}, ensure_ascii=False), file=sys.stderr)


if __name__ == "__main__":
    main()
