#!/usr/bin/env bash
# Полный конвейер: скачать -> очистить -> статистика -> отчёт.
# Использование: ./run_all.sh "Категория:Авиация" you@example.org "Иванов И. И." "М8О-101Б-23" [лимит]
set -euo pipefail
cd "$(dirname "$0")"
CATEGORY=${1:?категория}; CONTACT=${2:?e-mail}; STUDENT=${3:?ФИО}; GROUP=${4:?группа}; LIMIT=${5:-0}
OUT=data
python3 fetch_corpus.py "$CATEGORY" --out "$OUT" --contact "$CONTACT" --limit "$LIMIT"
python3 extract_text.py "$OUT/raw.jsonl" -o "$OUT/corpus.jsonl" --split-dir "$OUT/docs"
python3 corpus_stats.py "$OUT/corpus.jsonl" --raw "$OUT/raw.jsonl" -o "$OUT/stats.json"
python3 make_report.py --stats "$OUT/stats.json" --meta "$OUT/fetch_meta.json" \
    --student "$STUDENT" --group "$GROUP"
./build_report.sh
