"""Сквозные тесты CLI на локальном поддельном MediaWiki API (без интернета)."""
import http.server
import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
import urllib.parse

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
LONG = "Слово " * 60  # > 200 символов после очистки

CATS = {  # категория -> список (pageid, ns, title)
    "Категория:Корень": [(1, 0, "Статья А"), (2, 0, "Статья Б"), (10, 14, "Категория:Под")],
    "Категория:Под": [(2, 0, "Статья Б"), (3, 0, "Статья В"), (4, 0, "Редирект"),
                      (5, 0, "Короткая"), (11, 14, "Категория:Корень"), (6, 1, "Обсуждение")],
}
PAGES = {
    1: "== Раздел ==\n" + LONG + "[[Файл:a.jpg|thumb|подпись]]{{шаблон}}",
    2: "'''Статья Б''' " + LONG + "<ref>x</ref>",
    3: LONG + "\n== Примечания ==\n* не должно попасть",
    4: "#REDIRECT [[Статья А]]",
    5: "Коротко.",
}


class Handler(http.server.BaseHTTPRequestHandler):
    log = []

    def log_message(self, *a):
        pass

    def do_GET(self):
        q = {k: v[0] for k, v in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).items()}
        if q.get("list") == "categorymembers":
            members = CATS[q["cmtitle"]]
            start = int(q.get("cmcontinue", 0))
            chunk = members[start:start + 2]  # страницы по 2 - проверка continue
            body = {"query": {"categorymembers": [
                {"pageid": p, "ns": ns, "title": t} for p, ns, t in chunk]}}
            if start + 2 < len(members):
                body["continue"] = {"cmcontinue": str(start + 2), "continue": "-||"}
        else:
            ids = [int(x) for x in q["pageids"].split("|")]
            Handler.log.append(ids)
            pages = []
            for i in ids:
                if i in PAGES:
                    pages.append({"pageid": i, "title": "T%d" % i, "revisions": [{
                        "revid": 100 + i, "timestamp": "2026-01-01T00:00:00Z",
                        "slots": {"main": {"content": PAGES[i]}}}]})
                else:
                    pages.append({"pageid": i, "missing": True})
            body = {"query": {"pages": pages}}
        data = json.dumps(body).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(data)


def run(script, *args, stdin=None):
    return subprocess.run([sys.executable, os.path.join(ROOT, script), *args],
                          input=stdin, capture_output=True, text=True, encoding="utf-8")


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.api = "http://127.0.0.1:%d/w/api.php" % cls.srv.server_port

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    def fetch(self, out, *extra):
        return run("fetch_corpus.py", "Корень", "--out", out, "--api", self.api,
                   "--contact", "t@example.org", "--delay", "0", "--batch", "2", *extra)

    def test_full_pipeline(self):
        with tempfile.TemporaryDirectory() as d:
            Handler.log.clear()
            r = self.fetch(d)
            self.assertEqual(r.returncode, 0, r.stderr)
            # титулы: дубликат 2 и обсуждение (ns=1) не попали, цикл категорий не завис
            titles = open(os.path.join(d, "titles.tsv"), encoding="utf-8").read().split("\n")
            ids = sorted(int(l.split("\t")[0]) for l in titles if l)
            self.assertEqual(ids, [1, 2, 3, 4, 5])
            # пакеты по 2 id
            self.assertTrue(all(len(b) <= 2 for b in Handler.log))
            raw = os.path.join(d, "raw.jsonl")
            self.assertEqual(sum(1 for _ in open(raw, encoding="utf-8")), 5)

            corpus = os.path.join(d, "corpus.jsonl")
            split = os.path.join(d, "split")
            r = run("extract_text.py", raw, "-o", corpus, "--split-dir", split)
            self.assertEqual(r.returncode, 0, r.stderr)
            summary = json.loads(r.stderr.strip().splitlines()[-1])
            self.assertEqual(summary["kept"], 3)
            self.assertEqual(summary["skipped"]["redirect"], 1)
            self.assertEqual(summary["skipped"]["too_short"], 1)
            docs = [json.loads(l) for l in open(corpus, encoding="utf-8")]
            self.assertEqual(sorted(x["id"] for x in docs), [1, 2, 3])
            by_id = {x["id"]: x for x in docs}
            self.assertNotIn("не должно попасть", by_id[3]["text"])
            self.assertNotIn("шаблон", by_id[1]["text"])
            self.assertTrue(by_id[1]["url"].startswith("https://ru.wikipedia.org/wiki/T1"))
            self.assertEqual(sorted(os.listdir(split)), ["1.txt", "2.txt", "3.txt"])

            out = os.path.join(d, "stats.json")
            r = run("corpus_stats.py", corpus, "--raw", raw, "-o", out, "--min-docs", "3")
            self.assertEqual(r.returncode, 0, r.stderr)
            st = json.load(open(out, encoding="utf-8"))
            self.assertEqual(st["docs"], 3)
            self.assertTrue(st["requirements"]["docs_ok"])
            self.assertEqual(st["top_tokens"][0][0], "слово")
            self.assertGreater(st["markup_removed_ratio"], 0)
            self.assertEqual(sum(b["docs"] for b in st["length_histogram"]), 3)
            self.assertGreater(st["share_cyrillic_letters"], 0.5)

    def test_resume_does_not_refetch(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(self.fetch(d).returncode, 0)
            Handler.log.clear()
            r = self.fetch(d)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertEqual(Handler.log, [])
            raw = os.path.join(d, "raw.jsonl")
            self.assertEqual(sum(1 for _ in open(raw, encoding="utf-8")), 5)

    def test_resume_after_truncated_line(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(self.fetch(d).returncode, 0)
            raw = os.path.join(d, "raw.jsonl")
            lines = open(raw, encoding="utf-8").read().splitlines()
            with open(raw, "w", encoding="utf-8") as f:  # обрываем последнюю запись
                f.write("\n".join(lines[:-1]) + "\n" + lines[-1][:30])
            Handler.log.clear()
            self.assertEqual(self.fetch(d).returncode, 0)
            self.assertEqual(sum(len(b) for b in Handler.log), 1)

    def test_limit(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(self.fetch(d, "--limit", "2").returncode, 0)
            ids = [l for l in open(os.path.join(d, "titles.tsv"), encoding="utf-8") if l.strip()]
            self.assertEqual(len(ids), 2)

    def test_depth_zero_ignores_subcategories(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(self.fetch(d, "--depth", "0").returncode, 0)
            ids = sorted(int(l.split("\t")[0]) for l in
                         open(os.path.join(d, "titles.tsv"), encoding="utf-8") if l.strip())
            self.assertEqual(ids, [1, 2])

    def test_extract_stdin_stdout(self):
        rec = {"id": 7, "title": "Т", "wikitext": "'''Т''' " + LONG}
        r = run("extract_text.py", "-", stdin=json.dumps(rec, ensure_ascii=False) + "\n")
        self.assertEqual(r.returncode, 0, r.stderr)
        doc = json.loads(r.stdout)
        self.assertEqual(doc["id"], 7)
        self.assertTrue(doc["text"].startswith("Т Слово"))

    def test_extract_skips_bad_json_lines(self):
        good = json.dumps({"id": 1, "title": "A", "wikitext": LONG}, ensure_ascii=False)
        r = run("extract_text.py", "-", stdin="{oops\n" + good + "\n")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(json.loads(r.stderr.strip().splitlines()[-1])["skipped"]["bad_json"], 1)
        self.assertEqual(len(r.stdout.strip().splitlines()), 1)

    def test_stats_reports_requirement_failure(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "c.jsonl")
            with open(p, "w", encoding="utf-8") as f:
                f.write(json.dumps({"id": 1, "title": "A", "text": "раз два три"}) + "\n")
            r = run("corpus_stats.py", p)
            self.assertEqual(r.returncode, 0, r.stderr)
            st = json.loads(r.stdout)
            self.assertFalse(st["requirements"]["docs_ok"])
            self.assertEqual(st["tokens"], 3)
            self.assertIsNone(st["markup_removed_ratio"])


if __name__ == "__main__":
    unittest.main()
