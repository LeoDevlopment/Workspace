import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import wikitext as w


class CleanTests(unittest.TestCase):
    def test_nested_templates_removed(self):
        self.assertEqual(w.clean("A{{x|{{y|z}}|q}}B"), "AB")

    def test_unbalanced_template_drops_tail_only(self):
        self.assertEqual(w.clean("Начало {{незакрыт и дальше"), "Начало")

    def test_stray_close_braces_kept(self):
        self.assertEqual(w.clean("a }} b"), "a }} b")

    def test_refs_both_forms(self):
        self.assertEqual(w.clean('Факт<ref name="a">источник {{cite}}</ref> тут<ref name="b"/>.'),
                         "Факт тут.")

    def test_comment_removed(self):
        self.assertEqual(w.clean("до<!-- скрыто\nмногострочно -->после"), "допосле")

    def test_piped_and_plain_links(self):
        self.assertEqual(w.clean("[[Москва|город]] и [[Лондон]]"), "город и Лондон")

    def test_file_with_nested_link_caption_removed(self):
        self.assertEqual(w.clean("до [[Файл:a.jpg|thumb|вид на [[Москва|город]]]] после"),
                         "до после")

    def test_category_and_interwiki_removed(self):
        self.assertEqual(w.clean("текст [[Категория:Авиация]][[en:Aviation]]"), "текст")

    def test_colon_link_to_category_page_is_not_interwiki(self):
        self.assertEqual(w.clean("[[:Категория:Авиация]]"), "Категория:Авиация")

    def test_external_links(self):
        self.assertEqual(
            w.clean("[https://a.example/x подпись] и [https://b.example] и https://c.example/z."),
            "подпись и и")

    def test_table_removed_with_nested(self):
        src = "до\n{|\n|a\n{|\n|вложенная\n|}\n|b\n|}\nпосле"
        self.assertEqual(w.clean(src), "до\n\nпосле")

    def test_bold_italic_html_entities(self):
        self.assertEqual(w.clean("'''жирный''' ''курсив'' <b>тег</b> A&nbsp;&amp;&nbsp;B"),
                         "жирный курсив тег A & B")

    def test_less_than_sign_is_not_a_tag(self):
        self.assertEqual(w.clean("если a < b и c > d"), "если a < b и c > d")

    def test_headings_kept_lists_unmarked(self):
        self.assertEqual(w.clean("== История ==\n* первый\n** второй\nтекст"),
                         "История\nпервый\nвторой\nтекст")

    def test_service_sections_dropped_until_next_heading(self):
        src = "Лид\n== Примечания ==\n* x\n=== Ещё ===\n* y\n== Итог ==\nконец"
        self.assertEqual(w.clean(src), "Лид\nИтог\nконец")

    def test_service_sections_kept_on_request(self):
        out = w.clean("Лид\n== Литература ==\n* книга", keep_service=True)
        self.assertEqual(out, "Лид\nЛитература\nкнига")

    def test_redirect_returns_none(self):
        self.assertIsNone(w.clean("#REDIRECT [[Другая]]"))
        self.assertIsNone(w.clean("#перенаправление [[Другая]]"))

    def test_empty_parentheses_after_template_removal(self):
        self.assertEqual(w.clean("Иванов ({{дата|1|1|2000}}) учёный"), "Иванов учёный")

    def test_math_and_gallery_blocks_removed(self):
        self.assertEqual(w.clean("до <math>x^2</math> и <gallery>\nФайл:a.jpg\n</gallery> после"),
                         "до и после")

    def test_empty_input(self):
        self.assertEqual(w.clean(""), "")


if __name__ == "__main__":
    unittest.main()
