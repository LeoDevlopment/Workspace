"""Очистка викитекста до простого текста. Только стандартная библиотека."""
import html
import re

# Служебные разделы: списки ссылок и литературы, почти не содержат связного текста.
SERVICE = {
    "примечания", "примечание", "литература", "ссылки", "см. также", "источники",
    "сноски", "комментарии", "references", "external links", "see also", "notes",
    "sources", "bibliography", "further reading",
}
FILE_NS = {"file", "image", "файл", "изображение", "media", "медиа"}
CAT_NS = {"category", "категория"}

REDIRECT = re.compile(r"^\s*#\s*(redirect|перенаправление)", re.I)
COMMENT = re.compile(r"<!--.*?-->", re.S)
REF_SELF = re.compile(r"<ref\b[^>]*/>", re.I)
REF = re.compile(r"<ref\b[^>]*>.*?</ref\s*>", re.S | re.I)
BLOCK = re.compile(
    r"<(gallery|math|timeline|imagemap|source|syntaxhighlight|score|references|"
    r"nowiki|pre|code|hiero|mapframe|maplink|chem)\b[^>]*?(?:/>|>.*?</\1\s*>)",
    re.S | re.I)
TEMPLATE_TOK = re.compile(r"\{\{|\}\}")
TABLE_TOK = re.compile(r"^[ \t]*(\{\||\|\})", re.M)
LINK = re.compile(r"\[\[([^\[\]]*)\]\]")
EXT_LABEL = re.compile(r"\[(?:https?:)?//[^\s\]]+\s+([^\]]*)\]")
EXT_BARE = re.compile(r"\[(?:https?:)?//[^\s\]]+\]")
URL = re.compile(r"https?://[^\s<>\]]+")
TAG = re.compile(r"</?[A-Za-z][^>]*>")
HEAD = re.compile(r"^(={1,6})\s*(.*?)\s*\1\s*$")
INTERWIKI = re.compile(r"[a-z]{2,3}(-[a-z]+)?")


def strip_templates(t):
    """Удаляет {{...}} с учётом вложенности за один проход."""
    out, depth, pos = [], 0, 0
    for m in TEMPLATE_TOK.finditer(t):
        if m.group() == "{{":
            if depth == 0:
                out.append(t[pos:m.start()])
            depth += 1
        elif depth > 0:
            depth -= 1
            if depth == 0:
                pos = m.end()
    if depth == 0:
        out.append(t[pos:])
    return "".join(out)


def strip_tables(t):
    """Удаляет таблицы {| ... |} с учётом вложенности."""
    out, depth, pos = [], 0, 0
    for m in TABLE_TOK.finditer(t):
        if m.group(1) == "{|":
            if depth == 0:
                out.append(t[pos:m.start()])
            depth += 1
        elif depth > 0:
            depth -= 1
            if depth == 0:
                pos = m.end()
    if depth == 0:
        out.append(t[pos:])
    return "".join(out)


def _link(m):
    body = m.group(1)
    target, sep, label = body.partition("|")
    ns = target.split(":", 1)[0].strip().lstrip(":").lower() if ":" in target else ""
    if ns in FILE_NS or ns in CAT_NS:
        return ""
    if ns and INTERWIKI.fullmatch(ns) and not target.startswith(":"):
        return ""
    if sep and label.strip():
        return label
    return target.lstrip(":")


def _links(t):
    for _ in range(10):  # вложенные ссылки: снимаем изнутри наружу
        new = LINK.sub(_link, t)
        if new == t:
            break
        t = new
    return t


def clean(wikitext, keep_service=False):
    """Возвращает простой текст статьи или None для страницы-перенаправления."""
    if REDIRECT.match(wikitext):
        return None
    t = COMMENT.sub("", wikitext)
    t = REF_SELF.sub("", t)
    t = REF.sub("", t)
    t = BLOCK.sub("", t)
    t = strip_templates(t)
    t = strip_tables(t)
    t = _links(t)
    t = EXT_LABEL.sub(r"\1", t)
    t = EXT_BARE.sub("", t)
    t = URL.sub("", t)
    t = re.sub(r"'{2,}", "", t)
    t = TAG.sub("", t)
    t = html.unescape(t).replace("\xa0", " ")
    t = re.sub(r"__[A-Z]+__", "", t)
    t = re.sub(r"\(\s*[,;:]?\s*\)", "", t)

    lines, skip_level = [], None
    for raw in t.split("\n"):
        line = raw.strip()
        m = HEAD.match(line)
        if m:
            level, title = len(m.group(1)), m.group(2).strip()
            if skip_level is not None and level <= skip_level:
                skip_level = None
            if skip_level is None and not keep_service and title.lower().rstrip(":") in SERVICE:
                skip_level = level
                continue
            if skip_level is None and title:
                lines.append(title)
            continue
        if skip_level is not None:
            continue
        line = re.sub(r"^[*#:;]+\s*", "", line)
        line = re.sub(r"[ \t]+", " ", line)
        line = re.sub(r"\s+([,.;:!?])", r"\1", line)
        lines.append(line)
    text = "\n".join(lines)
    return re.sub(r"\n{3,}", "\n\n", text).strip()
