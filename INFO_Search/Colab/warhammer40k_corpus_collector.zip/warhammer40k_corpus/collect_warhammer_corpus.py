#!/usr/bin/env python3
"""Сбор UTF-8 корпуса Warhammer 40,000 из нескольких MediaWiki API."""
import argparse, collections, datetime, json, os, re, sys, time, urllib.error, urllib.parse, urllib.request
import wikitext

SOURCES = [
    {"key":"lexicanum", "api":"https://wh40k.lexicanum.com/mediawiki/api.php", "wiki":"https://wh40k.lexicanum.com/wiki/", "roots":["Category:Warhammer 40,000", "Category:Imperium of Man", "Category:Chaos", "Category:Space Marines", "Category:Xenos"]},
    {"key":"wiki_gg", "api":"https://warhammer40k.wiki.gg/api.php", "wiki":"https://warhammer40k.wiki.gg/wiki/", "roots":["Category:Warhammer 40,000", "Category:Imperium of Man", "Category:Space Marines", "Category:Chaos"]},
    {"key":"ruwiki", "api":"https://ru.wikipedia.org/w/api.php", "wiki":"https://ru.wikipedia.org/wiki/", "roots":["Категория:Warhammer 40,000", "Категория:Warhammer 40,000"]},
]
TOKEN = re.compile(r"\w+", re.UNICODE)

class Api:
    def __init__(self, base, contact, delay):
        self.base, self.delay = base, delay
        self.ua = "MAI-IR-WarhammerCorpus/1.0 (educational corpus; contact: %s)" % contact
    def call(self, params):
        params = dict(params, format="json", formatversion="2", maxlag="5")
        url = self.base + "?" + urllib.parse.urlencode(params)
        last = None
        for attempt in range(6):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": self.ua})
                with urllib.request.urlopen(req, timeout=45) as resp:
                    data = json.load(resp)
                if data.get("error"):
                    err = data["error"]
                    if err.get("code") in ("maxlag", "ratelimited", "readonly"):
                        time.sleep(min(2 ** attempt, 20)); continue
                    raise RuntimeError(str(err))
                time.sleep(self.delay)
                return data
            except (urllib.error.URLError, TimeoutError, ValueError, json.JSONDecodeError) as e:
                last = e; time.sleep(min(2 ** attempt, 20))
        raise RuntimeError("API unavailable: %s (%s)" % (self.base, last))

def load_jsonl(path):
    out=[]
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for line in f:
                try: out.append(json.loads(line))
                except ValueError: pass
    return out

def crawl_categories(api, roots, max_pages, depth, source):
    queue=collections.deque((r,0) for r in roots); seen_cats=set(roots); pages={}
    while queue and len(pages) < max_pages:
        cat,d=queue.popleft(); cont={}
        try:
            while len(pages) < max_pages:
                params={"action":"query","list":"categorymembers","cmtitle":cat,"cmtype":"page|subcat","cmlimit":"500"}; params.update(cont)
                data=api.call(params)
                members=data.get("query",{}).get("categorymembers",[])
                for m in members:
                    ns=m.get("ns")
                    if ns==14 and d<depth and m["title"] not in seen_cats:
                        seen_cats.add(m["title"]); queue.append((m["title"],d+1))
                    elif ns==0 and m.get("pageid"):
                        pages.setdefault(m["pageid"],m["title"])
                        if len(pages)>=max_pages: break
                if "continue" not in data: break
                cont=data["continue"]
        except Exception as e:
            print("[WARN] %s category %r: %s"%(source,cat,e),file=sys.stderr)
    return list(pages.items())

def fetch_pages(api, ids):
    params={"action":"query","pageids":"|".join(map(str,ids)),"prop":"revisions","rvprop":"ids|timestamp|content","rvslots":"main"}
    data=api.call(params)
    for p in data.get("query",{}).get("pages",[]):
        revs=p.get("revisions") or []
        if p.get("missing") or not revs: continue
        rev=revs[0]; content=rev.get("slots",{}).get("main",{}).get("content","")
        if content:
            yield {"id":"%s:%s"%(p.get("pageid"),p.get("pageid")),"pageid":p.get("pageid"),"title":p.get("title"),"revid":rev.get("revid"),"timestamp":rev.get("timestamp"),"wikitext":content}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--out",default="data"); ap.add_argument("--target",type=int,default=30000)
    ap.add_argument("--contact",required=True); ap.add_argument("--depth",type=int,default=5)
    ap.add_argument("--delay",type=float,default=0.35); ap.add_argument("--min-chars",type=int,default=200)
    ap.add_argument("--per-source-cap",type=int,default=50000)
    args=ap.parse_args(); os.makedirs(args.out,exist_ok=True)
    raw_path=os.path.join(args.out,"raw.jsonl"); corpus_path=os.path.join(args.out,"corpus.jsonl")
    # Resume by source/page ID. Existing raw records are preserved.
    existing=load_jsonl(raw_path); done={(r.get("source"),str(r.get("pageid",r.get("id")))) for r in existing}
    raw_count=len(existing); corpus_seen={}
    raw_target = args.target * 2  # часть страниц будет отброшена при очистке
    with open(raw_path,"a",encoding="utf-8") as raw:
        for src in SOURCES:
            if len(done)>=raw_target: break
            api=Api(src["api"],args.contact,args.delay)
            try: pages=crawl_categories(api,src["roots"],args.per_source_cap,args.depth,src["key"])
            except Exception as e:
                print("[WARN] source skipped %s: %s"%(src["key"],e),file=sys.stderr); continue
            print("[%s] category pages found: %d"%(src["key"],len(pages)),file=sys.stderr)
            todo=[pid for pid,title in pages if (src["key"],str(pid)) not in done]
            for i in range(0,len(todo),50):
                try: batch=list(fetch_pages(api,todo[i:i+50]))
                except Exception as e:
                    print("[WARN] batch %s: %s"%(src["key"],e),file=sys.stderr); continue
                for rec in batch:
                    rec["id"]="%s:%s"%(src["key"],rec["pageid"]); rec["source"]=src["key"]
                    rec["url"]=src["wiki"]+urllib.parse.quote(rec["title"].replace(" ","_"))
                    raw.write(json.dumps(rec,ensure_ascii=False)+"\n"); raw.flush()
                    done.add((src["key"],str(rec["pageid"])))
                print("[%s] fetched %d/%d; total raw %d"%(src["key"],min(i+50,len(todo)),len(todo),len(done)),file=sys.stderr)
                if len(done)>=raw_target: break
    # Rebuild clean corpus from raw so resume does not create duplicate output lines.
    kept=[]; redirects=short=0
    for rec in load_jsonl(raw_path):
        txt=wikitext.clean(rec.get("wikitext",""))
        if txt is None: redirects+=1; continue
        if len(txt)<args.min_chars: short+=1; continue
        kept.append({"id":rec["id"],"title":rec["title"],"url":rec.get("url",""),"text":txt,"source":rec.get("source","unknown")})
    # Deduplicate on normalized title+source; preserve separate sources for traceability.
    with open(corpus_path,"w",encoding="utf-8") as f:
        for doc in kept: f.write(json.dumps(doc,ensure_ascii=False)+"\n")
    token_count=0; unique=set(); lengths=[]; byte_count=0
    for d in kept:
        toks=TOKEN.findall(d["text"].lower()); token_count+=len(toks); unique.update(toks); lengths.append(len(toks)); byte_count+=len(d["text"].encode("utf-8"))
    stats={"docs":len(kept),"required_docs":30000,"requirement_met":len(kept)>=30000,"raw_docs":len(load_jsonl(raw_path)),"tokens":token_count,"unique_tokens":len(unique),"text_bytes":byte_count,"avg_tokens_per_doc":round(token_count/len(kept),1) if kept else 0,"median_tokens_per_doc":sorted(lengths)[len(lengths)//2] if lengths else 0,"min_chars":args.min_chars,"skipped_redirects":redirects,"skipped_short":short,"by_source":dict(collections.Counter(d["source"] for d in kept)),"collected_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")}
    with open(os.path.join(args.out,"stats.json"),"w",encoding="utf-8") as f: json.dump(stats,f,ensure_ascii=False,indent=2)
    meta={"sources":SOURCES,"target":args.target,"depth":args.depth,"contact_user_agent":args.contact,"collected_utc":stats["collected_utc"]}
    with open(os.path.join(args.out,"fetch_meta.json"),"w",encoding="utf-8") as f: json.dump(meta,f,ensure_ascii=False,indent=2)
    print(json.dumps(stats,ensure_ascii=False,indent=2))
    if len(kept)<30000: print("[WARN] Requirement not met: run again or expand categories/sources.",file=sys.stderr)
if __name__=="__main__": main()
