#!/usr/bin/env bash
# Прогон автотестов "с нуля". Результат: tests_result.txt (один тест-кейс на строку).
set -uo pipefail
cd "$(dirname "$0")"
python3 -m unittest discover -s tests -v 2>&1 | tee tests_result.txt
exit "${PIPESTATUS[0]}"
