import os
import sys
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import make_report
import zipf

with open(os.path.join(ROOT, "report_template.md"), encoding="utf-8") as f:
    TEMPLATE = f.read()


def render(items):
    res = zipf.analyse(items)
    return make_report.render(res, "Иванов И. И.", "М8О-000", "Тест", "data/z.png", "data/m.png", TEMPLATE), res


class PhraseTests(unittest.TestCase):
    def test_phrase_branches(self):
        self.assertIn("примерно совпадает", make_report.phrase(1.1))
        self.assertIn("в 2.0 раза меньше", make_report.phrase(0.5))
        self.assertIn("в 3.0 раза больше", make_report.phrase(3.0))

    def test_num_formatting(self):
        self.assertEqual(make_report.num(1234567), "1\u00a0234\u00a0567")
        self.assertEqual(make_report.num(0.123456), "0.1235")
        self.assertEqual(make_report.num(157751.4), "157\u00a0751")


class RenderTests(unittest.TestCase):
    def test_no_unsubstituted_fields_and_no_tex_math(self):
        md, _ = render([("t%d" % r, round(1e8 / (r + 100) ** 1.15)) for r in range(1, 20001)])
        self.assertNotIn("${", md)
        self.assertNotIn("$", md)             # формулы - обычный текст, математика pandoc не нужна
        self.assertIn("**P = ", md)
        self.assertIn("data/m.png", md)

    def test_numbers_from_analysis_appear_in_report(self):
        md, res = render([("t%d" % r, round(1e8 / (r + 100) ** 1.15)) for r in range(1, 20001)])
        self.assertIn("%.3f" % res["mandelbrot"]["B"], md)
        self.assertIn("B = 1.150", md)
        self.assertIn(make_report.num(res["tokens"]), md)

    def test_head_branch_depends_on_data(self):
        low_head, _ = render([("t%d" % r, round(1e8 / (r + 100) ** 1.15)) for r in range(1, 20001)])
        self.assertIn("согласуется с этой причиной", low_head)
        exact_zipf, _ = render([("t%d" % r, round(1e6 / r)) for r in range(1, 20001)])
        self.assertIn("этого эффекта не видно", exact_zipf)

    def test_mandelbrot_vs_zipf_sentence_branches(self):
        better, _ = render([("t%d" % r, round(1e8 / (r + 100) ** 1.15)) for r in range(1, 20001)])
        self.assertIn("Мандельброт точнее в", better)
        same, _ = render([("t%d" % r, round(1e6 / r)) for r in range(1, 20001)])
        self.assertIn("не точнее", same)

    def test_conclusions_follow_the_numbers(self):
        exact, _ = render([("t%d" % r, round(1e6 / r)) for r in range(1, 20001)])
        self.assertIn("описывает корпус хорошо", exact)
        self.assertIn("не лучше закона Ципфа", exact)
        self.assertIn("Терминов с частотой 1 в корпусе нет", exact)
        self.assertNotIn("ни один из законов не описывает", exact)
        shifted, _ = render([("t%d" % r, max(1, round(1e5 / (r + 100) ** 1.15))) for r in range(1, 20001)])
        self.assertIn("описывает распределение заметно лучше", shifted)
        self.assertIn("Полку из терминов с частотой 1", shifted)
        self.assertIn("ни один из законов не описывает", shifted)
        self.assertNotIn("оправдывает стоп-слова", shifted)          # топ-10 дают лишь ~3% токенов
        steep, res = render([("t%d" % r, max(1, round(1e6 / r ** 1.3))) for r in range(1, 60001)])
        self.assertGreater(res["top10_share_of_tokens"], 0.1)
        self.assertGreater(res["hapax_share_of_terms"], 0.3)
        self.assertIn("оправдывает стоп-слова", steep)

    def test_plateau_note_without_hapax(self):
        md, _ = render([("t%d" % r, round(1e9 / (r + 100) ** 1.15)) for r in range(1, 2001)])
        self.assertNotIn("${", md)
        self.assertIn("нет", md)               # полки из единичных частот в данных нет


if __name__ == "__main__":
    unittest.main()
