import json
import math
import os
import random
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import zipf


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def mandelbrot_items(p, b, rho, n):
    return [("t%d" % r, round(p / (r + rho) ** b)) for r in range(1, n + 1)]


class CountingTests(unittest.TestCase):
    def test_read_counts_lines_and_blank_lines(self):
        c, bad = zipf.read_counts(["a\n", "b\n", "a\n", "\n", "  \n", "a"])
        self.assertEqual((dict(c), bad), ({"a": 3, "b": 1}, 0))

    def test_read_counts_uniq_format(self):
        c, bad = zipf.read_counts(["   12 мир\n", "3 hello\n", "bad line\n", "0 zero\n", "5\n", "2 мир\n"], uniq=True)
        self.assertEqual(dict(c), {"мир": 14, "hello": 3})
        self.assertEqual(bad, 3)

    def test_ranked_is_deterministic_on_ties(self):
        items = zipf.ranked({"б": 2, "а": 2, "в": 5, "г": 1})
        self.assertEqual(items, [("в", 5), ("а", 2), ("б", 2), ("г", 1)])


class MathTests(unittest.TestCase):
    def test_sample_ranks_properties(self):
        r = zipf.sample_ranks(1_000_000, 400)
        self.assertEqual((r[0], r[-1]), (1, 1_000_000))
        self.assertEqual(r, sorted(set(r)))
        self.assertLessEqual(len(r), 402)
        self.assertEqual(zipf.sample_ranks(10, 400), list(range(1, 11)))
        self.assertEqual(zipf.sample_ranks(1000, 50, lo=10, hi=100)[0], 10)
        self.assertEqual(zipf.sample_ranks(5, 10, lo=9), [])

    def test_sample_is_log_uniform_each_decade_has_points(self):
        r = zipf.sample_ranks(1_000_000, 400)
        self.assertEqual([x for x in r if x < 10], list(range(1, 10)))      # в первой декаде все ранги
        for k in range(1, 6):
            self.assertGreaterEqual(sum(1 for x in r if 10 ** k <= x < 10 ** (k + 1)), 20)

    def test_linreg_exact(self):
        a, b = zipf.linreg([0, 1, 2, 3], [1, 3, 5, 7])
        self.assertAlmostEqual(a, 1); self.assertAlmostEqual(b, 2)

    def test_exact_zipf_recovered(self):
        freqs = [round(1_000_000 / r) for r in range(1, 20001)]
        ranks = zipf.sample_ranks(len(freqs))
        z, pl = zipf.fit_zipf(freqs, ranks), zipf.fit_powerlaw(freqs, ranks)
        self.assertAlmostEqual(z["C"] / 1e6, 1.0, delta=0.01)
        self.assertAlmostEqual(pl["s"], 1.0, delta=0.01)
        self.assertLess(z["rmse_log10"], 0.01)

    def test_mandelbrot_parameters_recovered_exactly(self):
        items = mandelbrot_items(1e8, 1.15, 100, 20000)
        mb = zipf.analyse(items)["mandelbrot"]
        self.assertAlmostEqual(mb["B"], 1.15, delta=0.005)
        self.assertAlmostEqual(mb["rho"], 100, delta=3)
        self.assertAlmostEqual(mb["log10_P"], 8.0, delta=0.01)
        self.assertLess(mb["rmse_log10"], 0.005)

    def test_mandelbrot_with_zero_shift_is_plain_power_law(self):
        items = mandelbrot_items(1e8, 1.0, 0, 20000)
        res = zipf.analyse(items)
        self.assertLess(res["mandelbrot"]["rho"], 1.0)
        self.assertAlmostEqual(res["mandelbrot"]["B"], 1.0, delta=0.01)

    def test_mandelbrot_beats_zipf_when_data_have_shift(self):
        res = zipf.analyse(mandelbrot_items(1e8, 1.15, 100, 20000))
        self.assertLess(res["mandelbrot"]["rmse_log10"], res["zipf"]["rmse_log10"] / 10)
        self.assertGreater(res["mandelbrot"]["r2"], res["zipf"]["r2"])

    def test_noisy_sample_from_zipf_distribution_gives_exponent_near_one(self):
        rnd = random.Random(5)
        v = 5000
        words = ["w%d" % r for r in range(1, v + 1)]
        draws = rnd.choices(words, weights=[1.0 / r for r in range(1, v + 1)], k=300_000)
        counter, _ = zipf.read_counts(draws)
        res = zipf.analyse(zipf.ranked(counter), fit_hi=300)    # хвост из единичных частот не берём
        self.assertAlmostEqual(res["powerlaw"]["s"], 1.0, delta=0.08)
        self.assertGreater(res["hapax_share_of_terms"], 0.0)

    def test_regions_and_checkpoints_on_exact_zipf(self):
        items = [("t%d" % r, round(1e6 / r)) for r in range(1, 20001)]
        res = zipf.analyse(items)
        self.assertEqual([(g["from"], g["to"]) for g in res["regions"]],
                         [(1, 10), (11, 100), (101, 1000), (1001, 10000), (10001, 20000)])
        for g in res["regions"][:-1]:
            self.assertAlmostEqual(g["ratio_to_zipf"], 1.0, delta=0.02)
        self.assertEqual(res["checkpoints"][0]["rank"], 1)
        self.assertEqual(res["checkpoints"][-1]["rank"], 20000)

    def test_plateau_and_hapax_statistics(self):
        items = [("a", 10), ("b", 5), ("c", 2), ("d", 1), ("e", 1), ("f", 1), ("g", 1)]
        res = zipf.analyse(items)
        self.assertEqual((res["hapax_terms"], res["plateau_start_rank"], res["terms"], res["tokens"]),
                         (4, 4, 7, 21))
        self.assertAlmostEqual(res["hapax_share_of_terms"], 4 / 7)

    def test_too_few_terms_raises(self):
        with self.assertRaises(ValueError):
            zipf.analyse([("a", 3), ("b", 2), ("c", 1)])

    def test_fit_range_restricts_points(self):
        items = mandelbrot_items(1e8, 1.15, 100, 20000)
        res = zipf.analyse(items, fit_lo=10, fit_hi=1000)
        self.assertEqual((res["fit"]["rank_from"], res["fit"]["rank_to"]), (10, 1000))


class CliTests(unittest.TestCase):
    def run_cli(self, data, *args):
        return subprocess.run([sys.executable, os.path.join(ROOT, "zipf.py"), "-", *args],
                              input=data.encode("utf-8"), capture_output=True)

    def test_end_to_end_outputs(self):
        rnd = random.Random(1)
        words = ["слово%d" % r for r in range(1, 3001)]
        data = "\n".join(rnd.choices(words, weights=[1 / r for r in range(1, 3001)], k=60000)) + "\n"
        with tempfile.TemporaryDirectory() as d:
            r = self.run_cli(data, "--outdir", d)
            self.assertEqual(r.returncode, 0, r.stderr)
            res = json.loads(read(os.path.join(d, "zipf.json")))
            self.assertEqual(res["tokens"], 60000)
            for k in ("zipf", "powerlaw", "mandelbrot", "regions", "checkpoints", "hapax_terms"):
                self.assertIn(k, res)
            lines = read(os.path.join(d, "freq.tsv")).splitlines()
            self.assertEqual(len(lines), res["terms"])
            ranks = [int(l.split("\t")[0]) for l in lines]
            counts = [int(l.split("\t")[2]) for l in lines]
            self.assertEqual(ranks, list(range(1, len(lines) + 1)))
            self.assertEqual(counts, sorted(counts, reverse=True))
            for png in ("zipf.png", "zipf_mandelbrot.png"):
                with open(os.path.join(d, png), "rb") as f:
                    self.assertEqual(f.read(8), b"\x89PNG\r\n\x1a\n")

    def test_uniq_mode_matches_plain_mode(self):
        rnd = random.Random(2)
        toks = rnd.choices(["a", "b", "c", "d", "e", "f", "g", "h"], weights=[8, 7, 6, 5, 4, 3, 2, 1], k=2000)
        plain = "\n".join(toks) + "\n"
        uniq = "".join("%7d %s\n" % (toks.count(w), w) for w in sorted(set(toks)))
        with tempfile.TemporaryDirectory() as d1, tempfile.TemporaryDirectory() as d2:
            self.assertEqual(self.run_cli(plain, "--outdir", d1, "--no-plot").returncode, 0)
            self.assertEqual(self.run_cli(uniq, "--uniq", "--outdir", d2, "--no-plot").returncode, 0)
            self.assertEqual(read(os.path.join(d1, "freq.tsv")), read(os.path.join(d2, "freq.tsv")))

    def test_empty_input_and_too_small_input_fail_cleanly(self):
        for data in ("", "\n\n", "a\nb\nc\n"):
            with tempfile.TemporaryDirectory() as d:
                r = self.run_cli(data, "--outdir", d, "--no-plot")
                self.assertEqual(r.returncode, 1, data)
                self.assertIn("zipf:", r.stderr.decode("utf-8"))
                self.assertNotIn("Traceback", r.stderr.decode("utf-8"))


if __name__ == "__main__":
    unittest.main()
