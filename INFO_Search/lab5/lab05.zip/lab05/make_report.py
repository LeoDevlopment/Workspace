#!/usr/bin/env python3
"""Собирает report.md из report_template.md и zipf.json; выводы о расхождениях строятся по числам."""
import argparse
import json
import os
import string


def num(x):
    if isinstance(x, int):
        return "{:,}".format(x).replace(",", "\u00a0")
    if abs(x) >= 1000:
        return "{:,.0f}".format(x).replace(",", "\u00a0")
    return "%.4g" % x


def pct(x):
    return "%.1f%%" % (100 * x)


def phrase(ratio):
    """Словесное описание отношения «факт / предсказание»."""
    if 0.8 <= ratio <= 1.25:
        return "примерно совпадает с предсказанной (отношение %.2f)" % ratio
    if ratio < 1:
        return "в %.1f раза меньше предсказанной" % (1 / ratio)
    return "в %.1f раза больше предсказанной" % ratio


def render(res, student, group, category, img_zipf, img_mandelbrot, template_text):
    z, pl, mb = res["zipf"], res["powerlaw"], res["mandelbrot"]
    v = res["terms"]
    reg = res["regions"]
    last = res["checkpoints"][-1]
    t = {
        "student": student, "group": group, "category": category,
        "img_zipf": img_zipf, "img_mandelbrot": img_mandelbrot,
        "fit_points": str(res["fit"]["points"]), "fit_from": num(res["fit"]["rank_from"]),
        "fit_to": num(res["fit"]["rank_to"]),
        "tokens": num(res["tokens"]), "terms": num(v), "top_freq": num(res["top_freq"]),
        "top10_share": pct(res["top10_share_of_tokens"]),
        "hapax_terms": num(res["hapax_terms"]), "hapax_share": pct(res["hapax_share_of_terms"]),
        "plateau_start": num(res["plateau_start_rank"]) if res["plateau_start_rank"] else "нет",
        "zipf_C": num(z["C"]), "zipf_rmse": "%.3f" % z["rmse_log10"], "zipf_r2": "%.4f" % z["r2"],
        "pl_C": num(pl["C"]), "pl_s": "%.3f" % pl["s"], "pl_rmse": "%.3f" % pl["rmse_log10"], "pl_r2": "%.4f" % pl["r2"],
        "mb_P": num(mb["P"]), "mb_logP": "%.3f" % mb["log10_P"], "mb_B": "%.3f" % mb["B"], "mb_rho": num(mb["rho"]),
        "mb_rmse": "%.3f" % mb["rmse_log10"], "mb_r2": "%.4f" % mb["r2"],
    }
    rows = ["| Ранг | Частота | Ципф | Мандельброт | Факт / Ципф |", "|---|---|---|---|---|"]
    for c in res["checkpoints"]:
        rows.append("| %s | %s | %s | %s | %.2f |" % (num(c["rank"]), num(c["freq"]), num(c["zipf"]),
                                                     num(c["mandelbrot"]), c["ratio_to_zipf"]))
    t["checkpoints_table"] = "\n".join(rows)
    rows = ["| Ранги | Факт / Ципф | Пояснение |", "|---|---|---|"]
    for g in reg:
        rows.append("| %s–%s | %.2f | %s |" % (num(g["from"]), num(g["to"]), g["ratio_to_zipf"], phrase(g["ratio_to_zipf"])))
    t["regions_table"] = "\n".join(rows)
    parts = ["на рангах %s–%s фактическая частота %s" % (num(g["from"]), num(g["to"]), phrase(g["ratio_to_zipf"])) for g in reg]
    t["divergence_text"] = ("По таблице областей рангов (среднее геометрическое по области): " + "; ".join(parts) +
                            ". Константа *C* подобрана по всему диапазону рангов (в логарифмическом масштабе), "
                            "поэтому в разных областях отклонения могут иметь разный знак.")
    first = reg[0]["ratio_to_zipf"]
    t["head_note"] = ("На ваших данных на рангах 1–10 фактическая частота %s, что согласуется с этой причиной." % phrase(first)
                      if first < 0.8 else
                      "На ваших данных в голове (ранги 1–10) этого эффекта не видно: фактическая частота %s." % phrase(first))
    zl = z["C"] / v
    zl = z["C"] / v
    t["zipf_at_last"] = "C/%s ≈ %s, то есть %s" % (num(v), num(zl), "меньше единицы" if zl < 1 else "не меньше единицы")
    if res["hapax_terms"]:
        t["hapax_note"] = ("В вашем корпусе %s терминов (%s словаря) встречаются один раз, полка начинается с ранга %s (%s словаря)." % (
            t["hapax_terms"], t["hapax_share"], t["plateau_start"], pct(res["plateau_start_rank"] / v)))
    else:
        t["hapax_note"] = "В вашем корпусе терминов с частотой 1 нет, поэтому полки на графике нет."
    factor = 10 ** z["rmse_log10"]
    if z["rmse_log10"] < 0.1:
        adj = "хорошо"
    elif z["rmse_log10"] < 0.3:
        adj = "приближённо"
    else:
        adj = "грубо"
    t["powerlaw_conclusion"] = ("Степенной закон со свободным показателем даёт *s* = %s, R² закона Ципфа в логарифмическом масштабе равен %s." % (
        t["pl_s"], t["zipf_r2"]))
    t["zipf_conclusion"] = ("Классический закон Ципфа (*s* = 1) описывает корпус %s: в среднем по точкам подгонки фактическая частота "
                            "отличается от предсказанной в %.1f раза (RMSE %s порядка)." % (adj, factor, t["zipf_rmse"]))
    ratio = z["rmse_log10"] / mb["rmse_log10"] if mb["rmse_log10"] > 0 else float("inf")
    if ratio >= 1.5:
        t["mb_conclusion"] = ("Закон Мандельброта описывает распределение заметно лучше: RMSE %s порядка против %s у Ципфа; "
                              "сдвиг ранга ρ = %s учитывает форму головы распределения." % (t["mb_rmse"], t["zipf_rmse"], t["mb_rho"]))
    elif ratio >= 1.2:
        t["mb_conclusion"] = "Закон Мандельброта описывает распределение немного лучше: RMSE %s порядка против %s у Ципфа." % (t["mb_rmse"], t["zipf_rmse"])
    else:
        t["mb_conclusion"] = "Закон Мандельброта на этих данных не лучше закона Ципфа (RMSE %s против %s)." % (t["mb_rmse"], t["zipf_rmse"])
    if ratio >= 1.2:
        t["mb_vs_zipf"] = ("Среднеквадратичное отклонение в логарифмах у закона Мандельброта %s порядка, у закона Ципфа %s: "
                           "Мандельброт точнее в %.1f раза." % (t["mb_rmse"], t["zipf_rmse"], ratio))
    else:
        t["mb_vs_zipf"] = "На этих данных закон Мандельброта не точнее закона Ципфа (RMSE %s против %s)." % (t["mb_rmse"], t["zipf_rmse"])
    if res["hapax_terms"]:
        t["hapax_conclusion"] = ("Полку из терминов с частотой 1 (%s словаря) ни один из законов не описывает: это эффект дискретности "
                                 "частот и конечности корпуса, а не недостаток подгонки." % t["hapax_share"])
    else:
        t["hapax_conclusion"] = "Терминов с частотой 1 в корпусе нет, полка из единичных частот отсутствует."
    t["practical_conclusion"] = "Десять самых частых терминов покрывают %s токенов корпуса, а термины с частотой 1 составляют %s словаря." % (
        t["top10_share"], t["hapax_share"])
    if res["top10_share_of_tokens"] >= 0.1 and res["hapax_share_of_terms"] >= 0.3:
        t["practical_conclusion"] += (" Небольшое число терминов покрывает значительную долю токенов, а большая часть словаря редкие термины: "
                                      "это оправдывает стоп-слова и сжатие индекса и показывает, что качество поиска определяют редкие термины.")
    return string.Template(template_text).substitute(t)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--stats", default="data/zipf.json")
    ap.add_argument("--template", default=os.path.join(here, "report_template.md"))
    ap.add_argument("--img-zipf", default="data/zipf.png")
    ap.add_argument("--img-mandelbrot", default="data/zipf_mandelbrot.png")
    ap.add_argument("--student", required=True)
    ap.add_argument("--group", required=True)
    ap.add_argument("--category", default="ЗАПОЛНИТЬ (тема корпуса ЛР1)")
    ap.add_argument("-o", "--output", default="report.md")
    a = ap.parse_args()
    with open(a.stats, encoding="utf-8") as f:
        res = json.load(f)
    with open(a.template, encoding="utf-8") as f:
        tpl = f.read()
    with open(a.output, "w", encoding="utf-8") as f:
        f.write(render(res, a.student, a.group, a.category, a.img_zipf, a.img_mandelbrot, tpl))


if __name__ == "__main__":
    main()
