#!/usr/bin/env python3
"""Закон Ципфа для корпуса: распределение терминов по частотам, подгонка Ципфа и Мандельброта.

Вход: токены (по одному на строку; вывод токенизатора ЛР3 с --lower) либо, с --uniq,
вывод `sort | uniq -c` (строки «число токен») - так обрабатываются корпуса, для которых
счётчик терминов не помещается в память.

Модели (f - частота, r - ранг термина в списке по убыванию частоты):
  Ципф:        f = C / r                  (C подбирается по МНК в логарифмах при s = 1)
  степенная:   f = C / r^s                (то же, но показатель s свободный)
  Мандельброт: f = P / (r + rho)^B
Подгонка идёт в логарифмическом масштабе по точкам, равномерно расставленным по логарифму ранга:
иначе хвост (почти все ранги) задавил бы голову.
"""
import argparse
import collections
import json
import math
import os
import sys


# ---------- подсчёт ----------
def read_counts(lines, uniq=False):
    """Возвращает (Counter термин -> частота, число пропущенных строк)."""
    c, bad = collections.Counter(), 0
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if uniq:
            n, _, term = line.partition(" ")
            term = term.strip()
            if not n.isdigit() or not term or int(n) < 1:
                bad += 1
                continue
            c[term] += int(n)
        else:
            c[line] += 1
    return c, bad


def ranked(counter):
    """Список (термин, частота) по убыванию частоты; при равенстве - по термину (детерминированно)."""
    return sorted(counter.items(), key=lambda kv: (-kv[1], kv[0]))


# ---------- математика ----------
def sample_ranks(v, k=400, lo=1, hi=None):
    """Не более ~k рангов из [lo, hi], равномерно по логарифму, включая границы."""
    hi = min(hi or v, v)
    lo = max(1, lo)
    if hi < lo:
        return []
    if hi - lo + 1 <= k:
        return list(range(lo, hi + 1))
    a, b = math.log(lo), math.log(hi)
    pts = {lo, hi}
    for i in range(k):
        pts.add(int(round(math.exp(a + (b - a) * i / (k - 1)))))
    return sorted(p for p in pts if lo <= p <= hi)


def linreg(xs, ys):
    """МНК y = a + b*x. Возвращает (a, b)."""
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    b = sxy / sxx if sxx else 0.0
    return my - b * mx, b


def quality(ys, preds):
    """RMSE и R^2 в логарифмическом масштабе (единицы: порядки десятичные)."""
    n = len(ys)
    my = sum(ys) / n
    ss_res = sum((y - p) ** 2 for y, p in zip(ys, preds))
    ss_tot = sum((y - my) ** 2 for y in ys)
    return {"rmse_log10": math.sqrt(ss_res / n), "r2": (1 - ss_res / ss_tot) if ss_tot else 1.0}


def fit_zipf(freqs, ranks):
    """f = C / r (s = 1). C - среднее геометрическое f*r по выбранным рангам."""
    ys = [math.log10(freqs[r - 1]) for r in ranks]
    xs = [math.log10(r) for r in ranks]
    log_c = sum(y + x for x, y in zip(xs, ys)) / len(ys)
    out = {"C": 10 ** log_c, "s": 1.0}
    out.update(quality(ys, [log_c - x for x in xs]))
    return out


def fit_powerlaw(freqs, ranks):
    """f = C / r^s со свободным показателем."""
    ys = [math.log10(freqs[r - 1]) for r in ranks]
    xs = [math.log10(r) for r in ranks]
    a, b = linreg(xs, ys)
    out = {"C": 10 ** a, "s": -b}
    out.update(quality(ys, [a + b * x for x in xs]))
    return out


def _mandelbrot_for_rho(ranks, ys, rho):
    xs = [math.log10(r + rho) for r in ranks]
    a, b = linreg(xs, ys)
    sse = sum((y - (a + b * x)) ** 2 for x, y in zip(xs, ys))
    return sse, a, b


def fit_mandelbrot(freqs, ranks, rho_max=None):
    """f = P / (r + rho)^B. Для фиксированного rho P и B находятся регрессией,
    rho - сеткой по логарифму и золотым сечением внутри лучшей ячейки."""
    ys = [math.log10(freqs[r - 1]) for r in ranks]
    rho_max = rho_max or max(10.0, float(ranks[-1]))
    grid = [0.0] + [10 ** (k / 8) for k in range(0, int(8 * math.log10(rho_max)) + 1)]
    sse = [_mandelbrot_for_rho(ranks, ys, g)[0] for g in grid]
    i = min(range(len(grid)), key=sse.__getitem__)
    lo, hi = grid[max(0, i - 1)], grid[min(len(grid) - 1, i + 1)]
    phi = (math.sqrt(5) - 1) / 2
    c, d = hi - phi * (hi - lo), lo + phi * (hi - lo)
    fc, fd = _mandelbrot_for_rho(ranks, ys, c)[0], _mandelbrot_for_rho(ranks, ys, d)[0]
    for _ in range(60):
        if fc < fd:
            hi, d, fd = d, c, fc
            c = hi - phi * (hi - lo)
            fc = _mandelbrot_for_rho(ranks, ys, c)[0]
        else:
            lo, c, fc = c, d, fd
            d = lo + phi * (hi - lo)
            fd = _mandelbrot_for_rho(ranks, ys, d)[0]
    rho = (lo + hi) / 2
    _, a, b = _mandelbrot_for_rho(ranks, ys, rho)
    out = {"P": 10 ** a, "log10_P": a, "B": -b, "rho": rho}
    out.update(quality(ys, [a + b * math.log10(r + rho) for r in ranks]))
    return out


# ---------- анализ расхождений ----------
def region_ratios(freqs, c_zipf):
    """Среднее геометрическое «фактическая частота / предсказанная Ципфом» по областям рангов
    1-10, 11-100, 101-1000, ... до последнего ранга."""
    v, out, lo, hi = len(freqs), [], 1, 10
    while lo <= v:
        top = min(hi, v)
        n = top - lo + 1
        s = sum(math.log10(freqs[r - 1] * r / c_zipf) for r in range(lo, top + 1))
        out.append({"from": lo, "to": top, "ratio_to_zipf": 10 ** (s / n)})
        lo, hi = hi + 1, hi * 10
    return out


def checkpoints(freqs, zipf, mand):
    v = len(freqs)
    pts = [r for r in [1, 2, 3, 5, 10, 30, 100, 300, 1000, 3000, 10000, 30000, 100000, 300000, 1000000] if r <= v]
    if v not in pts:
        pts.append(v)
    rows = []
    for r in pts:
        z = zipf["C"] / r
        m = mand["P"] / (r + mand["rho"]) ** mand["B"] if mand else None
        rows.append({"rank": r, "freq": freqs[r - 1], "zipf": z, "mandelbrot": m, "ratio_to_zipf": freqs[r - 1] / z})
    return rows


def analyse(items, points=400, fit_lo=1, fit_hi=0):
    """items - ранжированный список (термин, частота). Возвращает словарь результатов."""
    freqs = [f for _, f in items]
    v, n = len(freqs), sum(freqs)
    ranks = sample_ranks(v, points, fit_lo, fit_hi or None)
    if len(ranks) < 5:
        raise ValueError("слишком мало терминов для подгонки (нужно хотя бы 5 различных рангов)")
    z, pl, mb = fit_zipf(freqs, ranks), fit_powerlaw(freqs, ranks), fit_mandelbrot(freqs, ranks)
    hapax = sum(1 for f in freqs if f == 1)
    plateau = next((i + 1 for i, f in enumerate(freqs) if f == 1), None)
    return {
        "tokens": n, "terms": v, "top_freq": freqs[0],
        "hapax_terms": hapax, "hapax_share_of_terms": hapax / v, "plateau_start_rank": plateau,
        "top10_share_of_tokens": sum(freqs[:10]) / n,
        "fit": {"rank_from": ranks[0], "rank_to": ranks[-1], "points": len(ranks)},
        "zipf": z, "powerlaw": pl, "mandelbrot": mb,
        "regions": region_ratios(freqs, z["C"]),
        "checkpoints": checkpoints(freqs, z, mb),
    }


# ---------- графики ----------
def plot(items, res, path_zipf, path_mandelbrot):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    freqs = [f for _, f in items]
    v = len(freqs)
    shown = sorted(set(sample_ranks(v, 3000)) | set(range(1, min(v, 1000) + 1)))
    xs, ys = shown, [freqs[r - 1] for r in shown]
    z, pl, mb = res["zipf"], res["powerlaw"], res["mandelbrot"]
    grid = sample_ranks(v, 300)

    def base(title):
        fig, ax = plt.subplots(figsize=(7, 4.4))
        ax.loglog(xs, ys, ".", ms=3, color="#4c72b0", label="корпус", rasterized=True)
        ax.set_xlabel("ранг термина r"); ax.set_ylabel("частота f")
        ax.set_title(title, fontsize=10); ax.grid(True, which="both", alpha=.25)
        return fig, ax
    fig, ax = base("Распределение терминов по частотам и закон Ципфа")
    ax.loglog(grid, [z["C"] / r for r in grid], "-", color="#dd8452", lw=1.6,
              label="Ципф: f = C/r, C = %.3g" % z["C"])
    ax.loglog(grid, [pl["C"] / r ** pl["s"] for r in grid], "--", color="#55a868", lw=1.4,
              label="степенная: f = C/r^s, s = %.3f" % pl["s"])
    ax.legend(fontsize=8); fig.tight_layout(); fig.savefig(path_zipf, dpi=150); plt.close(fig)
    fig, ax = base("Закон Ципфа и закон Мандельброта")
    ax.loglog(grid, [z["C"] / r for r in grid], "-", color="#dd8452", lw=1.4, label="Ципф: f = C/r")
    ax.loglog(grid, [mb["P"] / (r + mb["rho"]) ** mb["B"] for r in grid], "-", color="#c44e52", lw=1.6,
              label="Мандельброт: P = %.3g, B = %.3f, ρ = %.3g" % (mb["P"], mb["B"], mb["rho"]))
    ax.legend(fontsize=8); fig.tight_layout(); fig.savefig(path_mandelbrot, dpi=150); plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input", help="файл с токенами (токен на строку) или '-'")
    ap.add_argument("--uniq", action="store_true", help="вход - вывод `sort | uniq -c`")
    ap.add_argument("--outdir", default="data")
    ap.add_argument("--points", type=int, default=400, help="число точек подгонки (равномерно по log r)")
    ap.add_argument("--fit-min-rank", type=int, default=1)
    ap.add_argument("--fit-max-rank", type=int, default=0, help="0 - до последнего ранга")
    ap.add_argument("--no-plot", action="store_true")
    a = ap.parse_args()

    f = sys.stdin if a.input == "-" else open(a.input, encoding="utf-8")
    with f:
        counter, bad = read_counts(f, a.uniq)
    if not counter:
        print("zipf: во входных данных нет токенов", file=sys.stderr)
        return 1
    items = ranked(counter)
    try:
        res = analyse(items, a.points, a.fit_min_rank, a.fit_max_rank)
    except ValueError as e:
        print("zipf: %s" % e, file=sys.stderr)
        return 1
    res["bad_input_lines"] = bad
    os.makedirs(a.outdir, exist_ok=True)
    with open(os.path.join(a.outdir, "freq.tsv"), "w", encoding="utf-8") as g:
        for i, (t, c) in enumerate(items, 1):
            g.write("%d\t%s\t%d\n" % (i, t, c))
    with open(os.path.join(a.outdir, "zipf.json"), "w", encoding="utf-8") as g:
        json.dump(res, g, ensure_ascii=False, indent=2)
    if not a.no_plot:
        plot(items, res, os.path.join(a.outdir, "zipf.png"), os.path.join(a.outdir, "zipf_mandelbrot.png"))
    print(json.dumps({k: res[k] for k in ("tokens", "terms", "zipf", "powerlaw", "mandelbrot")},
                     ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
