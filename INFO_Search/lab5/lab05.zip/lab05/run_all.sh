#!/usr/bin/env bash
# Токены -> частоты и подгонка -> графики -> отчёт.
# Использование: ./run_all.sh ../lab03/data/tokens.txt "Иванов И. И." "М8О-101Б-23" "Тема корпуса"
# tokens.txt - вывод токенизатора ЛР3: ./tokenizer corpus.jsonl --input-format jsonl --lower > tokens.txt
set -euo pipefail
cd "$(dirname "$0")"
TOKENS=${1:?файл с токенами}; STUDENT=${2:?ФИО}; GROUP=${3:?группа}; CATEGORY=${4:?тема корпуса}
python3 zipf.py "$TOKENS" --outdir data
python3 make_report.py --student "$STUDENT" --group "$GROUP" --category "$CATEGORY"
./build_report.sh
