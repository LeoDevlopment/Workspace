#!/usr/bin/env bash
# Собирает report.docx (редактируемый) и report.pdf из report.md.
set -euo pipefail
cd "$(dirname "$0")"
pandoc report.md -o report.docx
soffice --headless --convert-to pdf report.docx >/dev/null
echo "готово: report.docx, report.pdf"
