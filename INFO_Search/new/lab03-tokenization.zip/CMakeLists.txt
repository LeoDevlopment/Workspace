cmake_minimum_required(VERSION 3.16)
project(lab03_tokenization LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(tokenizer src/tokenizer.cpp)
target_include_directories(tokenizer PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/src)

add_executable(tokenizer_cli src/main.cpp)
target_link_libraries(tokenizer_cli PRIVATE tokenizer)

add_executable(tokenizer_tests tests/test_tokenizer.cpp)
target_link_libraries(tokenizer_tests PRIVATE tokenizer)

enable_testing()
add_test(NAME tokenizer_unit_tests COMMAND tokenizer_tests)
