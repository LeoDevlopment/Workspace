#ifndef LAB03_TOKENIZER_H
#define LAB03_TOKENIZER_H

#include <cstddef>
#include <string>
#include <vector>

struct Token {
    std::string text;
    std::size_t position; // byte offset from the beginning of the original UTF-8 string
};

class Tokenizer {
public:
    // Splits UTF-8 text into normalized tokens. Positions are byte offsets.
    std::vector<Token> tokenize(const std::string& text) const;

    // Counts Unicode code points in a valid UTF-8 string (invalid bytes count as one).
    static std::size_t character_count(const std::string& text);
};

#endif
