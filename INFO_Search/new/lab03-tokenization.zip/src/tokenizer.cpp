#include "tokenizer.h"

#include <cstdint>

namespace {
struct CodePoint {
    std::uint32_t value;
    std::size_t length;
    bool valid;
};

CodePoint decode_utf8(const std::string& s, std::size_t i) {
    const auto b0 = static_cast<unsigned char>(s[i]);
    if (b0 < 0x80) return {b0, 1, true};

    std::size_t len = 0;
    std::uint32_t cp = 0;
    if ((b0 & 0xE0) == 0xC0) { len = 2; cp = b0 & 0x1F; }
    else if ((b0 & 0xF0) == 0xE0) { len = 3; cp = b0 & 0x0F; }
    else if ((b0 & 0xF8) == 0xF0) { len = 4; cp = b0 & 0x07; }
    else return {b0, 1, false};

    if (i + len > s.size()) return {b0, 1, false};
    for (std::size_t j = 1; j < len; ++j) {
        const auto b = static_cast<unsigned char>(s[i + j]);
        if ((b & 0xC0) != 0x80) return {b0, 1, false};
        cp = (cp << 6) | (b & 0x3F);
    }
    // Reject overlong encodings, surrogates and values outside Unicode.
    if ((len == 2 && cp < 0x80) || (len == 3 && cp < 0x800) ||
        (len == 4 && cp < 0x10000) || (cp >= 0xD800 && cp <= 0xDFFF) || cp > 0x10FFFF)
        return {b0, 1, false};
    return {cp, len, true};
}

void append_utf8(std::string& out, std::uint32_t cp) {
    if (cp <= 0x7F) out.push_back(static_cast<char>(cp));
    else if (cp <= 0x7FF) {
        out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else if (cp <= 0xFFFF) {
        out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else {
        out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
}

bool is_letter(std::uint32_t cp) {
    if ((cp >= 'A' && cp <= 'Z') || (cp >= 'a' && cp <= 'z')) return true;
    // Latin, Greek and Cyrillic blocks commonly found in mixed-language corpora.
    if ((cp >= 0x00C0 && cp <= 0x02AF) ||
        (cp >= 0x0370 && cp <= 0x03FF) ||
        (cp >= 0x0400 && cp <= 0x052F)) return true;
    return false;
}

bool is_digit(std::uint32_t cp) { return cp >= '0' && cp <= '9'; }
bool is_word_base(std::uint32_t cp) { return is_letter(cp) || is_digit(cp); }
bool is_connector(std::uint32_t cp) { return cp == '-' || cp == '\'' || cp == 0x2019; }

std::uint32_t to_lower(std::uint32_t cp) {
    if (cp >= 'A' && cp <= 'Z') return cp + 0x20;
    if ((cp >= 0x00C0 && cp <= 0x00D6) || (cp >= 0x00D8 && cp <= 0x00DE)) return cp + 0x20;
    if (cp == 0x0178) return 0x00FF;
    // Regular uppercase/lowercase pairs in Latin Extended-A.
    if (((cp >= 0x0100 && cp <= 0x012F) || (cp >= 0x0132 && cp <= 0x0137) ||
         (cp >= 0x014A && cp <= 0x0177)) && cp % 2 == 0) return cp + 1;
    if (((cp >= 0x0139 && cp <= 0x0148) || (cp >= 0x0179 && cp <= 0x017E)) && cp % 2 == 1) return cp + 1;
    if (cp >= 0x0391 && cp <= 0x03A1) return cp + 0x20;
    if (cp >= 0x03A3 && cp <= 0x03AB) return cp + 0x20;
    if (cp >= 0x0410 && cp <= 0x042F) return cp + 0x20;
    if (cp >= 0x0400 && cp <= 0x040F) return cp + 0x50;
    return cp;
}

struct DecodedAt { std::uint32_t cp; std::size_t length; bool valid; };
DecodedAt at(const std::string& s, std::size_t i) {
    const auto d = decode_utf8(s, i);
    return {d.value, d.length, d.valid};
}
} // namespace

std::vector<Token> Tokenizer::tokenize(const std::string& text) const {
    std::vector<Token> result;
    std::string current;
    std::size_t start = 0;
    std::size_t letters_and_digits = 0;
    bool has_letter = false;

    auto flush = [&]() {
        // A token must contain at least two alphanumeric code points and a letter.
        if (!current.empty() && letters_and_digits >= 2 && has_letter)
            result.push_back({current, start});
        current.clear();
        letters_and_digits = 0;
        has_letter = false;
    };

    for (std::size_t i = 0; i < text.size();) {
        const auto d = at(text, i);
        if (d.valid && is_word_base(d.cp)) {
            if (current.empty()) start = i;
            append_utf8(current, to_lower(d.cp));
            ++letters_and_digits;
            has_letter = has_letter || is_letter(d.cp);
            i += d.length;
            continue;
        }

        // Keep a single hyphen/apostrophe only when it is internal to a word.
        if (d.valid && is_connector(d.cp) && !current.empty() && i + d.length < text.size()) {
            const auto next = at(text, i + d.length);
            if (next.valid && is_word_base(next.cp)) {
                append_utf8(current, d.cp);
                i += d.length;
                continue;
            }
        }

        flush();
        i += d.length;
    }
    flush();
    return result;
}

std::size_t Tokenizer::character_count(const std::string& text) {
    std::size_t count = 0;
    for (std::size_t i = 0; i < text.size();) {
        const auto d = decode_utf8(text, i);
        i += d.length;
        ++count;
    }
    return count;
}
