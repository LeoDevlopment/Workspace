#include "tokenizer.h"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>

namespace fs = std::filesystem;

std::string read_file(const fs::path& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("Cannot open file: " + path.string());
    return std::string(std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>());
}

void print_tokens(const fs::path& file) {
    Tokenizer tokenizer;
    const auto text = read_file(file);
    const auto tokens = tokenizer.tokenize(text);
    for (const auto& token : tokens)
        std::cout << token.position << '\t' << token.text << '\n';
}

void print_stats(const fs::path& root) {
    if (!fs::exists(root) || !fs::is_directory(root))
        throw std::runtime_error("Text directory does not exist: " + root.string());

    Tokenizer tokenizer;
    std::uintmax_t total_bytes = 0;
    std::size_t documents = 0, total_tokens = 0, total_token_chars = 0;
    const auto begin = std::chrono::steady_clock::now();

    for (const auto& entry : fs::recursive_directory_iterator(root)) {
        if (!entry.is_regular_file() || entry.path().extension() != ".txt") continue;
        const std::string text = read_file(entry.path());
        const auto tokens = tokenizer.tokenize(text);
        ++documents;
        total_bytes += text.size();
        total_tokens += tokens.size();
        for (const auto& token : tokens) total_token_chars += Tokenizer::character_count(token.text);
    }

    const auto end = std::chrono::steady_clock::now();
    const double seconds = std::chrono::duration<double>(end - begin).count();
    const double kb = static_cast<double>(total_bytes) / 1024.0;
    const double avg_len = total_tokens ? static_cast<double>(total_token_chars) / total_tokens : 0.0;
    const double speed = seconds > 0.0 ? kb / seconds : 0.0;

    std::cout << std::fixed << std::setprecision(3)
              << "Documents: " << documents << '\n'
              << "Input bytes: " << total_bytes << '\n'
              << "Input KB: " << kb << '\n'
              << "Tokens: " << total_tokens << '\n'
              << "Average token length (Unicode characters): " << avg_len << '\n'
              << "Elapsed seconds: " << std::setprecision(6) << seconds << '\n'
              << "Throughput (KB/s): " << std::setprecision(3) << speed << '\n';
}

int main(int argc, char** argv) {
    try {
        if (argc == 3 && std::string(argv[1]) == "--file") print_tokens(argv[2]);
        else if (argc == 3 && std::string(argv[1]) == "--stats") print_stats(argv[2]);
        else {
            std::cerr << "Usage:\n  tokenizer_cli --file <file.txt>\n  tokenizer_cli --stats <text_directory>\n";
            return 2;
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << '\n';
        return 1;
    }
    return 0;
}
