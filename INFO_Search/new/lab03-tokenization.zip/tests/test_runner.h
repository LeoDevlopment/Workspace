#ifndef LAB03_TEST_RUNNER_H
#define LAB03_TEST_RUNNER_H
#include <functional>
#include <iostream>
#include <string>
#include <vector>

struct TestCase { std::string name; std::function<void()> run; };
inline std::vector<TestCase>& test_cases() { static std::vector<TestCase> tests; return tests; }
struct TestRegistrar {
    TestRegistrar(const std::string& name, std::function<void()> fn) { test_cases().push_back({name, fn}); }
};
#define TEST(name) void name(); static TestRegistrar reg_##name(#name, name); void name()
#define EXPECT_TRUE(x) do { if (!(x)) throw std::runtime_error(std::string("EXPECT_TRUE failed: ") + #x); } while (0)
#define EXPECT_EQ(a,b) do { const auto& va=(a); const auto& vb=(b); if (!(va==vb)) throw std::runtime_error(std::string("EXPECT_EQ failed: ") + #a + " != " + #b); } while (0)
#endif
