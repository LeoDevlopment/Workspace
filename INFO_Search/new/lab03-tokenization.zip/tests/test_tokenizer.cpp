#include "../src/tokenizer.h"
#include "test_runner.h"
#include <stdexcept>

TEST(empty_input_returns_no_tokens) {
    Tokenizer t;
    EXPECT_TRUE(t.tokenize("").empty());
}

TEST(ascii_words_are_lowercased) {
    Tokenizer t;
    const auto v = t.tokenize("Hello WORLD");
    EXPECT_EQ(v.size(), 2u);
    EXPECT_EQ(v[0].text, std::string("hello"));
    EXPECT_EQ(v[1].text, std::string("world"));
}

TEST(cyrillic_and_yo_are_lowercased) {
    Tokenizer t;
    const auto v = t.tokenize(u8"МОСКВА ЁЖ");
    EXPECT_EQ(v.size(), 2u);
    EXPECT_EQ(v[0].text, std::string(u8"москва"));
    EXPECT_EQ(v[1].text, std::string(u8"ёж"));
}

TEST(latin1_accented_letters_are_lowercased) {
    Tokenizer t;
    const auto v = t.tokenize(u8"CAFÉ ÉCOLE");
    EXPECT_EQ(v.size(), 2u);
    EXPECT_EQ(v[0].text, std::string(u8"café"));
    EXPECT_EQ(v[1].text, std::string(u8"école"));
    const auto extended = t.tokenize(u8"ĀBC");
    EXPECT_EQ(extended[0].text, std::string(u8"ābc"));
}

TEST(punctuation_separates_tokens) {
    Tokenizer t;
    const auto v = t.tokenize("alpha,beta! gamma?delta.");
    EXPECT_EQ(v.size(), 4u);
    EXPECT_EQ(v[0].text, std::string("alpha"));
    EXPECT_EQ(v[1].text, std::string("beta"));
    EXPECT_EQ(v[2].text, std::string("gamma"));
    EXPECT_EQ(v[3].text, std::string("delta"));
}

TEST(internal_hyphen_and_apostrophe_are_preserved) {
    Tokenizer t;
    const auto v = t.tokenize("state-of-the-art traveler's O’Neil");
    EXPECT_EQ(v.size(), 3u);
    EXPECT_EQ(v[0].text, std::string("state-of-the-art"));
    EXPECT_EQ(v[1].text, std::string("traveler's"));
    EXPECT_EQ(v[2].text, std::string(u8"o’neil"));
}

TEST(numbers_only_and_single_character_tokens_are_filtered) {
    Tokenizer t;
    const auto v = t.tokenize("a I 7 2025 A7 42b");
    EXPECT_EQ(v.size(), 2u);
    EXPECT_EQ(v[0].text, std::string("a7"));
    EXPECT_EQ(v[1].text, std::string("42b"));
}

TEST(byte_positions_are_preserved_for_utf8) {
    Tokenizer t;
    const std::string input = u8"Ёж cat";
    const auto v = t.tokenize(input);
    EXPECT_EQ(v.size(), 2u);
    EXPECT_EQ(v[0].position, 0u);
    EXPECT_EQ(v[1].position, 5u); // Ёж = 4 UTF-8 bytes, then one space
}

TEST(mixed_cyrillic_and_latin_text) {
    Tokenizer t;
    const auto v = t.tokenize(u8"Поиск information retrieval");
    EXPECT_EQ(v.size(), 3u);
    EXPECT_EQ(v[0].text, std::string(u8"поиск"));
    EXPECT_EQ(v[1].text, std::string("information"));
    EXPECT_EQ(v[2].text, std::string("retrieval"));
}

TEST(malformed_utf8_does_not_crash_or_join_words) {
    Tokenizer t;
    std::string input = "ab";
    input.push_back(static_cast<char>(0xFF));
    input += "cd";
    const auto v = t.tokenize(input);
    EXPECT_EQ(v.size(), 2u);
    EXPECT_EQ(v[0].text, std::string("ab"));
    EXPECT_EQ(v[1].text, std::string("cd"));
}

TEST(character_count_counts_codepoints_not_bytes) {
    EXPECT_EQ(Tokenizer::character_count(u8"ёж"), 2u);
    EXPECT_EQ(Tokenizer::character_count("abc"), 3u);
}

int main() {
    std::size_t passed = 0;
    for (const auto& test : test_cases()) {
        try { test.run(); ++passed; std::cout << "[PASS] " << test.name << '\n'; }
        catch (const std::exception& e) { std::cout << "[FAIL] " << test.name << ": " << e.what() << '\n'; }
    }
    std::cout << "\nResult: " << passed << '/' << test_cases().size() << " tests passed\n";
    return passed == test_cases().size() ? 0 : 1;
}
