#ifndef MAI_ZIPF_H
#define MAI_ZIPF_H
#include <cstddef>
#include <map>
#include <string>
#include <vector>
struct TermFrequency { std::string term; std::size_t frequency; };
class ZipfAnalyzer {
    std::map<std::string,std::size_t> frequencies_;
    std::size_t total_=0;
public:
    void add(const std::string& term);
    std::vector<TermFrequency> ranked() const;
    std::size_t totalTokens() const{return total_;}
    std::size_t vocabularySize() const{return frequencies_.size();}
    double zipfConstant() const;
    static double theoreticalFrequency(double c,std::size_t rank);
};
#endif
