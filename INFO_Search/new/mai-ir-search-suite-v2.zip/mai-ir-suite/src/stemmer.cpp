#include "stemmer.h"
#include <algorithm>
#include <vector>

namespace {
bool vowelAt(const std::string& s, std::size_t p) {
    if (p+1>=s.size()) return false;
    const std::string c=s.substr(p,2);
    return c=="а"||c=="е"||c=="ё"||c=="и"||c=="о"||c=="у"||c=="ы"||c=="э"||c=="ю"||c=="я";
}
std::size_t rvStart(const std::string& s) {
    for(std::size_t i=0;i+1<s.size();){ unsigned char c=s[i]; std::size_t n=(c<0x80?1:(c<0xE0?2:(c<0xF0?3:4))); if(vowelAt(s,i)) return i+n; i+=n; }
    return s.size();
}
bool cut(std::string& s,std::size_t rv,const std::vector<std::string>& suffixes) {
    for(const auto& x:suffixes) if(s.size()>=rv+x.size() && s.compare(s.size()-x.size(),x.size(),x)==0){s.erase(s.size()-x.size());return true;} return false;
}
}
std::string RussianStemmer::stem(const std::string& input) const {
    if(input.size()<4 || input.find("\xD0")==std::string::npos && input.find("\xD1")==std::string::npos) return input;
    std::string w=input; const std::size_t rv=rvStart(w);
    // Step 1: perfective gerund, reflexive, adjective, verb, then noun endings.
    if(!cut(w,rv,{"ивши","ывши","ившись","ывшись","ив","ыв","вшись","вши","в"})) {
        cut(w,rv,{"ся","сь"});
        bool adj=cut(w,rv,{"ее","ие","ые","ое","ими","ыми","ей","ий","ый","ой","ем","им","ым","ом","его","ого","ему","ому","их","ых","ую","юю","ая","яя","ою","ею"});
        if(!adj && !cut(w,rv,{"ла","на","ете","йте","ли","й","л","ем","н","ло","но","ет","ют","ть","ешь","нно","ила","ыла","ена","ейте","уйте","ит","ыт","ишь","ую","ю","ат","ят","ует","уют"}))
            cut(w,rv,{"иями","ями","ами","ией","иям","ием","иях","ев","ов","ие","ье","еи","ии","ей","ой","ий","й","ия","ья","я","а","е","и","о","у","ы","ь","ю","ею","ом","ем","ам","ям","ах","ях","ей","ою","ею"});
    }
    // Step 2: remove terminal и.
    cut(w,rv,{"и"});
    // Step 3: derivational suffixes in R2 (approximated by RV for compact implementation).
    cut(w,rv,{"ость","ост"});
    // Step 4: superlative, doubled н, soft sign.
    if(!cut(w,rv,{"ейше","ейш"})) { if(w.size()>=4 && w.compare(w.size()-4,4,"нн")==0) w.erase(w.size()-2); else cut(w,rv,{"ь"}); }
    return w.empty()?input:w;
}
