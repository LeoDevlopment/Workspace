#ifndef MAI_STEMMER_H
#define MAI_STEMMER_H
#include <string>
class RussianStemmer { public: std::string stem(const std::string& word) const; };
#endif
