#ifndef MAI_INDEX_H
#define MAI_INDEX_H
#include <cstddef>
#include <memory>
#include <string>
#include <vector>

struct Document { std::string path; };
class BooleanIndex {
    struct Entry { std::string term; std::vector<int> docs; bool occupied=false; };
    std::unique_ptr<Entry[]> table_;
    std::size_t capacity_=1024, size_=0;
    std::vector<Document> docs_;
    static std::size_t hash(const std::string& s);
    Entry* find(const std::string& term);
    const Entry* find(const std::string& term) const;
    void grow();
public:
    BooleanIndex();
    void clear();
    void addDocument(const std::string& path,const std::vector<std::string>& terms);
    bool save(const std::string& file) const;
    bool load(const std::string& file);
    std::vector<int> evaluate(const std::string& query,std::string& error) const;
    const std::vector<Document>& documents() const{return docs_;}
    std::size_t vocabularySize() const{return size_;}
    std::size_t postingFrequency(const std::string& term) const;
};
#endif
