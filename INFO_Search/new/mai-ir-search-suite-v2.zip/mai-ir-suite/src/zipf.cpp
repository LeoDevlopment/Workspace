#include "zipf.h"
#include <algorithm>
void ZipfAnalyzer::add(const std::string&t){if(t.empty())return;++frequencies_[t];++total_;}
std::vector<TermFrequency> ZipfAnalyzer::ranked()const{std::vector<TermFrequency>v;v.reserve(frequencies_.size());for(const auto&p:frequencies_)v.push_back({p.first,p.second});std::sort(v.begin(),v.end(),[](const TermFrequency&a,const TermFrequency&b){return a.frequency!=b.frequency?a.frequency>b.frequency:a.term<b.term;});return v;}
double ZipfAnalyzer::zipfConstant()const{auto v=ranked();return v.empty()?0.0:(double)v.front().frequency;}
double ZipfAnalyzer::theoreticalFrequency(double c,std::size_t r){return r?c/(double)r:0.0;}
