#include "tokenizer.h"
#include "stemmer.h"
#include "index.h"
#include "zipf.h"
#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <cstdio>
#include <functional>
static int passed=0,failed=0;
static void test(const char*n,const std::function<bool()>&f){bool ok=false;try{ok=f();}catch(...){ok=false;}std::cout<<(ok?"[PASS] ":"[FAIL] ")<<n<<"\n";ok?++passed:++failed;}
int main(int argc,char**argv){std::string group=argc>1?argv[1]:"all";auto run=[&](const std::string&g){return group=="all"||group==g;};
 if(run("tokenizer")){Tokenizer t;test("tokenizer: Cyrillic lowercase",[&]{auto x=t.tokenize("МАШИНЫ и ДОРОГИ");return x.size()==2&&x[0].text=="машины";});test("tokenizer: punctuation splitting",[&]{return t.tokenize("hello, world!").size()==2;});test("tokenizer: positions in UTF-8",[&]{auto x=t.tokenize("я hello");return x.size()==1&&x[0].position==3;});test("tokenizer: empty text",[&]{return t.tokenize("").empty();});}
 if(run("stemmer")){RussianStemmer s;test("stemmer: inflection family",[&]{return s.stem("машины")==s.stem("машинам")&&s.stem("работали")==s.stem("работать");});test("stemmer: English remains unchanged",[&]{return s.stem("running")=="running";});test("stemmer: short word safe",[&]{return s.stem("дом")=="дом";});test("stemmer: deterministic",[&]{return s.stem("красивыми")==s.stem("красивыми");});}
 if(run("zipf")){test("zipf: frequency counting",[]{ZipfAnalyzer z;for(auto*w:{"a","b","a","c","a","b"})z.add(w);return z.totalTokens()==6&&z.vocabularySize()==3&&z.ranked()[0].term=="a"&&z.ranked()[0].frequency==3;});test("zipf: ranking by frequency",[]{ZipfAnalyzer z;z.add("low");z.add("high");z.add("high");auto r=z.ranked();return r.size()==2&&r[0].term=="high"&&r[1].term=="low";});test("zipf: theoretical frequency",[]{return ZipfAnalyzer::theoreticalFrequency(12,1)==12.0&&ZipfAnalyzer::theoreticalFrequency(12,3)==4.0&&ZipfAnalyzer::theoreticalFrequency(12,0)==0.0;});}
 if(run("index")||run("search")){BooleanIndex idx;idx.addDocument("d0",{"cat","pet"});idx.addDocument("d1",{"dog","pet"});idx.addDocument("d2",{"cat","wild"});if(run("index")){test("index: vocabulary size",[&]{return idx.vocabularySize()==4;});test("index: posting list document frequency",[&]{return idx.postingFrequency("cat")==2;});test("index: save/load round trip",[&]{bool a=idx.save("test_index.tmp");BooleanIndex copy;bool b=copy.load("test_index.tmp");std::remove("test_index.tmp");return a&&b&&copy.documents().size()==3&&copy.postingFrequency("pet")==2;});test("index: hash table grows",[]{BooleanIndex large;std::vector<std::string> terms;for(int i=0;i<1500;++i)terms.push_back("term_"+std::to_string(i));large.addDocument("large",terms);return large.vocabularySize()==1500&&large.postingFrequency("term_1499")==1;});}
 if(run("search")){std::string e;test("search: AND intersection",[&]{auto r=idx.evaluate("cat AND pet",e);return e.empty()&&r.size()==1&&r[0]==0;});test("search: OR union",[&]{auto r=idx.evaluate("cat OR dog",e);return e.empty()&&r.size()==3;});test("search: NOT complement",[&]{auto r=idx.evaluate("NOT cat",e);return e.empty()&&r.size()==1&&r[0]==1;});test("search: parentheses and precedence",[&]{auto r=idx.evaluate("cat OR dog AND wild",e);return e.empty()&&r.size()==2&&r[0]==0&&r[1]==2;});test("search: malformed query reports error",[&]{idx.evaluate("cat AND (dog",e);return !e.empty();});}}
 std::cout<<"\nИтого: "<<passed<<" PASS, "<<failed<<" FAIL\n";return failed?1:0;}
