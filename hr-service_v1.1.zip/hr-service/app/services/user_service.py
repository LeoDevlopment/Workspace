from uuid import UUID

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.permissions import Perm
from app.core.permissions_cache import get_user_permissions, invalidate_user_permissions
from app.core.security import generate_session_id, hash_password
from app.db.models import (
    InfoCardVisibility,
    PersonnelReserve,
    Position,
    Role,
    User,
    UserPermission,
    UserRole,
    UserStatus,
    Workplace,
)
from app.services.access_service import can_view_user_card


FIRED_CODE = "fired"


async def get_user_by_id(session: AsyncSession, user_id: UUID) -> User | None:
    return await session.get(User, user_id)


async def list_visible_users(
    session: AsyncSession,
    actor: User,
    *,
    include_fired: bool | None = None,
) -> list[User]:
    """
    Возвращает список пользователей, доступных для просмотра actor.
    Логика:
      - users.view_all или admin → все (в т.ч. уволенные при users.view_fired)
      - иначе: свой workplace + публичные карточки
      - уволенные скрыты, если нет users.view_fired
    """
    perms = await get_user_permissions(session, actor.id)
    can_all = Perm.USERS_VIEW_ALL.value in perms
    can_fired = Perm.USERS_VIEW_FIRED.value in perms

    stmt = select(User)
    if not can_all and not can_fired:
        # исключаем уволенных
        fired_status = await session.scalar(
            select(UserStatus).where(UserStatus.code == FIRED_CODE)
        )
        if fired_status is not None:
            stmt = stmt.where(User.status_id != fired_status.id)

    result = (await session.scalars(stmt.order_by(User.full_name))).all()

    visible: list[User] = []
    for u in result:
        if await can_view_user_card(session, actor, u):
            visible.append(u)
    return visible


async def create_user(
    session: AsyncSession,
    *,
    login: str,
    email: str | None,
    full_name: str,
    phone: str | None,
    schedule: str | None,
    position_id: UUID | None,
    workplace_id: UUID | None,
    status_id: UUID,
    password: str,
    created_by: User,
    role_ids: list[UUID] | None = None,
) -> User:
    user = User(
        login=login,
        email=email,
        full_name=full_name,
        phone=phone,
        schedule=schedule,
        position_id=position_id,
        workplace_id=workplace_id,
        status_id=status_id,
        password_hash=hash_password(password),
        is_active=True,
        must_change_password=True,
        created_by_id=created_by.id,
    )
    session.add(user)
    await session.flush()

    if role_ids:
        for rid in role_ids:
            session.add(UserRole(user_id=user.id, role_id=rid))

    # активируем персональную видимость карточки (по умолчанию не публичная)
    session.add(InfoCardVisibility(user_id=user.id, visible_to_all=False))

    await session.flush()
    return user


async def change_status(
    session: AsyncSession,
    target: User,
    status_code: str,
    actor: User,
) -> None:
    status = await session.scalar(select(UserStatus).where(UserStatus.code == status_code))
    if status is None:
        raise ValueError(f"Неизвестный статус: {status_code}")

    target.status_id = status.id

    if status_code == FIRED_CODE:
        target.is_active = False
        # добавляем в кадровый резерв
        existing = await session.get(PersonnelReserve, target.id)
        if existing is None:
            session.add(
                PersonnelReserve(
                    user_id=target.id,
                    fired_at=__import__("datetime").datetime.now(__import__("datetime").timezone.utc),
                    added_by_id=actor.id,
                )
            )
        else:
            existing.is_restored = False
            existing.restored_at = None
    else:
        target.is_active = True
        # если восстанавливаем — сбрасываем флаг в резерве
        existing = await session.get(PersonnelReserve, target.id)
        if existing is not None:
            existing.is_restored = True
            from datetime import datetime, timezone

            existing.restored_at = datetime.now(timezone.utc)

    await session.flush()
    await invalidate_user_permissions(target.id)


async def set_roles(
    session: AsyncSession,
    target: User,
    role_ids: list[UUID],
) -> None:
    # удаляем старые
    old = (
        await session.scalars(select(UserRole).where(UserRole.user_id == target.id))
    ).all()
    for link in old:
        await session.delete(link)
    await session.flush()

    for rid in role_ids:
        session.add(UserRole(user_id=target.id, role_id=rid))

    await session.flush()
    await invalidate_user_permissions(target.id)


async def set_individual_permissions(
    session: AsyncSession,
    target: User,
    allow_codes: list[str],
    deny_codes: list[str],
) -> None:
    from app.db.models import Permission

    old = (
        await session.scalars(select(UserPermission).where(UserPermission.user_id == target.id))
    ).all()
    for link in old:
        await session.delete(link)
    await session.flush()

    async def _resolve(codes: list[str]) -> list[Permission]:
        if not codes:
            return []
        return (
            await session.scalars(select(Permission).where(Permission.code.in_(codes)))
        ).all()

    for p in await _resolve(allow_codes):
        session.add(UserPermission(user_id=target.id, permission_id=p.id, effect="allow"))
    for p in await _resolve(deny_codes):
        session.add(UserPermission(user_id=target.id, permission_id=p.id, effect="deny"))

    await session.flush()
    await invalidate_user_permissions(target.id)


async def set_public_visibility(
    session: AsyncSession,
    target: User,
    visible: bool,
    actor: User,
) -> None:
    from datetime import datetime, timezone

    vis = await session.get(InfoCardVisibility, target.id)
    if vis is None:
        vis = InfoCardVisibility(user_id=target.id, visible_to_all=visible)
        session.add(vis)
    else:
        vis.visible_to_all = visible
    vis.granted_by_id = actor.id
    vis.granted_at = datetime.now(timezone.utc)
    await session.flush()


def generate_temp_password(length: int = 12) -> str:
    import secrets
    import string

    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


async def get_reference_data(session: AsyncSession) -> dict:
    return {
        "positions": (await session.scalars(select(Position).order_by(Position.name))).all(),
        "workplaces": (await session.scalars(select(Workplace).order_by(Workplace.name))).all(),
        "statuses": (await session.scalars(select(UserStatus).order_by(UserStatus.name))).all(),
        "roles": (await session.scalars(select(Role).order_by(Role.name))).all(),
    }