from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.permissions import Perm
from app.db.models import Permission, Role, RolePermission, UserRole


async def list_roles(session: AsyncSession) -> list[Role]:
    return (
        await session.scalars(select(Role).order_by(Role.is_system.desc(), Role.name))
    ).all()


async def get_role(session: AsyncSession, role_id: UUID) -> Role | None:
    return await session.get(Role, role_id)


async def get_role_by_name(session: AsyncSession, name: str) -> Role | None:
    return await session.scalar(select(Role).where(Role.name == name))


async def list_permissions(session: AsyncSession) -> list[Permission]:
    return (await session.scalars(select(Permission).order_by(Permission.code))).all()


async def get_role_permission_codes(session: AsyncSession, role_id: UUID) -> set[str]:
    stmt = (
        select(Permission.code)
        .join(RolePermission, RolePermission.permission_id == Permission.id)
        .where(RolePermission.role_id == role_id)
    )
    return set((await session.scalars(stmt)).all())


async def create_role(
    session: AsyncSession,
    name: str,
    description: str | None,
    permission_codes: list[str],
) -> Role:
    role = Role(name=name, description=description, is_system=False)
    session.add(role)
    await session.flush()
    await _set_permissions(session, role.id, permission_codes)
    return role


async def update_role(
    session: AsyncSession,
    role: Role,
    name: str,
    description: str | None,
    permission_codes: list[str],
) -> None:
    if role.is_system and name != role.name:
        raise ValueError("Нельзя переименовать системную роль")
    role.name = name
    role.description = description
    await _set_permissions(session, role.id, permission_codes)
    await session.flush()


async def delete_role(session: AsyncSession, role: Role) -> None:
    if role.is_system:
        raise ValueError("Системную роль удалить нельзя")

    # отвязываем пользователей
    links = (
        await session.scalars(select(UserRole).where(UserRole.role_id == role.id))
    ).all()
    for link in links:
        await session.delete(link)
    await session.flush()

    await session.delete(role)
    await session.flush()


async def _set_permissions(
    session: AsyncSession, role_id: UUID, permission_codes: list[str]
) -> None:
    existing = (
        await session.scalars(
            select(RolePermission).where(RolePermission.role_id == role_id)
        )
    ).all()
    for link in existing:
        await session.delete(link)
    await session.flush()

    if not permission_codes:
        return

    perms = (
        await session.scalars(
            select(Permission).where(Permission.code.in_(permission_codes))
        )
    ).all()
    for p in perms:
        session.add(RolePermission(role_id=role_id, permission_id=p.id))
    await session.flush()


def group_permissions(perms: list[Permission]) -> dict[str, list[Permission]]:
    """Группирует permissions по префиксу до первой точки."""
    groups: dict[str, list[Permission]] = {}
    for p in perms:
        prefix = p.code.split(".", 1)[0]
        groups.setdefault(prefix, []).append(p)
    return dict(sorted(groups.items()))


GROUP_TITLES = {
    "users": "Пользователи",
    "roles": "Роли",
    "positions": "Должности",
    "workplaces": "Места работы",
    "documents": "Документы",
    "ratings": "Оценки",
    "comments": "Комментарии",
    "dashboard": "Дашборд",
    "personnel_reserve": "Кадровый резерв",
    "audit": "Аудит",
}