from uuid import UUID

from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import AuditLog, User


async def log_action(
    session: AsyncSession,
    actor: User,
    action: str,
    entity_type: str | None = None,
    entity_id: UUID | None = None,
    request: Request | None = None,
) -> None:
    ip = None
    if request is not None and request.client is not None:
        ip = request.client.host

    session.add(
        AuditLog(
            actor_id=actor.id,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            ip=ip,
        )
    )
    await session.flush()