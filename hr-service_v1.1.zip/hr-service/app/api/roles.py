from uuid import UUID

from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_user, require_permission
from app.core.permissions import Perm
from app.db.models import User
from app.db.session import get_session as db_session
from app.services import role_service
from app.services.audit_service import log_action
from app.core.permissions_cache import get_user_permissions

router = APIRouter(prefix="/roles", tags=["roles"])
templates = Jinja2Templates(directory="app/templates")


@router.get("", response_class=HTMLResponse)
async def list_roles(
    request: Request,
    user: User = Depends(require_permission(Perm.ROLES_VIEW)),
    session: AsyncSession = Depends(db_session),
):
    roles = await role_service.list_roles(session)
    counts: dict[UUID, int] = {r.id: len(r.users) for r in roles}
    perms = await get_user_permissions(session, user.id)
    return templates.TemplateResponse(
        request,
        "roles/list.html",
        {"user": user, "roles": roles, "counts": counts, "perms": perms},
    )


@router.get("/new", response_class=HTMLResponse)
async def new_role_form(
    request: Request,
    user: User = Depends(require_permission(Perm.ROLES_CREATE)),
    session: AsyncSession = Depends(db_session),
):
    perms = await role_service.list_permissions(session)
    return templates.TemplateResponse(
        request,
        "roles/form.html",
        {
            "user": user,
            "target": None,
            "groups": role_service.group_permissions(perms),
            "group_titles": role_service.GROUP_TITLES,
            "selected_codes": set(),
            "error": None,
        },
    )


@router.post("/new")
async def create_role(
    request: Request,
    name: str = Form(...),
    description: str | None = Form(default=None),
    permission_codes: list[str] = Form(default=[]),
    user: User = Depends(require_permission(Perm.ROLES_CREATE)),
    session: AsyncSession = Depends(db_session),
):
    existing = await role_service.get_role_by_name(session, name)
    if existing is not None:
        perms = await role_service.list_permissions(session)
        return templates.TemplateResponse(
            request,
            "roles/form.html",
            {
                "user": user,
                "target": None,
                "groups": role_service.group_permissions(perms),
                "group_titles": role_service.GROUP_TITLES,
                "selected_codes": set(permission_codes),
                "error": f"Роль с именем «{name}» уже существует",
            },
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    role = await role_service.create_role(session, name, description, permission_codes)
    await log_action(session, user, "role.create", "role", role.id, request)
    await session.commit()
    return RedirectResponse("/roles", status_code=status.HTTP_303_SEE_OTHER)


@router.get("/{role_id}/edit", response_class=HTMLResponse)
async def edit_role_form(
    role_id: UUID,
    request: Request,
    user: User = Depends(require_permission(Perm.ROLES_EDIT)),
    session: AsyncSession = Depends(db_session),
):
    role = await role_service.get_role(session, role_id)
    if role is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Роль не найдена")

    perms = await role_service.list_permissions(session)
    selected = await role_service.get_role_permission_codes(session, role_id)

    return templates.TemplateResponse(
        request,
        "roles/form.html",
        {
            "user": user,
            "target": role,
            "groups": role_service.group_permissions(perms),
            "group_titles": role_service.GROUP_TITLES,
            "selected_codes": selected,
            "error": None,
        },
    )


@router.post("/{role_id}/edit")
async def update_role(
    role_id: UUID,
    request: Request,
    name: str = Form(...),
    description: str | None = Form(default=None),
    permission_codes: list[str] = Form(default=[]),
    user: User = Depends(require_permission(Perm.ROLES_EDIT)),
    session: AsyncSession = Depends(db_session),
):
    role = await role_service.get_role(session, role_id)
    if role is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Роль не найдена")

    try:
        await role_service.update_role(session, role, name, description, permission_codes)
    except ValueError as e:
        perms = await role_service.list_permissions(session)
        return templates.TemplateResponse(
            request,
            "roles/form.html",
            {
                "user": user,
                "target": role,
                "groups": role_service.group_permissions(perms),
                "group_titles": role_service.GROUP_TITLES,
                "selected_codes": set(permission_codes),
                "error": str(e),
            },
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    await log_action(session, user, "role.update", "role", role.id, request)
    await session.commit()
    return RedirectResponse("/roles", status_code=status.HTTP_303_SEE_OTHER)


@router.post("/{role_id}/delete")
async def delete_role(
    role_id: UUID,
    request: Request,
    user: User = Depends(require_permission(Perm.ROLES_DELETE)),
    session: AsyncSession = Depends(db_session),
):
    role = await role_service.get_role(session, role_id)
    if role is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Роль не найдена")

    try:
        await role_service.delete_role(session, role)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))

    await log_action(session, user, "role.delete", "role", role_id, request)
    await session.commit()
    return RedirectResponse("/roles", status_code=status.HTTP_303_SEE_OTHER)