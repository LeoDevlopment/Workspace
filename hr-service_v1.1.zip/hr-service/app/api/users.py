from uuid import UUID

from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_user, require_any_permission, require_permission
from app.core.permissions import Perm
from app.core.permissions_cache import get_user_permissions
from app.db.models import Role, User, UserRole, UserStatus
from app.db.session import get_session as db_session
from app.services import user_service
from app.services.access_service import can_view_user_card
from app.services.audit_service import log_action

router = APIRouter(prefix="/users", tags=["users"])
templates = Jinja2Templates(directory="app/templates")


# ---------- /users/me ----------

@router.get("/me", response_class=HTMLResponse)
async def my_card(
    request: Request,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(db_session),
):
    perms = await get_user_permissions(session, user.id)
    refs = await user_service.get_reference_data(session)

    role_links = (
        await session.execute(
            select(Role.name)
            .join(UserRole, UserRole.role_id == Role.id)
            .where(UserRole.user_id == user.id)
        )
    ).scalars().all()

    return templates.TemplateResponse(
        request,
        "users/me.html",
        {
            "user": user,
            "refs": refs,
            "perms": perms,
            "role_names": list(role_links),
            "is_admin": Perm.USERS_VIEW_ALL.value in perms,
        },
    )


# ---------- /users ----------

@router.get("", response_class=HTMLResponse)
async def list_users(
    request: Request,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(db_session),
):
    users = await user_service.list_visible_users(session, user)
    perms = await get_user_permissions(session, user.id)
    return templates.TemplateResponse(
        request,
        "users/list.html",
        {
            "user": user,
            "users": users,
            "perms": perms,
        },
    )


# ---------- /users/new ----------

@router.get("/new", response_class=HTMLResponse)
async def new_user_form(
    request: Request,
    user: User = Depends(require_permission(Perm.USERS_CREATE)),
    session: AsyncSession = Depends(db_session),
):
    refs = await user_service.get_reference_data(session)
    return templates.TemplateResponse(
        request,
        "users/form.html",
        {
            "user": user,
            "refs": refs,
            "target": None,
            "error": None,
            "temp_password": None,
        },
    )


@router.post("/new")
async def create_user(
    request: Request,
    login: str = Form(...),
    full_name: str = Form(...),
    email: str | None = Form(default=None),
    phone: str | None = Form(default=None),
    schedule: str | None = Form(default=None),
    position_id: str | None = Form(default=None),
    workplace_id: str | None = Form(default=None),
    status_id: str = Form(...),
    role_ids: list[str] = Form(default=[]),
    user: User = Depends(require_permission(Perm.USERS_CREATE)),
    session: AsyncSession = Depends(db_session),
):
    # проверка уникальности логина
    existing = await session.scalar(select(User).where(User.login == login))
    if existing is not None:
        refs = await user_service.get_reference_data(session)
        return templates.TemplateResponse(
            request,
            "users/form.html",
            {
                "user": user,
                "refs": refs,
                "target": None,
                "error": f"Логин '{login}' уже занят",
                "temp_password": None,
            },
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    temp_password = user_service.generate_temp_password()

    new_user = await user_service.create_user(
        session,
        login=login,
        email=email or None,
        full_name=full_name,
        phone=phone or None,
        schedule=schedule or None,
        position_id=UUID(position_id) if position_id else None,
        workplace_id=UUID(workplace_id) if workplace_id else None,
        status_id=UUID(status_id),
        password=temp_password,
        created_by=user,
        role_ids=[UUID(r) for r in role_ids] if role_ids else [],
    )

    await log_action(
        session, user, "user.create", "user", new_user.id, request
    )
    await session.commit()

    refs = await user_service.get_reference_data(session)
    return templates.TemplateResponse(
        request,
        "users/form.html",
        {
            "user": user,
            "refs": refs,
            "target": new_user,
            "error": None,
            "temp_password": temp_password,
        },
    )


# ---------- /users/{id} ----------

@router.get("/{user_id}", response_class=HTMLResponse)
async def view_user(
    user_id: UUID,
    request: Request,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(db_session),
):
    target = await user_service.get_user_by_id(session, user_id)
    if target is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Пользователь не найден")

    if not await can_view_user_card(session, user, target):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Нет доступа к карточке")

    perms = await get_user_permissions(session, user.id)
    return templates.TemplateResponse(
        request,
        "users/detail.html",
        {
            "user": user,
            "target": target,
            "perms": perms,
        },
    )


# ---------- /users/{id}/edit ----------

@router.get("/{user_id}/edit", response_class=HTMLResponse)
async def edit_user_form(
    user_id: UUID,
    request: Request,
    user: User = Depends(require_any_permission(Perm.USERS_EDIT, Perm.USERS_VIEW_ALL)),
    session: AsyncSession = Depends(db_session),
):
    target = await user_service.get_user_by_id(session, user_id)
    if target is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Пользователь не найден")

    perms = await get_user_permissions(session, user.id)
    if Perm.USERS_EDIT.value not in perms and Perm.USERS_VIEW_ALL.value not in perms:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Нет доступа")

    refs = await user_service.get_reference_data(session)
    user_role_ids = [
        str(r.role_id)
        for r in (
            await session.scalars(select(UserRole).where(UserRole.user_id == target.id))
        ).all()
    ]

    return templates.TemplateResponse(
        request,
        "users/form.html",
        {
            "user": user,
            "refs": refs,
            "target": target,
            "user_role_ids": user_role_ids,
            "error": None,
            "temp_password": None,
        },
    )


@router.post("/{user_id}/edit")
async def update_user(
    user_id: UUID,
    request: Request,
    full_name: str = Form(...),
    email: str | None = Form(default=None),
    phone: str | None = Form(default=None),
    schedule: str | None = Form(default=None),
    position_id: str | None = Form(default=None),
    workplace_id: str | None = Form(default=None),
    status_id: str = Form(...),
    role_ids: list[str] = Form(default=[]),
    user: User = Depends(require_permission(Perm.USERS_EDIT)),
    session: AsyncSession = Depends(db_session),
):
    target = await user_service.get_user_by_id(session, user_id)
    if target is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Пользователь не найден")

    target.full_name = full_name
    target.email = email or None
    target.phone = phone or None
    target.schedule = schedule or None
    target.position_id = UUID(position_id) if position_id else None
    target.workplace_id = UUID(workplace_id) if workplace_id else None

    new_status = await session.get(UserStatus, UUID(status_id))
    old_status = await session.get(UserStatus, target.status_id)
    if new_status and (old_status is None or new_status.code != old_status.code):
        await user_service.change_status(session, target, new_status.code, user)

    await user_service.set_roles(
        session, target, [UUID(r) for r in role_ids] if role_ids else []
    )

    await log_action(session, user, "user.update", "user", target.id, request)
    await session.commit()
    return RedirectResponse(f"/users/{target.id}", status_code=status.HTTP_303_SEE_OTHER)


# ---------- Служебные действия ----------

@router.post("/{user_id}/make-public")
async def make_public(
    user_id: UUID,
    request: Request,
    visible: str = Form(...),
    user: User = Depends(require_permission(Perm.USERS_MAKE_CARD_PUBLIC)),
    session: AsyncSession = Depends(db_session),
):
    target = await user_service.get_user_by_id(session, user_id)
    if target is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)

    await user_service.set_public_visibility(session, target, visible == "true", user)
    await log_action(session, user, "user.make_public", "user", target.id, request)
    await session.commit()
    return RedirectResponse(f"/users/{target.id}", status_code=status.HTTP_303_SEE_OTHER)